TEXT_GAMEOVER  = "WINS";
TEXT_DRAW      = "DRAW";
TEXT_MOVES      = "MOVES";
TEXT_THINKING   = "THINKING";

TEXT_MODE      = "CHOOSE GAME MODE";

TEXT_BLACK     = "BLACK";
TEXT_WHITE     = "WHITE";

TEXT_JUMP      = "MANDATORY JUMP!";
TEXT_MOVES_AVAIL = "NO MOVES AVAILABLE";

TEXT_CREDITS_DEVELOPED = "DEVELOPED BY";

TEXT_SHARE_IMAGE = "200x200.jpg";
TEXT_SHARE_TITLE = "Congratulations!";
TEXT_SHARE_MSG1 = "You collected <strong>";
TEXT_SHARE_MSG2 = " points</strong>!<br><br>Share your score with your friends!";
TEXT_SHARE_SHARE1 = "My score is ";
TEXT_SHARE_SHARE2 = " points! Can you do better?";

