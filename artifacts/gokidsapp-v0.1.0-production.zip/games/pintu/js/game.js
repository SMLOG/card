!(function () {
  var _0x41d2ee = {
    jxqBX: "requestFullscreen",
    ncfXm: "exitFullscreen",
    oORCm: "fullscreenElement",
    SXVKU: "fullscreenEnabled",
    RAPVt: "fullscreenchange",
    HtiJq: "fullscreenerror",
    Mbxji: "webkitRequestFullscreen",
    LGThT: "webkitExitFullscreen",
    VObSK: "webkitFullscreenElement",
    rSaCc: "webkitFullscreenEnabled",
    MTzPt: "webkitfullscreenchange",
    yfALn: "webkitfullscreenerror",
    wXQoy: "webkitRequestFullScreen",
    HvzlN: "webkitCancelFullScreen",
    MChXG: "webkitCurrentFullScreenElement",
    LXeJo: "mozRequestFullScreen",
    SVILB: "mozCancelFullScreen",
    nxZNp: "mozFullScreenElement",
    yIhHX: "mozFullScreenEnabled",
    Bhmut: "mozfullscreenchange",
    DLTlu: "mozfullscreenerror",
    MKbGk: "msRequestFullscreen",
    zWNji: "msExitFullscreen",
    ObqkY: "msFullscreenElement",
    CMQwz: "msFullscreenEnabled",
    JLOtn: "MSFullscreenChange",
    DosXN: "MSFullscreenError",
    jEEos: function (_0x3abe1b, _0x2bc89e) {
      return _0x3abe1b < _0x2bc89e;
    },
    udhEz: function (_0x5c9975, _0x247328) {
      return _0x5c9975 in _0x247328;
    },
    wkOWq: "change",
    EiyaR: function (_0x59760e) {
      return _0x59760e();
    },
    IVPvg: function (_0x222e49) {
      return _0x222e49();
    },
    iPWBh: "error",
    iYyUN: function (_0x118c9e, _0x77daa0) {
      return _0x118c9e(_0x77daa0);
    },
    guCnM: function (_0x3d1c77, _0x178eb9) {
      return _0x3d1c77(_0x178eb9);
    },
    IRaiZ: function (_0x108a99, _0xc93be1) {
      return _0x108a99 != _0xc93be1;
    },
    FOvrP: "undefined",
    YUlEm: function (_0x7be986, _0x1f877a) {
      return _0x7be986 !== _0x1f877a;
    },
    okdXL: function (_0x90442d, _0xf5ef9e) {
      return _0x90442d != _0xf5ef9e;
    },
    ISsVp: function (_0x8cc93a, _0x14c644) {
      return _0x8cc93a in _0x14c644;
    },
    fdWee: "ALLOW_KEYBOARD_INPUT",
  };
  ("use strict");
  var _0x530bdd =
      _0x41d2ee["IRaiZ"](_0x41d2ee["FOvrP"], typeof window) &&
      _0x41d2ee["YUlEm"](void 0x0, window["document"])
        ? window["document"]
        : {},
    _0x1fc306 =
      _0x41d2ee["okdXL"](_0x41d2ee["FOvrP"], typeof module) &&
      module["exports"],
    _0x2e6c37 =
      _0x41d2ee["okdXL"](_0x41d2ee["FOvrP"], typeof Element) &&
      _0x41d2ee["ISsVp"](_0x41d2ee["fdWee"], Element),
    _0x4cec95 = (function () {
      for (
        var _0x1fc306,
          _0x502ce6 = [
            [
              _0x41d2ee["jxqBX"],
              _0x41d2ee["ncfXm"],
              _0x41d2ee["oORCm"],
              _0x41d2ee["SXVKU"],
              _0x41d2ee["RAPVt"],
              _0x41d2ee["HtiJq"],
            ],
            [
              _0x41d2ee["Mbxji"],
              _0x41d2ee["LGThT"],
              _0x41d2ee["VObSK"],
              _0x41d2ee["rSaCc"],
              _0x41d2ee["MTzPt"],
              _0x41d2ee["yfALn"],
            ],
            [
              _0x41d2ee["wXQoy"],
              _0x41d2ee["HvzlN"],
              _0x41d2ee["MChXG"],
              _0x41d2ee["HvzlN"],
              _0x41d2ee["MTzPt"],
              _0x41d2ee["yfALn"],
            ],
            [
              _0x41d2ee["LXeJo"],
              _0x41d2ee["SVILB"],
              _0x41d2ee["nxZNp"],
              _0x41d2ee["yIhHX"],
              _0x41d2ee["Bhmut"],
              _0x41d2ee["DLTlu"],
            ],
            [
              _0x41d2ee["MKbGk"],
              _0x41d2ee["zWNji"],
              _0x41d2ee["ObqkY"],
              _0x41d2ee["CMQwz"],
              _0x41d2ee["JLOtn"],
              _0x41d2ee["DosXN"],
            ],
          ],
          _0x50f541 = 0x0,
          _0x2c9180 = _0x502ce6["length"],
          _0x2e6c37 = {};
        _0x41d2ee["jEEos"](_0x50f541, _0x2c9180);
        _0x50f541++
      )
        if (
          (_0x1fc306 = _0x502ce6[_0x50f541]) &&
          _0x41d2ee["udhEz"](_0x1fc306[0x1], _0x530bdd)
        ) {
          for (
            _0x50f541 = 0x0;
            _0x41d2ee["jEEos"](_0x50f541, _0x1fc306["length"]);
            _0x50f541++
          )
            _0x2e6c37[_0x502ce6[0x0][_0x50f541]] = _0x1fc306[_0x50f541];
          return _0x2e6c37;
        }
      return !0x1;
    })(),
    _0x2c9180 = {
      change: _0x4cec95["fullscreenchange"],
      error: _0x4cec95["fullscreenerror"],
    },
    _0x502ce6 = {
      request: function (_0x22351d) {
        var _0x2be253 = {
          VoJZU: _0x41d2ee["wkOWq"],
          niTwq: function (_0x14fb2d) {
            return _0x41d2ee["EiyaR"](_0x14fb2d);
          },
        };
        return new Promise(
          function (_0x2b4fa4) {
            var _0x39a8be = {
              GolXM: _0x2be253["VoJZU"],
              hvlfo: function (_0x453820) {
                return _0x2be253["niTwq"](_0x453820);
              },
            };
            var _0x502ce6 = _0x4cec95["requestFullscreen"],
              _0x258588 = function () {
                this["off"](_0x39a8be["GolXM"], _0x258588),
                  _0x39a8be["hvlfo"](_0x2b4fa4);
              }["bind"](this);
            (_0x22351d = _0x22351d || _0x530bdd["documentElement"]),
              / Version\/5\.1(?:\.\d+)? Safari\//["test"](
                navigator["userAgent"]
              )
                ? _0x22351d[_0x502ce6]()
                : _0x22351d[_0x502ce6](
                    _0x2e6c37 ? Element["ALLOW_KEYBOARD_INPUT"] : {}
                  ),
              this["on"](_0x2be253["VoJZU"], _0x258588);
          }["bind"](this)
        );
      },
      exit: function () {
        var _0x5bf445 = {
          CWeot: _0x41d2ee["wkOWq"],
          nBUqH: function (_0x376dd4) {
            return _0x41d2ee["IVPvg"](_0x376dd4);
          },
        };
        return new Promise(
          function (_0x3c8eca) {
            var _0x502ce6 = function () {
              this["off"](_0x5bf445["CWeot"], _0x502ce6),
                _0x5bf445["nBUqH"](_0x3c8eca);
            }["bind"](this);
            _0x530bdd[_0x4cec95["exitFullscreen"]](),
              this["on"](_0x41d2ee["wkOWq"], _0x502ce6);
          }["bind"](this)
        );
      },
      toggle: function (_0x53dae2) {
        return this["isFullscreen"]
          ? this["exit"]()
          : this["request"](_0x53dae2);
      },
      onchange: function (_0x3170e9) {
        this["on"](_0x41d2ee["wkOWq"], _0x3170e9);
      },
      onerror: function (_0x1f2cf0) {
        this["on"](_0x41d2ee["iPWBh"], _0x1f2cf0);
      },
      on: function (_0x5c52bf, _0x4d668f) {
        var _0x560fb8 = _0x2c9180[_0x5c52bf];
        _0x560fb8 && _0x530bdd["addEventListener"](_0x560fb8, _0x4d668f, !0x1);
      },
      off: function (_0x38ece8, _0x1ea507) {
        var _0x110488 = _0x2c9180[_0x38ece8];
        _0x110488 &&
          _0x530bdd["removeEventListener"](_0x110488, _0x1ea507, !0x1);
      },
      raw: _0x4cec95,
    };
  _0x4cec95
    ? (Object["defineProperties"](_0x502ce6, {
        isFullscreen: {
          get: function () {
            return _0x41d2ee["iYyUN"](
              Boolean,
              _0x530bdd[_0x4cec95["fullscreenElement"]]
            );
          },
        },
        element: {
          enumerable: !0x0,
          get: function () {
            return _0x530bdd[_0x4cec95["fullscreenElement"]];
          },
        },
        enabled: {
          enumerable: !0x0,
          get: function () {
            return _0x41d2ee["guCnM"](
              Boolean,
              _0x530bdd[_0x4cec95["fullscreenEnabled"]]
            );
          },
        },
      }),
      _0x1fc306
        ? (module["exports"] = _0x502ce6)
        : (window["screenfull"] = _0x502ce6))
    : _0x1fc306
    ? (module["exports"] = !0x1)
    : (window["screenfull"] = !0x1);
})();
var sndTimer;
SoundManager = function (_0x1ee6ed) {
  var _0x514a2c = {
    AZcEK: "0|1|4|2|3|5",
    aiCdU: "kff-music",
    ZLTkC: function (_0x5448a0, _0x3cbd6b) {
      return _0x5448a0 === _0x3cbd6b;
    },
  };
  var _0x19e460 = _0x514a2c["AZcEK"]["split"]("|"),
    _0x16327a = 0x0;
  while ([]) {
    switch (_0x19e460[_0x16327a++]) {
      case "0":
        this["game"] = _0x1ee6ed;
        continue;
      case "1":
        try {
          (this["musicPlaying"] = SOUNDS_ENABLED),
            localStorage["getItem"](_0x514a2c["aiCdU"]) &&
              (this["musicPlaying"] =
                SOUNDS_ENABLED &&
                _0x514a2c["ZLTkC"](
                  !0x0,
                  JSON["parse"](localStorage["getItem"](_0x514a2c["aiCdU"]))
                ));
        } catch (_0x2a687e) {
          this["musicPlaying"] = SOUNDS_ENABLED;
        }
        continue;
      case "2":
        this["music"] = [];
        continue;
      case "3":
        this["sounds"] = [];
        continue;
      case "4":
        GameData["BuildDebug"] && (this["musicPlaying"] = !0x1);
        continue;
      case "5":
        this["prevSoundPlayed"] = this["actualMusic"] = null;
        continue;
    }
    break;
  }
};
SoundManager["prototype"] = {
  constructor: SoundManager,
  create: function () {
    var _0x499cea = {
      tyVMt: "12|13|1|0|11|8|16|3|7|2|9|15|6|4|14|10|5",
      Chgrg: "tile_select",
      QSgKu: "tiles_match",
      DMCPa: "result_bronze-silver-star",
      rBTVZ: "menu-click1",
      Iigku: "tile_pop",
      QdbwO: "game_completed",
      AdKdj: "result_item_appear",
      xELdd: "level-start-gank-with-tiles",
      mWYRQ: "level-start-tiles-only-reshufle",
      DuzMv: "result_gold-star",
      OljzN: "pop_balloon",
      ZjrNI: "lost_star2",
      XOgJG: "music_menu",
      suauu: "exceptional_text",
      mrYJg: "tile_return",
      dmRFV: "undo",
      ZMlRw: "tile_wrong-one",
    };
    var _0x13814b = _0x499cea["tyVMt"]["split"]("|"),
      _0x5d929b = 0x0;
    while ([]) {
      switch (_0x13814b[_0x5d929b++]) {
        case "0":
          this["addSound"](_0x499cea["Chgrg"], 0.4);
          continue;
        case "1":
          this["addSound"](_0x499cea["QSgKu"], 0.4);
          continue;
        case "2":
          this["addSound"](_0x499cea["DMCPa"], 0.4);
          continue;
        case "3":
          this["addSound"](_0x499cea["rBTVZ"], 0.4);
          continue;
        case "4":
          this["addSound"](_0x499cea["Iigku"], 0.5);
          continue;
        case "5":
          this["addSound"](_0x499cea["QdbwO"], 0.5);
          continue;
        case "6":
          this["addSound"](_0x499cea["AdKdj"], 0.4);
          continue;
        case "7":
          this["addSound"](_0x499cea["xELdd"], 0.4);
          continue;
        case "8":
          this["addSound"](_0x499cea["mWYRQ"], 0.4);
          continue;
        case "9":
          this["addSound"](_0x499cea["DuzMv"], 0.4);
          continue;
        case "10":
          this["addSound"](_0x499cea["OljzN"], 0.6);
          continue;
        case "11":
          this["addSound"](_0x499cea["ZjrNI"], 0.3);
          continue;
        case "12":
          this["addMusic"](_0x499cea["XOgJG"], 0.5, !0x0);
          continue;
        case "13":
          this["addSound"](_0x499cea["suauu"], 0.3);
          continue;
        case "14":
          this["addSound"](_0x499cea["mrYJg"], 0.5);
          continue;
        case "15":
          this["addSound"](_0x499cea["dmRFV"], 0.4);
          continue;
        case "16":
          this["addSound"](_0x499cea["ZMlRw"], 0.4);
          continue;
      }
      break;
    }
  },
  addMusic: function (_0x2174d5, _0x23d7c4, _0x28ab54) {
    var _0xb9f088 = {
      anFPO: function (_0x14733b, _0x13c686) {
        return _0x14733b === _0x13c686;
      },
    };
    _0xb9f088["anFPO"](void 0x0, _0x28ab54) && (_0x28ab54 = !0x1);
    this["music"][_0x2174d5] = game["add"]["audio"](
      _0x2174d5,
      _0x23d7c4,
      _0x28ab54
    );
  },
  addSound: function (_0x46d8f1, _0x37fcf9, _0x25e736) {
    var _0xc5f350 = {
      uiEfN: function (_0x274d88, _0x41be77) {
        return _0x274d88 === _0x41be77;
      },
    };
    _0xc5f350["uiEfN"](void 0x0, _0x25e736) && (_0x25e736 = !0x1);
    this["sounds"][_0x46d8f1] = game["add"]["audio"](
      _0x46d8f1,
      _0x37fcf9,
      _0x25e736
    );
  },
  playMusic: function (_0x41c30f, _0x30bc99) {
    var _0x11dbb5 = {
      cfXTq: function (_0x1a3122, _0x5609da) {
        return _0x1a3122 === _0x5609da;
      },
      tbehj: function (_0x22904c, _0x22e062) {
        return _0x22904c != _0x22e062;
      },
      EUHxf: function (_0xba3f32, _0x216879) {
        return _0xba3f32 != _0x216879;
      },
      KEzMv: "contains",
      dqiQN: function (_0x2de7cc, _0x298f46) {
        return _0x2de7cc == _0x298f46;
      },
    };
    _0x11dbb5["cfXTq"](void 0x0, _0x30bc99) && (_0x30bc99 = !0x1);
    if (_0x11dbb5["tbehj"](_0x41c30f, this["actualMusic"]) || _0x30bc99)
      this["actualMusic"] = _0x41c30f;
    if (this["musicPlaying"])
      for (var _0x4b485a in this["music"])
        _0x11dbb5["EUHxf"](_0x11dbb5["KEzMv"], _0x4b485a) &&
          (_0x11dbb5["dqiQN"](_0x4b485a, this["actualMusic"])
            ? this["music"][_0x4b485a]["play"]()
            : this["music"][_0x4b485a]["stop"]());
  },
  playSound: function (_0x355dcd) {
    var _0x1fe670 = {
      riDhg: function (_0xf1d42a, _0x5ebc09) {
        return _0xf1d42a(_0x5ebc09);
      },
      ZnCSG: function (_0x306ffa, _0x279620) {
        return _0x306ffa + _0x279620;
      },
      UBfRZ: "Failed\x20to\x20play\x20sound\x20:\x20",
    };
    if (this["musicPlaying"])
      try {
        this["sounds"][_0x355dcd]["play"]();
      } catch (_0x533279) {
        _0x1fe670["riDhg"](
          LOG,
          _0x1fe670["ZnCSG"](_0x1fe670["UBfRZ"], _0x355dcd)
        );
      }
  },
  pauseMusic: function () {
    var _0x3ced23 = {
      HTsLU: function (_0x22d75f, _0x504b92) {
        return _0x22d75f != _0x504b92;
      },
      UvrEK: "contains",
      qOUve: function (_0x5c7c27, _0x2dd4d0) {
        return _0x5c7c27 == _0x2dd4d0;
      },
    };
    if (this["musicPlaying"])
      for (var _0x5e576a in this["music"])
        _0x3ced23["HTsLU"](_0x3ced23["UvrEK"], _0x5e576a) &&
          _0x3ced23["qOUve"](_0x5e576a, this["actualMusic"]) &&
          this["music"][_0x5e576a]["pause"]();
  },
  resumeMusic: function () {
    var _0x155a09 = {
      KHRpK: function (_0x229ffa, _0xdc02c9) {
        return _0x229ffa != _0xdc02c9;
      },
      PYWgB: "contains",
      eHzEL: function (_0x1c4b7b, _0x22ea86) {
        return _0x1c4b7b == _0x22ea86;
      },
    };
    if (this["musicPlaying"])
      for (var _0x5ef457 in this["music"])
        _0x155a09["KHRpK"](_0x155a09["PYWgB"], _0x5ef457) &&
          _0x155a09["eHzEL"](_0x5ef457, this["actualMusic"]) &&
          this["music"][_0x5ef457]["resume"]();
  },
  stopMusic: function () {
    var _0x3adcd1 = {
      PNUxp: function (_0x4529a9, _0x39c603) {
        return _0x4529a9 != _0x39c603;
      },
      EuqEp: "contains",
    };
    for (var _0x525757 in this["music"])
      _0x3adcd1["PNUxp"](_0x3adcd1["EuqEp"], _0x525757) &&
        this["music"][_0x525757]["stop"]();
  },
  toggleMusic: function (_0x5854db) {
    this["musicPlaying"]
      ? ((this["musicPlaying"] = !0x1), this["stopMusic"]())
      : ((this["musicPlaying"] = !0x0), this["playMusic"](_0x5854db));
  },
  fadeOutMusic: function (_0x3fa946) {
    this["music"][_0x3fa946]["volume"] = 0x1;
    game["add"]
      ["tween"](this["music"][_0x3fa946])
      ["to"]({ volume: 0x0 }, 0xfa, Phaser["Easing"]["Linear"]["none"], !0x0)
      ["onComplete"]["add"](function () {
        this["pauseMusic"]();
      }, this);
    this["sndTimer"] = game["time"]["events"]["add"](
      0x9c4,
      function () {
        this["resumeMusic"]();
        game["add"]
          ["tween"](this["music"][_0x3fa946])
          ["to"](
            { volume: 0.5 },
            0xfa,
            Phaser["Easing"]["Linear"]["none"],
            !0x0
          );
      },
      this
    );
  },
  stopTimer: function (_0x3c0b7c) {
    game["time"]["events"]["remove"](this["sndTimer"]);
    this["music"][_0x3c0b7c]["volume"] = 0.5;
  },
};
TextParticles = function (_0x5f1f41) {
  this["MAX_PARTICLES"] = 0x3;
  this["objTextParticles"] = [];
  this["_init"]();
  TextParticles["instance"] = this;
};
TextParticles["instance"] = null;
TextParticles["prototype"] = {
  constructor: TextParticles,
  _init: function (_0x3b949f) {
    var _0x327670 = {
      ORqPn: function (_0x124c94, _0x5c255f) {
        return _0x124c94 < _0x5c255f;
      },
      YMIkY: "DUMMY",
    };
    this["grpTextParticles"] = game["add"]["group"]();
    _0x3b949f = { tag: "", velX: 0x0, velY: 0x0, accX: 0x0, accY: 0x0 };
    for (
      var _0x488356 = 0x0;
      _0x327670["ORqPn"](_0x488356, this["MAX_PARTICLES"]);
      _0x488356++
    )
      this["CreateTextParticle"](0x0, 0x0, _0x327670["YMIkY"], _0x3b949f);
    for (
      _0x488356 = 0x0;
      _0x327670["ORqPn"](_0x488356, this["MAX_PARTICLES"]);
      _0x488356++
    )
      this["objTextParticles"][_0x488356]["sprite"]["visible"] = !0x1;
  },
  CreateTextParticle: function (_0x126c81, _0x28dcce, _0x3faf3f, _0x1aab8c) {
    var _0x492ee1 = {
      Qpewa:
        "18|27|17|1|23|0|2|4|22|21|12|9|10|16|8|11|20|7|13|15|19|26|3|5|25|14|24|6",
      HpzlO: "velY",
      wOmlE: "life",
      euWNm: function (_0x68637f, _0x23c203) {
        return _0x68637f + _0x23c203;
      },
      RtOzR: function (_0x4ba1b2, _0x2351a5) {
        return _0x4ba1b2(_0x2351a5);
      },
      cPHIH: "accX",
      GtiWw: "accY",
      kwFqc: function (_0x347fe3, _0x7288a7) {
        return _0x347fe3 === _0x7288a7;
      },
      gEjTc: "alpha",
      TCJNW: "start",
      LamTt: "end",
      nYhfe: function (_0x80cea6, _0x1c43b9) {
        return _0x80cea6 - _0x1c43b9;
      },
      trAiE: function (_0x45db5e, _0x2b9c68) {
        return _0x45db5e < _0x2b9c68;
      },
      FHMtx: function (_0xef8fe6, _0x171a18) {
        return _0xef8fe6 == _0x171a18;
      },
      HsbOw: "blendMode",
      DFdOy: "tag",
      lwOfG: "scale",
      KRnRd: "rotation",
      jwiQV: "velX",
      ngYRC: function (_0x892cc7, _0x534326) {
        return _0x892cc7(_0x534326);
      },
      oioHN: function (_0x4050b5, _0x21e928) {
        return _0x4050b5 + _0x21e928;
      },
      vGZMx: "TILES\x20:\x20",
      SKxqu: "style",
    };
    var _0x158901 = _0x492ee1["Qpewa"]["split"]("|"),
      _0x435744 = 0x0;
    while ([]) {
      switch (_0x158901[_0x435744++]) {
        case "0":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["HpzlO"]) ||
            (_0x1aab8c["velY"] = 0x0);
          continue;
        case "1":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["wOmlE"]) ||
            (_0x1aab8c["life"] = _0x492ee1["euWNm"](
              0x1f4,
              _0x492ee1["RtOzR"](getRandomUInt, 0xc8)
            ));
          continue;
        case "2":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["cPHIH"]) ||
            (_0x1aab8c["accX"] = 0x0);
          continue;
        case "3":
          _0x1e6989["sprite"]["tint"] = 0xffffff;
          continue;
        case "4":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["GtiWw"]) ||
            (_0x1aab8c["accY"] = 0x0);
          continue;
        case "5":
          _0x1e6989["sprite"]["blendMode"] = _0x1aab8c["blendMode"];
          continue;
        case "6":
          return _0x1e6989;
        case "7":
          _0x1e6989["sprite"]["alpha"] = _0x1aab8c["alpha"]["start"];
          continue;
        case "8":
          _0x492ee1["kwFqc"](null, _0x1e6989) &&
            ((_0x1e6989 = this["objTextParticles"][
              this["objTextParticles"]["length"]
            ] =
              {}),
            (_0x1e6989["sprite"] = new Phaser["Text"](
              game,
              -0x64,
              -0x64,
              _0x3faf3f,
              _0x1aab8c["style"]
            )),
            this["grpTextParticles"]["add"](_0x1e6989["sprite"]),
            _0x1e6989["sprite"]["anchor"]["set"](0.5));
          continue;
        case "9":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["gEjTc"])
            ? (_0x1aab8c["alpha"]["hasOwnProperty"](_0x492ee1["TCJNW"]) ||
                (_0x1aab8c["alpha"]["start"] = 0x1),
              _0x1aab8c["alpha"]["hasOwnProperty"](_0x492ee1["LamTt"]) ||
                (_0x1aab8c["alpha"]["end"] = _0x1aab8c["alpha"]["start"]))
            : (_0x1aab8c["alpha"] = { start: 0x1, end: 0x1 });
          continue;
        case "10":
          _0x1aab8c["alpha"]["delta"] = _0x492ee1["nYhfe"](
            _0x1aab8c["alpha"]["start"],
            _0x1aab8c["alpha"]["end"]
          );
          continue;
        case "11":
          game["world"]["bringToTop"](_0x1e6989["sprite"]);
          continue;
        case "12":
          _0x1aab8c["scale"]["delta"] = _0x492ee1["nYhfe"](
            _0x1aab8c["scale"]["start"],
            _0x1aab8c["scale"]["end"]
          );
          continue;
        case "13":
          _0x1e6989["sprite"]["angle"] = 0x0;
          continue;
        case "14":
          _0x1e6989["data"]["lifeInit"] = _0x1aab8c["life"];
          continue;
        case "15":
          _0x1e6989["sprite"]["x"] = _0x126c81;
          continue;
        case "16":
          for (
            var _0x1e6989 = null, _0x5b1149 = 0x0;
            _0x492ee1["trAiE"](_0x5b1149, this["objTextParticles"]["length"]) &&
            _0x492ee1["FHMtx"](null, _0x1e6989);
            _0x5b1149++
          )
            this["objTextParticles"][_0x5b1149]["sprite"]["visible"] ||
              ((_0x1e6989 = this["objTextParticles"][_0x5b1149]),
              (_0x1e6989["sprite"]["text"] = _0x3faf3f),
              _0x1e6989["sprite"]["setStyle"](_0x1aab8c["style"]));
          continue;
        case "17":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["HsbOw"]) ||
            (_0x1aab8c["blendMode"] = PIXI["blendModes"]["NORMAL"]);
          continue;
        case "18":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["DFdOy"]) ||
            (_0x1aab8c["tag"] = "");
          continue;
        case "19":
          _0x1e6989["sprite"]["y"] = _0x28dcce;
          continue;
        case "20":
          _0x1e6989["sprite"]["visible"] = !0x0;
          continue;
        case "21":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["lwOfG"])
            ? (_0x1aab8c["scale"]["hasOwnProperty"](_0x492ee1["TCJNW"]) ||
                (_0x1aab8c["scale"]["start"] = 0x1),
              _0x1aab8c["scale"]["hasOwnProperty"](_0x492ee1["LamTt"]) ||
                (_0x1aab8c["scale"]["end"] = _0x1aab8c["scale"]["start"]))
            : (_0x1aab8c["scale"] = { start: 0x1, end: 0x1 });
          continue;
        case "22":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["KRnRd"]) ||
            (_0x1aab8c["rotation"] = 0x0);
          continue;
        case "23":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["jwiQV"]) ||
            (_0x1aab8c["velX"] = 0x0);
          continue;
        case "24":
          _0x492ee1["trAiE"](0x0, _0x1aab8c["tag"]["length"]) &&
            _0x492ee1["ngYRC"](
              LOG,
              _0x492ee1["oioHN"](
                _0x492ee1["vGZMx"],
                Particles["instance"]["GetActiveCount"](_0x1aab8c["tag"])
              )
            );
          continue;
        case "25":
          _0x1e6989["data"] = _0x1aab8c;
          continue;
        case "26":
          _0x1e6989["sprite"]["scale"]["set"](0x1);
          continue;
        case "27":
          _0x1aab8c["hasOwnProperty"](_0x492ee1["SKxqu"]) ||
            (_0x1aab8c["style"] = {});
          continue;
      }
      break;
    }
  },
  Reset: function () {
    var _0x59b1e9 = {
      WxQqw: function (_0x525cf9, _0x22e749) {
        return _0x525cf9 < _0x22e749;
      },
    };
    for (
      var _0x126002 = 0x0;
      _0x59b1e9["WxQqw"](_0x126002, this["objTextParticles"]["length"]);
      _0x126002++
    )
      this["objTextParticles"][_0x126002]["sprite"]["visible"] = !0x1;
  },
  GetActiveCount: function (_0x29426e) {
    var _0x5a90c2 = {
      nynNR: function (_0x3e64e5, _0x2f2eb2) {
        return _0x3e64e5 || _0x2f2eb2;
      },
      vdSMs: function (_0x2832d0, _0x3253a4) {
        return _0x2832d0 < _0x3253a4;
      },
      dxkFC: function (_0x27599c, _0x10e9ca) {
        return _0x27599c == _0x10e9ca;
      },
      ICvBO: function (_0x43ff3a, _0x5a7f3b) {
        return _0x43ff3a < _0x5a7f3b;
      },
    };
    _0x29426e = _0x5a90c2["nynNR"](_0x29426e, null);
    for (
      var _0x131b09 = 0x0, _0x3d3953 = 0x0;
      _0x5a90c2["vdSMs"](_0x3d3953, this["objTextParticles"]["length"]);
      _0x3d3953++
    )
      (_0x5a90c2["dxkFC"](null, _0x29426e) ||
        _0x5a90c2["dxkFC"](
          this["objTextParticles"][_0x3d3953]["data"]["tag"],
          _0x29426e
        )) &&
        this["objTextParticles"][_0x3d3953]["sprite"]["visible"] &&
        _0x5a90c2["ICvBO"](
          0x0,
          this["objTextParticles"][_0x3d3953]["data"]["life"]
        ) &&
        _0x131b09++;
    return _0x131b09;
  },
  Update: function () {
    var _0x41c3c8 = {
      nKNLF: function (_0x314592, _0x414c1a) {
        return _0x314592 < _0x414c1a;
      },
      kCNVk: function (_0x19e5b5, _0x2eecdc) {
        return _0x19e5b5 >= _0x2eecdc;
      },
      dPnyX: function (_0x3e8abd, _0x46e01a) {
        return _0x3e8abd + _0x46e01a;
      },
      nQDWD: function (_0x2822ac, _0x45650a) {
        return _0x2822ac - _0x45650a;
      },
      YXIcg: function (_0x39fc71, _0x2e0f73) {
        return _0x39fc71 * _0x2e0f73;
      },
      hzcbH: function (_0x3191ec, _0x427cee) {
        return _0x3191ec / _0x427cee;
      },
      YxEWw: function (_0x157227, _0x4ae564) {
        return _0x157227 * _0x4ae564;
      },
    };
    for (
      var _0x14f570 = 0x0;
      _0x41c3c8["nKNLF"](_0x14f570, this["objTextParticles"]["length"]);
      _0x14f570++
    )
      this["objTextParticles"][_0x14f570]["sprite"]["visible"] &&
        ((this["objTextParticles"][_0x14f570]["data"]["life"] -=
          game["time"]["elapsedMS"]),
        _0x41c3c8["kCNVk"](
          0x0,
          this["objTextParticles"][_0x14f570]["data"]["life"]
        )
          ? (this["objTextParticles"][_0x14f570]["sprite"]["visible"] = !0x1)
          : ((this["objTextParticles"][_0x14f570]["sprite"]["alpha"] =
              _0x41c3c8["dPnyX"](
                _0x41c3c8["nQDWD"](
                  this["objTextParticles"][_0x14f570]["data"]["alpha"]["start"],
                  this["objTextParticles"][_0x14f570]["data"]["alpha"]["delta"]
                ),
                _0x41c3c8["YXIcg"](
                  _0x41c3c8["hzcbH"](
                    this["objTextParticles"][_0x14f570]["data"]["life"],
                    this["objTextParticles"][_0x14f570]["data"]["lifeInit"]
                  ),
                  this["objTextParticles"][_0x14f570]["data"]["alpha"]["delta"]
                )
              )),
            this["objTextParticles"][_0x14f570]["sprite"]["scale"]["set"](
              _0x41c3c8["dPnyX"](
                _0x41c3c8["nQDWD"](
                  this["objTextParticles"][_0x14f570]["data"]["scale"]["start"],
                  this["objTextParticles"][_0x14f570]["data"]["scale"]["delta"]
                ),
                _0x41c3c8["YxEWw"](
                  _0x41c3c8["hzcbH"](
                    this["objTextParticles"][_0x14f570]["data"]["life"],
                    this["objTextParticles"][_0x14f570]["data"]["lifeInit"]
                  ),
                  this["objTextParticles"][_0x14f570]["data"]["scale"]["delta"]
                )
              )
            ),
            (this["objTextParticles"][_0x14f570]["sprite"]["angle"] +=
              this["objTextParticles"][_0x14f570]["data"]["rotation"]),
            (this["objTextParticles"][_0x14f570]["sprite"]["x"] +=
              this["objTextParticles"][_0x14f570]["data"]["velX"]),
            (this["objTextParticles"][_0x14f570]["sprite"]["y"] +=
              this["objTextParticles"][_0x14f570]["data"]["velY"]),
            (this["objTextParticles"][_0x14f570]["data"]["velX"] +=
              this["objTextParticles"][_0x14f570]["data"]["accX"]),
            (this["objTextParticles"][_0x14f570]["data"]["velY"] +=
              this["objTextParticles"][_0x14f570]["data"]["accY"])));
  },
  Destroy: function () {
    var _0x1f673e = {
      BxgTF: function (_0x1cb4d, _0x1ef2c1) {
        return _0x1cb4d < _0x1ef2c1;
      },
    };
    for (
      var _0x3200bc = 0x0;
      _0x1f673e["BxgTF"](_0x3200bc, this["objTextParticles"]["length"]);
      _0x3200bc++
    )
      this["objTextParticles"][_0x3200bc]["sprite"]["Destroy"](),
        (this["objTextParticles"][_0x3200bc]["sprite"] = null),
        (this["objTextParticles"][_0x3200bc] = null);
    this["objTextParticles"] = null;
  },
  CreateTextParticle1: function (
    _0x3e25b3,
    _0x38570b,
    _0xd98353,
    _0x343718,
    _0x5ab3e5,
    _0x1356af
  ) {
    var _0x297497 = {
      ufLed: function (_0x4f574e, _0x22a3c5) {
        return _0x4f574e / _0x22a3c5;
      },
      xqFrV: function (_0x2755c0, _0x15ba7e) {
        return _0x2755c0 >= _0x15ba7e;
      },
      tJkXh: function (_0x5209ce, _0x322901) {
        return _0x5209ce + _0x322901;
      },
      yiQDS: "px\x20gameFont",
      yVhPW: "#FFFFFF",
    };
    _0x1356af = _0x1356af || PIXI["blendModes"]["NORMAL"];
    tmpY = _0x297497["ufLed"](
      game["rnd"]["integerInRange"](-0x64, -0x32),
      0x32
    );
    this["CreateTextParticle"](_0x3e25b3, _0x38570b, _0xd98353, {
      velX: 0x0,
      velY: tmpY,
      accX: 0x0,
      accY: _0x297497["xqFrV"](0x0, tmpY) ? 0.02 : -0.02,
      style: {
        font: _0x297497["tJkXh"](_0x343718, _0x297497["yiQDS"]),
        fill: _0x5ab3e5,
        stroke: _0x297497["yVhPW"],
        strokeThickness: 0x4,
      },
      blendMode: _0x1356af,
      rotation: 0x0,
      scale: { start: 1.2, end: 0x1 },
      alpha: { start: 0.9, end: 0x0 },
      life: 0x3e8,
    });
  },
};
var Languages = function () {
    var _0x15e059 = {
      gOPcE: "0|4|2|3|1|5|6",
      QABAs: function (_0x35464d, _0xeb43de) {
        return _0x35464d != _0xeb43de;
      },
      WkGbI: "lang_strings",
      xFiFK: "text/xml",
      Spwnx: "string",
      FWcLb: function (_0x3640be, _0x4db0d6) {
        return _0x3640be < _0x4db0d6;
      },
      UfuXq: function (_0x31ff36, _0x458296) {
        return _0x31ff36 == _0x458296;
      },
    };
    var _0xd78f8d = _0x15e059["gOPcE"]["split"]("|"),
      _0x103f0f = 0x0;
    while ([]) {
      switch (_0xd78f8d[_0x103f0f++]) {
        case "0":
          if (_0x15e059["QABAs"](null, Languages["instance"]))
            return Languages["instance"];
          continue;
        case "1":
          var _0x215c61 = game["cache"]["getText"](_0x15e059["WkGbI"]);
          continue;
        case "2":
          this["xml"] = this["gameTextsParsed"] = null;
          continue;
        case "3":
          this["gameTextsLists"] = [];
          continue;
        case "4":
          Languages["instance"] = this;
          continue;
        case "5":
          this["gameTextsParsed"] = new DOMParser()["parseFromString"](
            _0x215c61,
            _0x15e059["xFiFK"]
          );
          continue;
        case "6":
          for (
            var _0x215c61 = this["gameTextsParsed"]["getElementsByTagName"](
                _0x15e059["Spwnx"]
              ),
              _0x2c2da9 = 0x0;
            _0x15e059["FWcLb"](_0x2c2da9, _0x215c61["length"]);
            _0x2c2da9++
          ) {
            _0x15e059["UfuXq"](
              null,
              this["gameTextsLists"][
                _0x215c61["item"](_0x2c2da9)["getAttribute"]("id")
              ]
            ) &&
              (this["gameTextsLists"][
                _0x215c61["item"](_0x2c2da9)["getAttribute"]("id")
              ] = []);
            for (
              var _0x50c188 = 0x0;
              _0x15e059["FWcLb"](_0x50c188, LANGUAGES["length"]);
              _0x50c188++
            )
              _0x15e059["FWcLb"](
                0x0,
                _0x215c61["item"](_0x2c2da9)["getElementsByTagName"](
                  LANGUAGES[_0x50c188]
                )["length"]
              ) &&
                (this["gameTextsLists"][
                  _0x215c61["item"](_0x2c2da9)["getAttribute"]("id")
                ][LANGUAGES[_0x50c188]] = _0x215c61["item"](_0x2c2da9)
                  ["getElementsByTagName"](LANGUAGES[_0x50c188])[0x0]
                  ["textContent"]["replace"](/\\n/g, "\x0a")
                  ["toUpperCase"]());
          }
          continue;
      }
      break;
    }
  },
  LANGUAGES = "en\x20de\x20es\x20fr\x20it\x20br\x20nl\x20tr\x20ru"["split"](
    "\x20"
  );
Languages["instance"] = null;
Languages["prototype"] = {};
function STR(_0x4278eb) {
  var _0x2a4732 = {
    lFocu: function (_0x34d97, _0x24e20e) {
      return _0x34d97 == _0x24e20e;
    },
    HXUEa: function (_0x5932ca, _0x4d22f9) {
      return _0x5932ca(_0x4d22f9);
    },
    goEGM: function (_0x53af81, _0x4f7040) {
      return _0x53af81 + _0x4f7040;
    },
    gUIjx: function (_0x4cd03d, _0x42196d) {
      return _0x4cd03d + _0x42196d;
    },
    ZkRoy: "STR(",
    xIpVV: ")\x20MISSING!",
    IboqI: "NAN",
  };
  return _0x2a4732["lFocu"](
    void 0x0,
    Languages["instance"]["gameTextsLists"][_0x4278eb]
  ) ||
    _0x2a4732["lFocu"](
      void 0x0,
      Languages["instance"]["gameTextsLists"][_0x4278eb][
        Languages["instance"]["language"]
      ]
    )
    ? (_0x2a4732["HXUEa"](
        LOG,
        _0x2a4732["goEGM"](
          _0x2a4732["gUIjx"](_0x2a4732["ZkRoy"], _0x4278eb),
          _0x2a4732["xIpVV"]
        )
      ),
      _0x2a4732["IboqI"])
    : Languages["instance"]["gameTextsLists"][_0x4278eb][
        Languages["instance"]["language"]
      ]["replaceAll"]("\x5cn", "\x0a");
}
var ADS_ENABLED = !0x1,
  ADS_DELAY = 0x3c,
  ADS_ON_FIRST_PLAY = !0x0,
  ADS_MOBILE_WIDTH = 0x1e0,
  ADS_MOBILE_HEIGHT = 0x320,
  adinplay_onAdStarted = function () {},
  adinplay_onAdFinished = function () {};
function adinplay_init() {
  var _0x113320 = {
    XquiC: "ads",
    ZqKzl: function (_0x4c6ab3) {
      return _0x4c6ab3();
    },
    bkccd: function (_0x3ba235) {
      return _0x3ba235();
    },
    dYfEU: "loading\x20advertisement",
    QmlMP: function (_0x450d9a, _0x359868) {
      return _0x450d9a !== _0x359868;
    },
    AqZVe: "undefined",
    JFHOO: "0|6|1|10|7|8|2|5|3|4|9",
    mxtzf: "inlogic",
    pwaQR: function (_0xde33cf, _0x4b4ed8) {
      return _0xde33cf || _0x4b4ed8;
    },
    Tqpnn: "partner_id",
  };
  if (ADS_ENABLED && _0x113320["QmlMP"](_0x113320["AqZVe"], typeof aiptag)) {
    var _0x34effd = _0x113320["JFHOO"]["split"]("|"),
      _0x23391d = 0x0;
    while ([]) {
      switch (_0x34effd[_0x23391d++]) {
        case "0":
          var _0x83fce8 = _0x113320["mxtzf"],
            _0x2e4a4a = _0x113320["bkccd"](getJsonFromUrl);
          continue;
        case "1":
          aiptag = _0x113320["pwaQR"](aiptag, {});
          continue;
        case "2":
          aiptag["subid"] = _0x83fce8;
          continue;
        case "3":
          ads_time = 0x0;
          continue;
        case "4":
          ADS_ON_FIRST_PLAY && (ads_time = -ADS_DELAY);
          continue;
        case "5":
          aiptag["consented"] = !0x0;
          continue;
        case "6":
          _0x2e4a4a["hasOwnProperty"](_0x113320["Tqpnn"]) &&
            (_0x83fce8 = _0x2e4a4a["partner_id"]);
          continue;
        case "7":
          aiptag["cmd"]["display"] = aiptag["cmd"]["display"] || [];
          continue;
        case "8":
          aiptag["cmd"]["player"] = aiptag["cmd"]["player"] || [];
          continue;
        case "9":
          aiptag["cmd"]["player"]["push"](function () {
            var _0x332830 = {
              cudzk: function (_0x49a712) {
                return _0x113320["ZqKzl"](_0x49a712);
              },
              fkvBR: function (_0x548868) {
                return _0x113320["bkccd"](_0x548868);
              },
              xEHYk: function (_0x1a04bc) {
                return _0x113320["bkccd"](_0x1a04bc);
              },
            };
            var _0x83fce8 = game["width"],
              _0x2e4a4a = game["height"];
            Phaser["Device"]["desktop"] ||
              ((_0x83fce8 = ADS_MOBILE_WIDTH), (_0x2e4a4a = ADS_MOBILE_HEIGHT));
            adplayer = new aipPlayer({
              AD_WIDTH: _0x83fce8,
              AD_HEIGHT: _0x2e4a4a,
              AD_FULLSCREEN: 0x1,
              AD_CENTERPLAYER: 0x0,
              AD_FADING: 0x0,
              LOADING_TEXT: _0x113320["dYfEU"],
              PREROLL_ELEM: function () {
                return document["getElementById"](_0x113320["XquiC"]);
              },
              AIP_COMPLETE: function () {
                _0x332830["cudzk"](adinplay_resumeMusic);
                _0x332830["fkvBR"](adinplay_enableInput);
                _0x332830["xEHYk"](adinplay_onAdStarted);
              },
              AIP_REMOVE: function () {
                _0x113320["ZqKzl"](adinplay_onAdFinished);
              },
            });
          });
          continue;
        case "10":
          aiptag["cmd"] = aiptag["cmd"] || [];
          continue;
      }
      break;
    }
  }
}
function adinplay_playVideoAd() {
  var _0x4ca2cb = {
    iUIag: function (_0x20be6d, _0x2f5a40) {
      return _0x20be6d === _0x2f5a40;
    },
    vpdni: "undefined",
    pdLMg: function (_0x4edd20) {
      return _0x4edd20();
    },
    YClty: function (_0x264796) {
      return _0x264796();
    },
    wjLtp: function (_0x1057bc) {
      return _0x1057bc();
    },
    AePLf: function (_0x3a0464, _0x1ac9be) {
      return _0x3a0464 < _0x1ac9be;
    },
    Swrbz: function (_0x39b27d, _0x6a8325) {
      return _0x39b27d - _0x6a8325;
    },
    DCDIk: function (_0x296c5d) {
      return _0x296c5d();
    },
    GsZQZ: function (_0x4f2765) {
      return _0x4f2765();
    },
    eEFuC: function (_0x5848c9) {
      return _0x5848c9();
    },
  };
  ADS_ENABLED
    ? _0x4ca2cb["iUIag"](_0x4ca2cb["vpdni"], typeof aiptag)
      ? (_0x4ca2cb["pdLMg"](adinplay_init),
        _0x4ca2cb["pdLMg"](adinplay_enableInput),
        _0x4ca2cb["YClty"](adinplay_onAdStarted))
      : _0x4ca2cb["iUIag"](_0x4ca2cb["vpdni"], typeof adplayer)
      ? (_0x4ca2cb["YClty"](adinplay_init),
        _0x4ca2cb["YClty"](adinplay_enableInput),
        _0x4ca2cb["wjLtp"](adinplay_onAdStarted))
      : _0x4ca2cb["AePLf"](
          _0x4ca2cb["Swrbz"](game["time"]["totalElapsedSeconds"](), ads_time),
          ADS_DELAY
        )
      ? (_0x4ca2cb["wjLtp"](adinplay_enableInput),
        _0x4ca2cb["wjLtp"](adinplay_onAdStarted))
      : ((ads_time = game["time"]["totalElapsedSeconds"]()),
        _0x4ca2cb["DCDIk"](adinplay_disableInput),
        _0x4ca2cb["GsZQZ"](adinplay_pauseMusic),
        aiptag["cmd"]["player"]["push"](function () {
          adplayer["startPreRoll"]();
        }))
    : (_0x4ca2cb["eEFuC"](adinplay_enableInput),
      _0x4ca2cb["eEFuC"](adinplay_onAdStarted));
}
function adinplay_disableInput() {
  var _0x1e9afb = {
    MmCUA: "4|2|0|3|1",
    oHeAX: function (_0x34384c, _0x2b551c) {
      return _0x34384c / _0x2b551c;
    },
    xHZOI: function (_0x51bb26, _0x6012d4) {
      return _0x51bb26 / _0x6012d4;
    },
    NbwYy: function (_0x38426e, _0x57a3ef) {
      return _0x38426e == _0x57a3ef;
    },
    KRaOC: "undefined",
    tUKJF: function (_0x3d49b4, _0x5e7540) {
      return _0x3d49b4 / _0x5e7540;
    },
    MMzPG: "void",
  };
  var _0x15307b = _0x1e9afb["MmCUA"]["split"]("|"),
    _0x7df2fd = 0x0;
  while ([]) {
    switch (_0x15307b[_0x7df2fd++]) {
      case "0":
        adinplay_overlay["width"] = game["width"];
        continue;
      case "1":
        adinplay_overlay["visible"] = !0x0;
        continue;
      case "2":
        adinplay_overlay["position"]["setTo"](
          _0x1e9afb["oHeAX"](game["width"], 0x2),
          _0x1e9afb["xHZOI"](game["height"], 0x2)
        );
        continue;
      case "3":
        adinplay_overlay["height"] = game["heigth"];
        continue;
      case "4":
        _0x1e9afb["NbwYy"](_0x1e9afb["KRaOC"], typeof adinplay_overlay) &&
          ((adinplay_overlay = game["make"]["sprite"](
            _0x1e9afb["tUKJF"](game["width"], 0x2),
            _0x1e9afb["tUKJF"](game["height"], 0x2),
            _0x1e9afb["MMzPG"]
          )),
          adinplay_overlay["anchor"]["set"](0x0, 0x1),
          (adinplay_overlay["inputEnabled"] = !0x0));
        continue;
    }
    break;
  }
}
function adinplay_enableInput() {
  var _0xe316c6 = {
    dZfsQ: function (_0x23df29, _0x175361) {
      return _0x23df29 != _0x175361;
    },
    QpIpq: "undefined",
  };
  _0xe316c6["dZfsQ"](_0xe316c6["QpIpq"], typeof adinplay_overlay) &&
    (adinplay_overlay["visible"] = !0x1);
}
function adinplay_pauseMusic() {
  game["sound"]["mute"] = !0x0;
}
function adinplay_resumeMusic() {
  game["sound"]["mute"] = !0x1;
}
function getJsonFromUrl() {
  var _0x4d7d5f = {
    ZiYMs: function (_0x5ae073, _0x5b3e4b) {
      return _0x5ae073 < _0x5b3e4b;
    },
    eqEsF: function (_0x4a14b7, _0x51de3b) {
      return _0x4a14b7 + _0x51de3b;
    },
    DPcLa: function (_0x5a8453, _0xcee8ac) {
      return _0x5a8453(_0xcee8ac);
    },
  };
  for (
    var _0x3a2df2 = {},
      _0x44e594 = location["search"]["substr"](0x1)["split"]("&"),
      _0x5d07e2 = 0x0;
    _0x4d7d5f["ZiYMs"](_0x5d07e2, _0x44e594["length"]);
    _0x5d07e2++
  ) {
    var _0x4a4ecc = _0x44e594[_0x5d07e2]["indexOf"]("="),
      _0x4a4ecc = [
        _0x44e594[_0x5d07e2]["substring"](0x0, _0x4a4ecc),
        _0x44e594[_0x5d07e2]["substring"](_0x4d7d5f["eqEsF"](_0x4a4ecc, 0x1)),
      ];
    _0x3a2df2[_0x4a4ecc[0x0]] = _0x4d7d5f["DPcLa"](
      decodeURIComponent,
      _0x4a4ecc[0x1]
    );
  }
  return _0x3a2df2;
}
var partnerName = "gamedistribution";
function analyticsOnMainMenuLoadEvent() {}
function analyticsOnLevelStartEvent() {}
var ORIENTATION_PORTRAIT = 0x0,
  ORIENTATION_LANDSCAPE = 0x1,
  GAME_CURRENT_ORIENTATION = ORIENTATION_PORTRAIT,
  GAME_LAST_ORIENTATION = GAME_CURRENT_ORIENTATION,
  MAX_SWIPES = 0x5,
  game_resolutions = {
    0: { x: 0x2a8, yMin: 0x2bc, yMax: 0x514 },
    1: { xMin: 0x330, xMax: 0x4b0, y: 0x258 },
  };
function getMaxGameResolution() {
  return [game_resolutions[0x1]["xMax"], game_resolutions[0x0]["yMax"]];
}
var SOUNDS_ENABLED = !0x0,
  RUNNING_ON_WP = -0x1 < navigator["userAgent"]["indexOf"]("Windows\x20Phone");
RUNNING_ON_WP && (SOUNDS_ENABLED = !0x1);
var ANIMATION_CUBIC_IO = Phaser["Easing"]["Cubic"]["InOut"],
  tmp_sprites = [];
function getRandomUInt(_0x7ac76b) {
  var _0xf5e269 = {
    FoZCQ: function (_0x3bf7ca, _0x5c42db) {
      return _0x3bf7ca * _0x5c42db;
    },
  };
  return Math["floor"](_0xf5e269["FoZCQ"](Math["random"](), _0x7ac76b));
}
function getRandomInt(_0x586b0c) {
  var _0x78a8d6 = {
    GgMAZ: function (_0x152b74, _0x441f4c) {
      return _0x152b74 * _0x441f4c;
    },
    GdHbL: function (_0x428531, _0x54952f) {
      return _0x428531 * _0x54952f;
    },
    JHVvI: function (_0xfe6307, _0x3f3ae5) {
      return _0xfe6307 < _0x3f3ae5;
    },
    KiwNh: function (_0x2a460b, _0x35860b) {
      return _0x2a460b(_0x35860b);
    },
  };
  return _0x78a8d6["GgMAZ"](
    Math["floor"](_0x78a8d6["GdHbL"](Math["random"](), _0x586b0c)),
    _0x78a8d6["JHVvI"](0x32, _0x78a8d6["KiwNh"](getRandomUInt, 0x64))
      ? -0x1
      : 0x1
  );
}
function getRandomUIntInRange(_0x2a1fb7, _0xfa8da5) {
  var _0x33cfc8 = {
    eqHkg: function (_0x15fda0, _0x56c489) {
      return _0x15fda0 + _0x56c489;
    },
    cHOZD: function (_0x5b240b, _0x45e01c) {
      return _0x5b240b * _0x45e01c;
    },
    oYkRW: function (_0x54c2af, _0x446fe0) {
      return _0x54c2af + _0x446fe0;
    },
    eaZut: function (_0xac583b, _0xd16a1) {
      return _0xac583b - _0xd16a1;
    },
  };
  return _0x33cfc8["eqHkg"](
    Math["floor"](
      _0x33cfc8["cHOZD"](
        Math["random"](),
        _0x33cfc8["oYkRW"](_0x33cfc8["eaZut"](_0xfa8da5, _0x2a1fb7), 0x1)
      )
    ),
    _0x2a1fb7
  );
}
function getRandomIntInRange(_0x123034, _0x387344) {
  var _0x5533b6 = {
    cVjgT: function (_0x3c127c, _0x1ca350) {
      return _0x3c127c * _0x1ca350;
    },
    McLHb: function (_0x1cc352, _0x1581d8, _0x3d9238) {
      return _0x1cc352(_0x1581d8, _0x3d9238);
    },
    MThZF: function (_0x3628ba, _0x415561) {
      return _0x3628ba < _0x415561;
    },
    xtUDl: function (_0x268d52, _0x1fc8d7) {
      return _0x268d52(_0x1fc8d7);
    },
  };
  return _0x5533b6["cVjgT"](
    _0x5533b6["McLHb"](getRandomUIntInRange, _0x123034, _0x387344),
    _0x5533b6["MThZF"](0x32, _0x5533b6["xtUDl"](getRandomUInt, 0x64))
  )
    ? -0x1
    : 0x1;
}
String["prototype"]["replaceAll"] = function (_0x261135, _0x41b229) {
  return this["split"](_0x261135)["join"](_0x41b229);
};
function cloneObject(_0x32a233) {
  var _0x3afab3 = {
    YseHp: function (_0x5b72c5, _0x2a28f2) {
      return _0x5b72c5 == _0x2a28f2;
    },
    knoNV: function (_0x8028ef, _0x12f016) {
      return _0x8028ef != _0x12f016;
    },
    RNlKQ: "object",
  };
  if (
    _0x3afab3["YseHp"](null, _0x32a233) ||
    _0x3afab3["knoNV"](_0x3afab3["RNlKQ"], typeof _0x32a233)
  )
    return _0x32a233;
  var _0x344b7f = _0x32a233["constructor"](),
    _0x1cd6e5;
  for (_0x1cd6e5 in _0x32a233)
    _0x32a233["hasOwnProperty"](_0x1cd6e5) &&
      (_0x344b7f[_0x1cd6e5] = _0x32a233[_0x1cd6e5]);
  return _0x344b7f;
}
function isUpperCase(_0x1e2b62) {
  var _0x20fd92 = {
    GbKAy: function (_0x325aff, _0x27f671) {
      return _0x325aff == _0x27f671;
    },
  };
  return _0x20fd92["GbKAy"](_0x1e2b62, _0x1e2b62["toUpperCase"]());
}
function isLowerCase(_0x25dcaa) {
  var _0x5b5faf = {
    YGtIo: function (_0x23ce80, _0x5bca7e) {
      return _0x23ce80 == _0x5bca7e;
    },
  };
  return _0x5b5faf["YGtIo"](_0x25dcaa, _0x25dcaa["toLowerCase"]());
}
function LOG(_0x3e8864) {}
Array["prototype"]["contains"] = function (_0x3eafae) {
  var _0x1bf07e = {
    grdEI: function (_0xa5891, _0x2a84bd) {
      return _0xa5891 === _0x2a84bd;
    },
  };
  for (var _0x4e670b = this["length"]; _0x4e670b--; )
    if (_0x1bf07e["grdEI"](this[_0x4e670b], _0x3eafae)) return !0x0;
  return !0x1;
};
function shuffleArray(_0x2c510f) {
  var _0x3251de = {
    SJFzW: function (_0x3944f8, _0x15751e) {
      return _0x3944f8 !== _0x15751e;
    },
    ymTcL: function (_0x449adb, _0x37cf06) {
      return _0x449adb * _0x37cf06;
    },
  };
  for (
    var _0x377f77 = _0x2c510f["length"], _0x323300, _0x3e7e51;
    _0x3251de["SJFzW"](0x0, _0x377f77);

  )
    (_0x3e7e51 = Math["floor"](
      _0x3251de["ymTcL"](Math["random"](), _0x377f77)
    )),
      --_0x377f77,
      (_0x323300 = _0x2c510f[_0x377f77]),
      (_0x2c510f[_0x377f77] = _0x2c510f[_0x3e7e51]),
      (_0x2c510f[_0x3e7e51] = _0x323300);
  return _0x2c510f;
}
function getCorrectAnchorX(_0x3abb9d, _0x49b65b) {
  var _0x98650b = {
    YfZMy: function (_0x4db947, _0xd2a1f9) {
      return _0x4db947 / _0xd2a1f9;
    },
    PMCyc: function (_0x586d14, _0x230ee9) {
      return _0x586d14 * _0x230ee9;
    },
  };
  return _0x98650b["YfZMy"](
    Math["round"](_0x98650b["PMCyc"](_0x3abb9d["width"], _0x49b65b)),
    _0x3abb9d["width"]
  );
}
function getCorrectAnchorY(_0x14ece0, _0x1c9478) {
  var _0x2a0487 = {
    GjjsZ: function (_0xc920c4, _0x38ee33) {
      return _0xc920c4 / _0x38ee33;
    },
    REINx: function (_0x335a4f, _0x51dfb5) {
      return _0x335a4f * _0x51dfb5;
    },
  };
  return _0x2a0487["GjjsZ"](
    Math["round"](_0x2a0487["REINx"](_0x14ece0["height"], _0x1c9478)),
    _0x14ece0["height"]
  );
}
function getAndroidVersion(_0x4e0f0e) {
  _0x4e0f0e = (_0x4e0f0e || navigator["userAgent"])["toLowerCase"]();
  return (_0x4e0f0e = _0x4e0f0e["match"](/android\s([0-9\.]*)/))
    ? _0x4e0f0e[0x1]
    : !0x1;
}
function updateTextToHeight(_0x49b540, _0x12c747, _0xf19d89, _0x10155d) {
  var _0x2f7f93 = {
    ExFdD: function (_0x2a0cb0, _0x589331) {
      return _0x2a0cb0 + _0x589331;
    },
    zJAJw: function (_0x359df3, _0x46e7b0) {
      return _0x359df3 + _0x46e7b0;
    },
    MpNjJ: function (_0x7927da, _0x507feb) {
      return _0x7927da + _0x507feb;
    },
    CAKci: "px\x20\x22",
    thxMm: function (_0x4da925, _0x4b8179) {
      return _0x4da925 > _0x4b8179;
    },
    rICCA: "px\x20gameFont",
  };
  for (
    _0x49b540["style"]["font"] = _0x2f7f93["ExFdD"](
      _0x2f7f93["zJAJw"](
        _0x2f7f93["MpNjJ"](_0x12c747, _0x2f7f93["CAKci"]),
        _0xf19d89
      ),
      "\x22"
    );
    _0x2f7f93["thxMm"](_0x49b540["height"], _0x10155d);

  )
    _0x12c747--,
      (_0xf19d89 = _0x49b540["style"]),
      (_0xf19d89["font"] = _0x2f7f93["MpNjJ"](_0x12c747, _0x2f7f93["rICCA"])),
      _0x49b540["setStyle"](_0xf19d89);
}
function updateTextToWidth(_0x1d1eb3, _0x220e1a, _0x204c60, _0x746255) {
  var _0x4ae543 = {
    otuUF: function (_0x1fa6b4, _0x26563b) {
      return _0x1fa6b4 + _0x26563b;
    },
    YSbac: function (_0xb38413, _0x3efcf9) {
      return _0xb38413 + _0x3efcf9;
    },
    aTbIS: function (_0xceecc8, _0x4a66d9) {
      return _0xceecc8 + _0x4a66d9;
    },
    SXcCB: "px\x20\x22",
    ZUfIc: function (_0x2e1565, _0x2dcf41) {
      return _0x2e1565 > _0x2dcf41;
    },
    JtmrQ: function (_0x25af6d, _0x2a6fc3) {
      return _0x25af6d + _0x2a6fc3;
    },
    jsVhp: function (_0x48c3e8, _0x57090a) {
      return _0x48c3e8 + _0x57090a;
    },
  };
  for (
    _0x1d1eb3["style"]["font"] = _0x4ae543["otuUF"](
      _0x4ae543["YSbac"](
        _0x4ae543["aTbIS"](_0x220e1a, _0x4ae543["SXcCB"]),
        _0x204c60
      ),
      "\x22"
    );
    _0x4ae543["ZUfIc"](_0x1d1eb3["width"], _0x746255);

  ) {
    _0x220e1a--;
    var _0x1866ae = _0x1d1eb3["style"];
    _0x1866ae["font"] = _0x4ae543["JtmrQ"](
      _0x4ae543["jsVhp"](
        _0x4ae543["jsVhp"](_0x220e1a, _0x4ae543["SXcCB"]),
        _0x204c60
      ),
      "\x22"
    );
    _0x1d1eb3["setStyle"](_0x1866ae);
  }
}
function CreateBoardSpr(
  _0x3adfc1,
  _0x117ca0,
  _0x5093ac,
  _0x5e5f96,
  _0xe76766,
  _0x59c8b3,
  _0x39c57d,
  _0xd2d340,
  _0xf75564,
  _0x4df7a8
) {
  var _0x194d64 = {
    Eppur:
      "3|9|29|15|1|0|18|30|2|27|6|28|16|20|19|8|4|12|11|26|25|5|14|10|7|21|17|13|24|23|22|31",
    ANmfX: function (_0x7445ea, _0x2d577c) {
      return _0x7445ea === _0x2d577c;
    },
    JGLoN: "4|0|1|5|3|2",
    vLeFY: function (_0x353ab4, _0x398b53) {
      return _0x353ab4(_0x398b53);
    },
    IwZXP: "bmpData.generateTexture",
    qhajd: function (_0xf445b9, _0x316c0e) {
      return _0xf445b9 + _0x316c0e;
    },
    KPgKm: function (_0x3691b7, _0x104882, _0x4cc20c, _0x3ac925) {
      return _0x3691b7(_0x104882, _0x4cc20c, _0x3ac925);
    },
    VuzYQ: function (_0x5a853d, _0x1aad9c) {
      return _0x5a853d - _0x1aad9c;
    },
    EVUxH: function (_0x58e6cb, _0x1d2ed0) {
      return _0x58e6cb + _0x1d2ed0;
    },
    eFkbq: function (_0xda2969, _0x6f8756, _0x152ded, _0x149494, _0x430711) {
      return _0xda2969(_0x6f8756, _0x152ded, _0x149494, _0x430711);
    },
    vxyWC: "pak1",
    FqCFu: "void.png",
    TrIuz: function (_0x156b76, _0x121605) {
      return _0x156b76 / _0x121605;
    },
    mtIQu: function (_0x2f515c, _0x3a82d0) {
      return _0x2f515c / _0x3a82d0;
    },
    AyZVj: function (_0x339fe7, _0x515848, _0x1274ec, _0x53a18c) {
      return _0x339fe7(_0x515848, _0x1274ec, _0x53a18c);
    },
    pBjCY: function (_0x21f06c, _0x48a075) {
      return _0x21f06c < _0x48a075;
    },
    linQe: function (_0x35a3f3, _0x1b8b2f, _0x50bdf2, _0x3b5a9f) {
      return _0x35a3f3(_0x1b8b2f, _0x50bdf2, _0x3b5a9f);
    },
    GgfGZ: function (_0x4551ce, _0x3f7ffe) {
      return _0x4551ce + _0x3f7ffe;
    },
    mhxPr: function (_0x175af7, _0x45c67e) {
      return _0x175af7 * _0x45c67e;
    },
    ilQWK: function (_0x54457d, _0x12d9da) {
      return _0x54457d + _0x12d9da;
    },
    Tjrhp: function (_0x4c1dd1, _0x359ab7, _0x5da01e, _0x3bfb03) {
      return _0x4c1dd1(_0x359ab7, _0x5da01e, _0x3bfb03);
    },
    jWTJc: function (_0x2bb13a, _0x5576b2) {
      return _0x2bb13a < _0x5576b2;
    },
    vjMyx: function (_0x5b3cd5, _0x164a12, _0x1b553c, _0x475786) {
      return _0x5b3cd5(_0x164a12, _0x1b553c, _0x475786);
    },
    UTdns: function (_0x4664c2, _0x4a8d94) {
      return _0x4664c2 + _0x4a8d94;
    },
    WCgSd: function (_0x50c87b, _0x51d124) {
      return _0x50c87b - _0x51d124;
    },
    cNTvH: function (_0x1e01be, _0x478d56) {
      return _0x1e01be === _0x478d56;
    },
    LEbdY: function (_0x2e0ef9, _0x471912) {
      return _0x2e0ef9 + _0x471912;
    },
    hDfEi: function (_0x4f47fd, _0x15fefd) {
      return _0x4f47fd < _0x15fefd;
    },
    fWJAP: function (_0x1b3d10, _0x42b887) {
      return _0x1b3d10 * _0x42b887;
    },
    OKgJZ: function (_0x1651c1, _0x993607) {
      return _0x1651c1 + _0x993607;
    },
    bwudN: function (_0x471d5b, _0x3150bd) {
      return _0x471d5b - _0x3150bd;
    },
    jrjWc: function (_0x2eea34, _0x18cab0) {
      return _0x2eea34 + _0x18cab0;
    },
    pUhwS: function (_0xa43fe0, _0x55844b) {
      return _0xa43fe0 < _0x55844b;
    },
    WgckQ: function (_0x2373d5, _0x20944d) {
      return _0x2373d5 * _0x20944d;
    },
    vzeAr: function (_0x1deb33, _0x37a66c, _0x542279, _0x41469d) {
      return _0x1deb33(_0x37a66c, _0x542279, _0x41469d);
    },
    rSUeS: function (_0x3d6a79, _0x831d1e) {
      return _0x3d6a79 / _0x831d1e;
    },
    aWyhA: function (_0x5c005b, _0x435335) {
      return _0x5c005b === _0x435335;
    },
  };
  var _0x133642 = _0x194d64["Eppur"]["split"]("|"),
    _0x362cd0 = 0x0;
  while ([]) {
    switch (_0x133642[_0x362cd0++]) {
      case "0":
        tmp_sprites["contains"](_0xe76766) ||
          (tmp_sprites[_0xe76766] = game["make"]["sprite"](
            -0x2710,
            -0x2710,
            _0xe76766
          ));
        continue;
      case "1":
        _0x194d64["ANmfX"](void 0x0, _0x4df7a8) && (_0x4df7a8 = _0x5e5f96);
        continue;
      case "2":
        var _0x5d4910, _0x146548;
        continue;
      case "3":
        var _0x2333ed = {
          aMlzy: _0x194d64["JGLoN"],
          GznHd: function (_0x4aae0e, _0x459c8b) {
            return _0x194d64["vLeFY"](_0x4aae0e, _0x459c8b);
          },
          EsshD: _0x194d64["IwZXP"],
        };
        continue;
      case "4":
        _0x5093ac = _0x194d64["qhajd"](0x0, _0x5093ac);
        continue;
      case "5":
        _0x295fef["draw"](
          _0x194d64["KPgKm"](
            getSpriteFrameWithinAtlas,
            tmp_sprites[_0xe76766],
            _0x59c8b3,
            0x6
          ),
          0x0,
          _0x194d64["VuzYQ"](_0x194d64["EVUxH"](0x0, _0x5e5f96), _0x146548)
        );
        continue;
      case "6":
        _0x146548 = _0x194d64["KPgKm"](
          getSpriteFrameWithinAtlas,
          tmp_sprites[_0xe76766],
          _0x59c8b3,
          0x0
        )["height"];
        continue;
      case "7":
        _0x59c8b3 = _0x194d64["eFkbq"](
          makeSprite,
          0x0,
          0x0,
          _0x194d64["vxyWC"],
          _0x194d64["FqCFu"]
        );
        continue;
      case "8":
        var _0x3e658d = _0x194d64["VuzYQ"](
            _0x194d64["TrIuz"](_0x5093ac, _0x5d4910),
            0x2
          ),
          _0x212ec4 = _0x194d64["VuzYQ"](
            _0x194d64["mtIQu"](_0x5e5f96, _0x146548),
            0x2
          );
        continue;
      case "9":
        _0x194d64["ANmfX"](void 0x0, _0x39c57d) && (_0x39c57d = 0x0);
        continue;
      case "10":
        _0x295fef["draw"](
          _0x194d64["AyZVj"](
            getSpriteFrameWithinAtlas,
            tmp_sprites[_0xe76766],
            _0x59c8b3,
            0x8
          ),
          _0x194d64["VuzYQ"](_0x5093ac, _0x5d4910),
          _0x194d64["VuzYQ"](_0x194d64["EVUxH"](0x0, _0x5e5f96), _0x146548)
        );
        continue;
      case "11":
        for (
          var _0xd46771 = 0x0;
          _0x194d64["pBjCY"](_0xd46771, _0x3e658d);
          _0xd46771++
        )
          _0x295fef["draw"](
            _0x194d64["linQe"](
              getSpriteFrameWithinAtlas,
              tmp_sprites[_0xe76766],
              _0x59c8b3,
              0x1
            ),
            _0x194d64["GgfGZ"](
              0x0,
              _0x194d64["mhxPr"](_0x5d4910, _0x194d64["ilQWK"](_0xd46771, 0x1))
            ),
            0x0
          );
        continue;
      case "12":
        _0x295fef["draw"](
          _0x194d64["Tjrhp"](
            getSpriteFrameWithinAtlas,
            tmp_sprites[_0xe76766],
            _0x59c8b3,
            0x0
          ),
          0x0,
          0x0
        );
        continue;
      case "13":
        _0x59c8b3["x"] = _0x3adfc1;
        continue;
      case "14":
        for (
          _0xd46771 = 0x0;
          _0x194d64["jWTJc"](_0xd46771, _0x3e658d);
          _0xd46771++
        )
          _0x295fef["draw"](
            _0x194d64["vjMyx"](
              getSpriteFrameWithinAtlas,
              tmp_sprites[_0xe76766],
              _0x59c8b3,
              0x7
            ),
            _0x194d64["ilQWK"](
              0x0,
              _0x194d64["mhxPr"](_0x5d4910, _0x194d64["UTdns"](_0xd46771, 0x1))
            ),
            _0x194d64["WCgSd"](_0x194d64["UTdns"](0x0, _0x5e5f96), _0x146548)
          );
        continue;
      case "15":
        _0x194d64["cNTvH"](void 0x0, _0xf75564) && (_0xf75564 = _0x5093ac);
        continue;
      case "16":
        _0x5e5f96 = _0x194d64["mhxPr"](
          Math["floor"](
            _0x194d64["LEbdY"](_0x194d64["mtIQu"](_0x5e5f96, _0x146548), 0.5)
          ),
          _0x146548
        );
        continue;
      case "17":
        _0x295fef["generateTexture"](
          _0x5e5f96,
          function (_0x4e0080) {
            var _0x47a961 = _0x2333ed["aMlzy"]["split"]("|"),
              _0x8eeb37 = 0x0;
            while ([]) {
              switch (_0x47a961[_0x8eeb37++]) {
                case "0":
                  this["sprite"]["loadTexture"](_0x4e0080);
                  continue;
                case "1":
                  this["sprite"]["scale"]["set"](0x1);
                  continue;
                case "2":
                  this["sprite"]["anchor"]["setTo"](
                    this["anchorX"],
                    this["anchorY"]
                  );
                  continue;
                case "3":
                  this["sprite"]["height"] = this["scaledH"];
                  continue;
                case "4":
                  _0x2333ed["GznHd"](LOG, _0x2333ed["EsshD"]);
                  continue;
                case "5":
                  this["sprite"]["width"] = this["scaledW"];
                  continue;
              }
              break;
            }
          },
          {
            sprite: _0x59c8b3,
            anchorX: _0x39c57d,
            anchorY: _0xd2d340,
            scaledW: _0xf75564,
            scaledH: _0x4df7a8,
          }
        );
        continue;
      case "18":
        _width = _0x5093ac;
        continue;
      case "19":
        _0x295fef["smoothed"] = !0x1;
        continue;
      case "20":
        var _0x295fef = game["make"]["bitmapData"](_0x5093ac, _0x5e5f96);
        continue;
      case "21":
        _0x5e5f96 = game["rnd"]["uuid"]();
        continue;
      case "22":
        _0x295fef = null;
        continue;
      case "23":
        _0x295fef["destroy"]();
        continue;
      case "24":
        _0x59c8b3["y"] = _0x117ca0;
        continue;
      case "25":
        for (
          var _0x34d93a = 0x0;
          _0x194d64["hDfEi"](_0x34d93a, _0x212ec4);
          _0x34d93a++
        )
          for (
            _0x295fef["draw"](
              _0x194d64["vjMyx"](
                getSpriteFrameWithinAtlas,
                tmp_sprites[_0xe76766],
                _0x59c8b3,
                0x3
              ),
              0x0,
              _0x194d64["LEbdY"](
                0x0,
                _0x194d64["fWJAP"](
                  _0x146548,
                  _0x194d64["OKgJZ"](_0x34d93a, 0x1)
                )
              )
            ),
              _0x295fef["draw"](
                _0x194d64["vjMyx"](
                  getSpriteFrameWithinAtlas,
                  tmp_sprites[_0xe76766],
                  _0x59c8b3,
                  0x5
                ),
                _0x194d64["bwudN"](_0x5093ac, _0x5d4910),
                _0x194d64["jrjWc"](
                  0x0,
                  _0x194d64["fWJAP"](
                    _0x146548,
                    _0x194d64["jrjWc"](_0x34d93a, 0x1)
                  )
                )
              ),
              _0xd46771 = 0x0;
            _0x194d64["pUhwS"](_0xd46771, _0x3e658d);
            _0xd46771++
          )
            _0x295fef["draw"](
              _0x194d64["vjMyx"](
                getSpriteFrameWithinAtlas,
                tmp_sprites[_0xe76766],
                _0x59c8b3,
                0x4
              ),
              _0x194d64["jrjWc"](
                0x0,
                _0x194d64["WgckQ"](
                  _0x5d4910,
                  _0x194d64["jrjWc"](_0xd46771, 0x1)
                )
              ),
              _0x194d64["jrjWc"](
                0x0,
                _0x194d64["WgckQ"](
                  _0x146548,
                  _0x194d64["jrjWc"](_0x34d93a, 0x1)
                )
              )
            );
        continue;
      case "26":
        _0x295fef["draw"](
          _0x194d64["vzeAr"](
            getSpriteFrameWithinAtlas,
            tmp_sprites[_0xe76766],
            _0x59c8b3,
            0x2
          ),
          _0x194d64["bwudN"](_0x5093ac, _0x5d4910),
          0x0
        );
        continue;
      case "27":
        _0x5d4910 = _0x194d64["vzeAr"](
          getSpriteFrameWithinAtlas,
          tmp_sprites[_0xe76766],
          _0x59c8b3,
          0x0
        )["width"];
        continue;
      case "28":
        _0x5093ac = _0x194d64["WgckQ"](
          Math["floor"](
            _0x194d64["jrjWc"](_0x194d64["rSUeS"](_0x5093ac, _0x5d4910), 0.5)
          ),
          _0x5d4910
        );
        continue;
      case "29":
        _0x194d64["aWyhA"](void 0x0, _0xd2d340) && (_0xd2d340 = 0x0);
        continue;
      case "30":
        _height = _0x5e5f96;
        continue;
      case "31":
        return _0x59c8b3;
    }
    break;
  }
}
function CreateDialogSpr(
  _0x1f3552,
  _0x4984f8,
  _0x233f1e,
  _0x1a4f8c,
  _0x17f145,
  _0x42fb80,
  _0x3ce1f2,
  _0x2ee4ce,
  _0x5661ce,
  _0x447d2e
) {
  var _0x129418 = {
    HlPBu: "0|11|18|13|8|12|5|19|21|6|3|16|7|2|20|10|4|14|15|17|1|9",
    eFqEr: "4|1|0|3|2",
    idSDK: function (_0x441d9b, _0x261322) {
      return _0x441d9b(_0x261322);
    },
    hNVJo: "bmpData.generateTexture",
    cLDVf: function (_0xaa9c53, _0x18d012, _0x177ea3, _0x13c0f1) {
      return _0xaa9c53(_0x18d012, _0x177ea3, _0x13c0f1);
    },
    eTkgO: function (_0x10d54c, _0x3b5beb) {
      return _0x10d54c - _0x3b5beb;
    },
    jGZmb: function (_0xc3cbb3, _0xd85d92) {
      return _0xc3cbb3 + _0xd85d92;
    },
    ZfcvK: function (_0x3c1c63, _0x22b8b5, _0x41962d, _0x477121) {
      return _0x3c1c63(_0x22b8b5, _0x41962d, _0x477121);
    },
    DFcYu: function (_0x8037bb, _0x511027) {
      return _0x8037bb - _0x511027;
    },
    RTjnl: function (_0x1a4095, _0x20aa19) {
      return _0x1a4095 * _0x20aa19;
    },
    uRqgr: function (_0x59d9ac, _0x394d44) {
      return _0x59d9ac === _0x394d44;
    },
    PHYEk: function (_0x52021b, _0x144e7b) {
      return _0x52021b === _0x144e7b;
    },
    eTqgH: function (_0x509a0d, _0x4028dd, _0x53260e, _0xd5e180) {
      return _0x509a0d(_0x4028dd, _0x53260e, _0xd5e180);
    },
    saTFF: function (_0x1b86ef, _0x11de68, _0xd1a789, _0x3a3d20, _0x2e1dcf) {
      return _0x1b86ef(_0x11de68, _0xd1a789, _0x3a3d20, _0x2e1dcf);
    },
    LdKGb: "pak1",
    RnAkM: "void.png",
    XMyir: function (_0x1540de, _0x5e25e0, _0x17ce52, _0x16d622) {
      return _0x1540de(_0x5e25e0, _0x17ce52, _0x16d622);
    },
  };
  var _0x23cfae = _0x129418["HlPBu"]["split"]("|"),
    _0x4c9fa0 = 0x0;
  while ([]) {
    switch (_0x23cfae[_0x4c9fa0++]) {
      case "0":
        var _0x250b78 = {
          FjxrE: _0x129418["eFqEr"],
          jrbda: function (_0x1bccde, _0x561ace) {
            return _0x129418["idSDK"](_0x1bccde, _0x561ace);
          },
          GYAMH: _0x129418["hNVJo"],
        };
        continue;
      case "1":
        _0x233f1e = null;
        continue;
      case "2":
        _0x233f1e["draw"](
          _0x129418["cLDVf"](
            getSpriteFrameWithinAtlas,
            tmp_sprites[_0x17f145],
            _0x42fb80,
            0x2
          ),
          0x0,
          _0x129418["eTkgO"](_0x129418["jGZmb"](0x0, _0x1a4f8c), _0x4775b8)
        );
        continue;
      case "3":
        _0x233f1e["smoothed"] = !0x1;
        continue;
      case "4":
        _0x233f1e["generateTexture"](
          _0x1a4f8c,
          function (_0x4b2ffb) {
            var _0x5922a8 = _0x250b78["FjxrE"]["split"]("|"),
              _0x59b586 = 0x0;
            while ([]) {
              switch (_0x5922a8[_0x59b586++]) {
                case "0":
                  this["sprite"]["width"] = this["scaledW"];
                  continue;
                case "1":
                  this["sprite"]["loadTexture"](_0x4b2ffb);
                  continue;
                case "2":
                  this["sprite"]["anchor"]["setTo"](
                    this["anchorX"],
                    this["anchorY"]
                  );
                  continue;
                case "3":
                  this["sprite"]["height"] = this["scaledH"];
                  continue;
                case "4":
                  _0x250b78["jrbda"](LOG, _0x250b78["GYAMH"]);
                  continue;
              }
              break;
            }
          },
          {
            sprite: _0x42fb80,
            anchorX: _0x3ce1f2,
            anchorY: _0x2ee4ce,
            scaledW: _0x5661ce,
            scaledH: _0x447d2e,
          }
        );
        continue;
      case "5":
        tmp_sprites["contains"](_0x17f145) ||
          (tmp_sprites[_0x17f145] = game["make"]["sprite"](
            -0x2710,
            -0x2710,
            _0x17f145
          ));
        continue;
      case "6":
        _0x233f1e = game["make"]["bitmapData"](_0x233f1e, _0x1a4f8c);
        continue;
      case "7":
        _0x233f1e["draw"](
          _0x129418["ZfcvK"](
            getSpriteFrameWithinAtlas,
            tmp_sprites[_0x17f145],
            _0x42fb80,
            0x1
          ),
          0x0,
          _0x129418["jGZmb"](0x0, _0x4775b8),
          _0xdd0d7,
          _0x129418["DFcYu"](_0x1a4f8c, _0x129418["RTjnl"](0x2, _0x4775b8))
        );
        continue;
      case "8":
        _0x129418["uRqgr"](void 0x0, _0x5661ce) && (_0x5661ce = _0x233f1e);
        continue;
      case "9":
        return _0x42fb80;
      case "10":
        _0x1a4f8c = game["rnd"]["uuid"]();
        continue;
      case "11":
        var _0xdd0d7, _0x4775b8;
        continue;
      case "12":
        _0x129418["uRqgr"](void 0x0, _0x447d2e) && (_0x447d2e = _0x1a4f8c);
        continue;
      case "13":
        _0x129418["PHYEk"](void 0x0, _0x2ee4ce) && (_0x2ee4ce = 0x0);
        continue;
      case "14":
        _0x42fb80["x"] = _0x1f3552;
        continue;
      case "15":
        _0x42fb80["y"] = _0x4984f8;
        continue;
      case "16":
        _0x233f1e["draw"](
          _0x129418["ZfcvK"](
            getSpriteFrameWithinAtlas,
            tmp_sprites[_0x17f145],
            _0x42fb80,
            0x0
          ),
          0x0,
          0x0
        );
        continue;
      case "17":
        _0x233f1e["destroy"]();
        continue;
      case "18":
        _0x129418["PHYEk"](void 0x0, _0x3ce1f2) && (_0x3ce1f2 = 0x0);
        continue;
      case "19":
        _0xdd0d7 = _0x129418["eTqgH"](
          getSpriteFrameWithinAtlas,
          tmp_sprites[_0x17f145],
          _0x42fb80,
          0x0
        )["width"];
        continue;
      case "20":
        _0x42fb80 = _0x129418["saTFF"](
          makeSprite,
          0x0,
          0x0,
          _0x129418["LdKGb"],
          _0x129418["RnAkM"]
        );
        continue;
      case "21":
        _0x4775b8 = _0x129418["XMyir"](
          getSpriteFrameWithinAtlas,
          tmp_sprites[_0x17f145],
          _0x42fb80,
          0x0
        )["height"];
        continue;
    }
    break;
  }
}
function CreateButtonSpr(
  _0x5f0e03,
  _0x829ae,
  _0x2eb5fa,
  _0x102088,
  _0x1a1afe,
  _0x3f7879,
  _0x453e4f,
  _0x58c7b8,
  _0x7580fd
) {
  var _0x67d0ca = {
    cLlit: "8|4|14|6|5|3|2|0|19|22|13|1|20|17|24|21|23|18|15|10|11|9|16|7|12",
    nmRuH: function (_0x2cae47, _0x14e559) {
      return _0x2cae47 + _0x14e559;
    },
    XwfBg: "_0.png",
    GJckC: function (_0x509a0f, _0x3849f2) {
      return _0x509a0f - _0x3849f2;
    },
    CeBnf: function (_0x2bd03c, _0x55de28) {
      return _0x2bd03c / _0x55de28;
    },
    EJQMp: function (_0x29b4b2, _0x4f204a) {
      return _0x29b4b2 + _0x4f204a;
    },
    vytGY: function (_0x2ea305, _0x377696) {
      return _0x2ea305 === _0x377696;
    },
    dnRCW: function (_0x3ab8e9, _0x407b29) {
      return _0x3ab8e9 === _0x407b29;
    },
    lggdi: function (_0x598664, _0x3b6b1d) {
      return _0x598664 * _0x3b6b1d;
    },
    zdvUo: function (_0x42aa7a, _0xd55274) {
      return _0x42aa7a * _0xd55274;
    },
    jixnu: function (_0x2546f1, _0x36ed85) {
      return _0x2546f1 < _0x36ed85;
    },
    JmLXD: function (_0x12b6b3, _0x245e93, _0x7ada5a, _0x2db404) {
      return _0x12b6b3(_0x245e93, _0x7ada5a, _0x2db404);
    },
    zEIbO: function (_0x665dcb, _0x31632e) {
      return _0x665dcb + _0x31632e;
    },
    inDBK: function (_0x326fd3, _0x4a1a62) {
      return _0x326fd3 + _0x4a1a62;
    },
    WJrqA: function (_0x19388d, _0x4ef3a4, _0x51db1b, _0x375cff, _0x3a3b68) {
      return _0x19388d(_0x4ef3a4, _0x51db1b, _0x375cff, _0x3a3b68);
    },
    fHZbN: "pak1",
    xBJcC: "void.png",
  };
  var _0x505874 = _0x67d0ca["cLlit"]["split"]("|"),
    _0x21dfad = 0x0;
  while ([]) {
    switch (_0x505874[_0x21dfad++]) {
      case "0":
        _0x1ae7cb = game["cache"]["getFrameByName"](
          _0x102088,
          _0x67d0ca["nmRuH"](_0x1a1afe, _0x67d0ca["XwfBg"])
        )["width"];
        continue;
      case "1":
        var _0x48fa9a = _0x67d0ca["GJckC"](
            _0x67d0ca["CeBnf"](_0x2eb5fa, _0x1ae7cb),
            0x2
          ),
          _0x4f5c26 = _0x67d0ca["EJQMp"](0x0, _0x2eb5fa);
        continue;
      case "2":
        var _0x1ae7cb, _0x29f28c;
        continue;
      case "3":
        _width = _0x2eb5fa;
        continue;
      case "4":
        _0x67d0ca["vytGY"](void 0x0, _0x453e4f) && (_0x453e4f = 0x0);
        continue;
      case "5":
        tmp_sprites["contains"](_0x102088) ||
          (tmp_sprites[_0x102088] = game["make"]["sprite"](
            -0x2710,
            -0x2710,
            _0x102088
          ));
        continue;
      case "6":
        _0x67d0ca["dnRCW"](void 0x0, _0x7580fd) && (_0x7580fd = 0x1);
        continue;
      case "7":
        _0xb00155 = null;
        continue;
      case "8":
        _0x67d0ca["dnRCW"](void 0x0, _0x3f7879) && (_0x3f7879 = 0x0);
        continue;
      case "9":
        _0x1a1afe["height"] = _0x67d0ca["lggdi"](_0x29f28c, _0x7580fd);
        continue;
      case "10":
        _0x1a1afe["y"] = _0x829ae;
        continue;
      case "11":
        _0x1a1afe["width"] = _0x67d0ca["zdvUo"](_0x2eb5fa, _0x58c7b8);
        continue;
      case "12":
        return _0x1a1afe;
      case "13":
        _0xb00155["smoothed"] = !0x1;
        continue;
      case "14":
        _0x67d0ca["dnRCW"](void 0x0, _0x58c7b8) && (_0x58c7b8 = 0x1);
        continue;
      case "15":
        _0x1a1afe["x"] = _0x5f0e03;
        continue;
      case "16":
        _0xb00155["destroy"]();
        continue;
      case "17":
        for (
          var _0x1fd09b = 0x0;
          _0x67d0ca["jixnu"](_0x1fd09b, _0x48fa9a);
          _0x1fd09b++
        )
          _0xb00155["draw"](
            _0x67d0ca["JmLXD"](
              getSpriteFrameWithinAtlas,
              tmp_sprites[_0x102088],
              _0x1a1afe,
              0x1
            ),
            _0x67d0ca["EJQMp"](
              0x0,
              _0x67d0ca["zdvUo"](_0x1ae7cb, _0x67d0ca["zEIbO"](_0x1fd09b, 0x1))
            ),
            0x0
          );
        continue;
      case "18":
        _0xb00155["generateTexture"](
          _0x102088,
          function (_0x5e8a43) {
            this["sprite"]["loadTexture"](_0x5e8a43);
            this["sprite"]["anchor"]["setTo"](this["anchorX"], this["anchorY"]);
            this["sprite"]["scale"]["setTo"](this["scaleX"], this["scaleY"]);
          },
          {
            sprite: _0x1a1afe,
            anchorX: _0x3f7879,
            anchorY: _0x453e4f,
            scaleX: _0x58c7b8,
            scaleY: _0x7580fd,
          }
        );
        continue;
      case "19":
        _0x29f28c = game["cache"]["getFrameByName"](
          _0x102088,
          _0x67d0ca["inDBK"](_0x1a1afe, _0x67d0ca["XwfBg"])
        )["height"];
        continue;
      case "20":
        _0xb00155["draw"](
          _0x67d0ca["JmLXD"](
            getSpriteFrameWithinAtlas,
            tmp_sprites[_0x102088],
            _0x1a1afe,
            0x0
          ),
          0x0,
          0x0
        );
        continue;
      case "21":
        _0x1a1afe = _0x67d0ca["WJrqA"](
          makeSprite,
          0x0,
          0x0,
          _0x67d0ca["fHZbN"],
          _0x67d0ca["xBJcC"]
        );
        continue;
      case "22":
        var _0xb00155 = game["make"]["bitmapData"](_0x2eb5fa, _0x29f28c);
        continue;
      case "23":
        _0x102088 = game["rnd"]["uuid"]();
        continue;
      case "24":
        _0xb00155["draw"](
          _0x67d0ca["JmLXD"](
            getSpriteFrameWithinAtlas,
            tmp_sprites[_0x102088],
            _0x1a1afe,
            0x2
          ),
          _0x67d0ca["GJckC"](_0x4f5c26, _0x1ae7cb),
          0x0
        );
        continue;
    }
    break;
  }
}
function getSpriteFrame(_0x101ffa, _0x5e38e0) {
  _0x101ffa["frame"] = _0x5e38e0;
  return _0x101ffa;
}
function getSpriteFrameWithinAtlas(_0x5c872a, _0x38425f, _0x4c6f62) {
  var _0x151e0a = {
    KpJBh: function (_0x68970c, _0x15a3d7) {
      return _0x68970c + _0x15a3d7;
    },
    NIEbl: function (_0x20be86, _0x1e0a1c) {
      return _0x20be86 + _0x1e0a1c;
    },
    NiEhl: function (_0x5106e0, _0x288e17) {
      return _0x5106e0 + _0x288e17;
    },
    szXeD: ".png",
  };
  _0x5c872a["frameName"] = _0x151e0a["KpJBh"](
    _0x151e0a["NIEbl"](_0x151e0a["NiEhl"](_0x38425f, "_"), _0x4c6f62),
    _0x151e0a["szXeD"]
  );
  return _0x5c872a;
}
function makeSprite(_0x599988, _0x9ae741, _0x51b54a, _0x3b20b3) {
  var _0x24ca35 = {
    uVhJy: function (_0x4582cc, _0xc48aaf) {
      return _0x4582cc || _0xc48aaf;
    },
  };
  return (_0x51b54a = game["make"]["sprite"](
    _0x599988,
    _0x9ae741,
    _0x51b54a,
    _0x24ca35["uVhJy"](_0x3b20b3, 0x0)
  ));
}
function addSprite(_0x2f9ba9, _0x3f4b7e, _0x56a0b0, _0x59a456) {
  var _0x343529 = {
    NNYfw: function (_0x2b83c4, _0x322e5b) {
      return _0x2b83c4 || _0x322e5b;
    },
  };
  return (_0x56a0b0 = game["add"]["sprite"](
    _0x2f9ba9,
    _0x3f4b7e,
    _0x56a0b0,
    _0x343529["NNYfw"](_0x59a456, 0x0)
  ));
}
function leadingZero(_0x5eeac6, _0x1d3d5a) {
  var _0x19141d = {
    fKxvp: function (_0x5ce795, _0x17e085) {
      return _0x5ce795 + _0x17e085;
    },
    IuBmD: function (_0x23b97e, _0x2293a4) {
      return _0x23b97e < _0x2293a4;
    },
    fCPyJ: function (_0x24e5ac, _0x2348b3) {
      return _0x24e5ac + _0x2348b3;
    },
  };
  for (
    var _0x496008 = _0x19141d["fKxvp"]("", _0x5eeac6);
    _0x19141d["IuBmD"](_0x496008["length"], _0x1d3d5a);

  )
    _0x496008 = _0x19141d["fCPyJ"]("0", _0x496008);
  return _0x496008;
}
function SetPoingScaleTween(_0x219c02, _0x357e4c, _0x25752a, _0xb24752) {
  var _0x302965 = {
    PPRnP: "4|5|1|0|6|3|2",
    JPJFd: function (_0x1a2b8d, _0x36b23c) {
      return _0x1a2b8d === _0x36b23c;
    },
    cVZJJ: function (_0x254e98, _0x1789c4) {
      return _0x254e98 * _0x1789c4;
    },
    ARQur: function (_0x186305, _0x4c7de9) {
      return _0x186305 != _0x4c7de9;
    },
    ryWiF: function (_0xe34ee0, _0x54b1a4) {
      return _0xe34ee0 * _0x54b1a4;
    },
    lSGwo: function (_0x4686ea, _0x26f769) {
      return _0x4686ea > _0x26f769;
    },
    qeUeY: function (_0xc25841, _0xa99ba0) {
      return _0xc25841 === _0xa99ba0;
    },
  };
  var _0x3e1f03 = _0x302965["PPRnP"]["split"]("|"),
    _0x4efa2e = 0x0;
  while ([]) {
    switch (_0x3e1f03[_0x4efa2e++]) {
      case "0":
        _0x302965["JPJFd"](void 0x0, _0x25752a) && (_0x25752a = 0x0);
        continue;
      case "1":
        _0x302965["JPJFd"](void 0x0, _0x357e4c) && (_0x357e4c = 0x96);
        continue;
      case "2":
        game["add"]
          ["tween"](_0x219c02["scale"])
          ["to"](
            {
              x: _0x302965["cVZJJ"](_0x31e164, _0x17cfc4 ? -0x1 : 0x1),
              y: _0x302965["cVZJJ"](_0x31e164, _0x1e5f05 ? -0x1 : 0x1),
            },
            _0x357e4c,
            Phaser["Easing"]["Quadratic"]["Out"],
            !0x0,
            _0x25752a,
            0x0
          )
          ["onStart"]["add"](
            function () {
              _0x243c2e["ACJWW"](null, this["callbackOnStart"]) &&
                this["callbackOnStart"]();
              this["obj"]["scale"]["setTo"](
                _0x243c2e["Kskom"](
                  _0x243c2e["OkuzV"](1.3, _0x31e164),
                  _0x17cfc4 ? -0x1 : 0x1
                ),
                _0x243c2e["OkuzV"](
                  _0x243c2e["EuCqe"](1.3, _0x31e164),
                  _0x1e5f05 ? -0x1 : 0x1
                )
              );
            },
            { obj: _0x219c02, callbackOnStart: _0xb24752 }
          );
        continue;
      case "3":
        var _0x31e164 = _0x219c02["scale"]["x"];
        continue;
      case "4":
        var _0x243c2e = {
          ACJWW: function (_0x16c471, _0x4d15fc) {
            return _0x302965["ARQur"](_0x16c471, _0x4d15fc);
          },
          Kskom: function (_0x5eb556, _0x4b4614) {
            return _0x302965["cVZJJ"](_0x5eb556, _0x4b4614);
          },
          OkuzV: function (_0x5db120, _0x58b17c) {
            return _0x302965["cVZJJ"](_0x5db120, _0x58b17c);
          },
          EuCqe: function (_0x24dd9c, _0x5b2b9a) {
            return _0x302965["ryWiF"](_0x24dd9c, _0x5b2b9a);
          },
        };
        continue;
      case "5":
        var _0x17cfc4 = _0x302965["lSGwo"](0x0, _0x219c02["scale"]["x"]),
          _0x1e5f05 = _0x302965["lSGwo"](0x0, _0x219c02["scale"]["y"]);
        continue;
      case "6":
        _0x302965["qeUeY"](void 0x0, _0xb24752) && (_0xb24752 = null);
        continue;
    }
    break;
  }
}
function CreateButtonWithText(
  _0x3c9b78,
  _0x4f0fed,
  _0x1a5f7b,
  _0x1c0a95,
  _0xb08d4b,
  _0x52ee10,
  _0x2170af,
  _0x4425c9,
  _0x3e3b1e,
  _0x3d3d3f
) {
  var _0x5a88e8 = {
    pvjDP: "12|7|11|13|2|1|9|5|4|0|6|8|15|14|16|10|3",
    yIgSf: "pak1",
    FRRgI: function (_0x58892d, _0x186198) {
      return _0x58892d + _0x186198;
    },
    iGDjE: "px\x20gameFont",
    zzmtp: function (_0x5ed0eb, _0xf5b8e4) {
      return _0x5ed0eb != _0xf5b8e4;
    },
    cMLDY: function (_0x17b0d0, _0x2708ee) {
      return _0x17b0d0 === _0x2708ee;
    },
    dXGwO: "#FFFFFF",
    hDPJL: function (_0x531682, _0x75f106) {
      return _0x531682 === _0x75f106;
    },
    KeNFg: "#000000",
  };
  var _0x4e8379 = _0x5a88e8["pvjDP"]["split"]("|"),
    _0x52cc92 = 0x0;
  while ([]) {
    switch (_0x4e8379[_0x52cc92++]) {
      case "0":
        _0x52ee10["anchor"]["setTo"](0.5, 0.5);
        continue;
      case "1":
        _0x1a5f7b["anchor"]["set"](0.5);
        continue;
      case "2":
        _0x1a5f7b = _0x3c9b78["create"](
          _0x1a5f7b,
          _0x1c0a95,
          _0x5a88e8["yIgSf"],
          _0xb08d4b
        );
        continue;
      case "3":
        return _0x1a5f7b;
      case "4":
        _0x52ee10 = game["add"]["text"](0x1, 0x0, _0x52ee10, {
          font: _0x5a88e8["FRRgI"](_0x3d3d3f, _0x5a88e8["iGDjE"]),
          fill: _0x4425c9,
        });
        continue;
      case "5":
        _0x5a88e8["zzmtp"](null, _0x2170af) &&
          ((_0x3c9b78 = _0x3c9b78["create"](
            0x0,
            0x0,
            _0x5a88e8["yIgSf"],
            _0x2170af
          )),
          _0x3c9b78["anchor"]["set"](0.5),
          _0x1a5f7b["addChild"](_0x3c9b78),
          (_0x1a5f7b["btnHighlighted"] = _0x3c9b78),
          (_0x3c9b78["visible"] = !0x1));
        continue;
      case "6":
        _0x52ee10["shadowOffsetX"] = 0x2;
        continue;
      case "7":
        _0x5a88e8["cMLDY"](void 0x0, _0x4425c9) &&
          (_0x4425c9 = _0x5a88e8["dXGwO"]);
        continue;
      case "8":
        _0x52ee10["shadowOffsetY"] = 0x2;
        continue;
      case "9":
        _0x4f0fed["addChild"](_0x1a5f7b);
        continue;
      case "10":
        _0x1a5f7b["txtCaption"] = _0x52ee10;
        continue;
      case "11":
        _0x5a88e8["hDPJL"](void 0x0, _0x3e3b1e) &&
          (_0x3e3b1e = _0x5a88e8["KeNFg"]);
        continue;
      case "12":
        _0x5a88e8["hDPJL"](void 0x0, _0x2170af) && (_0x2170af = null);
        continue;
      case "13":
        _0x5a88e8["hDPJL"](void 0x0, _0x3d3d3f) && (_0x3d3d3f = 0x19);
        continue;
      case "14":
        _0x52ee10["shadowFill"] = _0x3e3b1e;
        continue;
      case "15":
        _0x52ee10["shadowColor"] = _0x3e3b1e;
        continue;
      case "16":
        _0x1a5f7b["addChild"](_0x52ee10);
        continue;
    }
    break;
  }
}
function SetTextColor(_0x4e9345, _0x383400, _0xde0986) {
  _0x4e9345["tint"] = _0x383400;
}
function wiggle(_0x25b288, _0x255db7, _0xd9c53f) {
  var _0x2447a6 = {
    lCLQu: function (_0x2f4206, _0x5bd95f) {
      return _0x2f4206 * _0x5bd95f;
    },
    OWuvs: function (_0x5184f6, _0x440517) {
      return _0x5184f6 + _0x440517;
    },
    KKOya: function (_0x48093e, _0x38aef5) {
      return _0x48093e * _0x38aef5;
    },
    hYdGX: function (_0x319307, _0x1be715) {
      return _0x319307 * _0x1be715;
    },
    gqBHJ: function (_0x5d9d66, _0x301cd1) {
      return _0x5d9d66 / _0x301cd1;
    },
    GlXEg: function (_0x383b96, _0x30795c) {
      return _0x383b96 * _0x30795c;
    },
    LoObU: function (_0x3c98a1, _0x4017d3) {
      return _0x3c98a1 * _0x4017d3;
    },
  };
  _0xd9c53f = _0x2447a6["lCLQu"](
    _0x25b288,
    _0x2447a6["OWuvs"](
      _0x2447a6["KKOya"](_0x2447a6["hYdGX"](0x2, Math["PI"]), _0xd9c53f),
      _0x2447a6["gqBHJ"](Math["PI"], 0x2)
    )
  );
  return _0x2447a6["GlXEg"](
    Math["sin"](
      _0x2447a6["GlXEg"](
        _0x2447a6["LoObU"](_0x2447a6["LoObU"](_0x25b288, Math["PI"]), 0x2),
        _0x255db7
      )
    ),
    Math["cos"](_0xd9c53f)
  );
}
function MoveSpriteBezier(
  _0x53cdec,
  _0x163c15,
  _0x51f0fc,
  _0xa2e73,
  _0x475e65,
  _0x9f8eb
) {
  var _0x4fdb60 = {
    PUiiS: "15|4|17|12|3|19|8|5|11|7|20|0|2|16|1|14|13|18|10|6|9",
    DNlIo: function (_0x9c65ee, _0x1896dd) {
      return _0x9c65ee > _0x1896dd;
    },
    xmSvQ: function (_0x19a1f5, _0x2cf8f0) {
      return _0x19a1f5 * _0x2cf8f0;
    },
    UXtfO: function (_0x24530e, _0x566db6) {
      return _0x24530e + _0x566db6;
    },
    puUXs: function (_0x1db05b, _0x21a475) {
      return _0x1db05b / _0x21a475;
    },
    SAKLa: function (_0x1d05b6, _0x555962) {
      return _0x1d05b6(_0x555962);
    },
    xUpSQ: function (_0x1ec90c, _0x13ff9a) {
      return _0x1ec90c + _0x13ff9a;
    },
    QXOIr: "coords.lenght\x20=\x20",
    jsxrB: function (_0x53ee51, _0x5b63eb) {
      return _0x53ee51 != _0x5b63eb;
    },
    IAtmO: function (_0x50b5ef, _0x4cc492) {
      return _0x50b5ef(_0x4cc492);
    },
    CQOHl: function (_0x537585, _0x146f17) {
      return _0x537585 + _0x146f17;
    },
    qURnM: function (_0x1199cd, _0x3d8fd4) {
      return _0x1199cd / _0x3d8fd4;
    },
  };
  var _0x486a9a = _0x4fdb60["PUiiS"]["split"]("|"),
    _0x3819b2 = 0x0;
  while ([]) {
    switch (_0x486a9a[_0x3819b2++]) {
      case "0":
        tmpCircle1["y"] = tmpLineNormal1["end"]["y"];
        continue;
      case "1":
        _0x4554f8 = [];
        continue;
      case "2":
        tmpCircle2["x"] = tmpLineNormal2["end"]["x"];
        continue;
      case "3":
        tmpLine["end"]["y"] = _0x51f0fc;
        continue;
      case "4":
        tmpLine["start"]["x"] = _0x53cdec["world"]["x"];
        continue;
      case "5":
        _0x4fdb60["DNlIo"](0x5, _0x4554f8["length"]) &&
          ((_0x4554f8[0x4] = []),
          (_0x4554f8[0x4][0x0] = _0x4554f8[0x3][0x0]),
          (_0x4554f8[0x4][0x1] = _0x4554f8[0x3][0x1]));
        continue;
      case "6":
        _0x4554f8 = game["add"]
          ["tween"](_0x53cdec["position"])
          ["to"](
            {
              x: [
                _0x4554f8[0x0]["x"],
                _0x4554f8[0x1]["x"],
                _0x4554f8[0x2]["x"],
                _0x4554f8[0x3]["x"],
              ],
              y: [
                _0x4554f8[0x0]["y"],
                _0x4554f8[0x1]["y"],
                _0x4554f8[0x2]["y"],
                _0x4554f8[0x3]["y"],
              ],
            },
            _0xa2e73,
            Phaser["Easing"]["Linear"]["Out"],
            !0x0,
            0x0,
            0x0
          )
          ["interpolation"](function (_0x24fe49, _0x288170) {
            return Phaser["Math"]["bezierInterpolation"](_0x24fe49, _0x288170);
          });
        continue;
      case "7":
        tmpLineNormal2["fromAngle"](
          _0x4554f8[0x4][0x0],
          _0x4554f8[0x4][0x1],
          tmpLine["normalAngle"],
          _0x4fdb60["xmSvQ"](
            0x1,
            _0x4fdb60["UXtfO"](
              Math["floor"](_0x4fdb60["puUXs"](tmpLine["length"], 0x8)),
              _0x4fdb60["SAKLa"](getRandomInt, 0x14)
            )
          )
        );
        continue;
      case "8":
        _0x4fdb60["SAKLa"](
          LOG,
          _0x4fdb60["xUpSQ"](_0x4fdb60["QXOIr"], _0x4554f8["length"])
        );
        continue;
      case "9":
        _0x4fdb60["jsxrB"](null, _0x475e65) &&
          _0x4554f8["onComplete"]["add"](_0x475e65, _0x9f8eb);
        continue;
      case "10":
        _0x4554f8[0x3] = { x: _0x163c15, y: _0x51f0fc };
        continue;
      case "11":
        tmpLineNormal1["fromAngle"](
          _0x4554f8[0x1][0x0],
          _0x4554f8[0x1][0x1],
          tmpLine["normalAngle"],
          _0x4fdb60["xmSvQ"](
            0x1,
            _0x4fdb60["xUpSQ"](
              Math["floor"](_0x4fdb60["puUXs"](tmpLine["length"], 0x4)),
              _0x4fdb60["IAtmO"](getRandomInt, 0xa)
            )
          )
        );
        continue;
      case "12":
        tmpLine["end"]["x"] = _0x163c15;
        continue;
      case "13":
        _0x4554f8[0x1] = {
          x: tmpLineNormal1["end"]["x"],
          y: tmpLineNormal1["end"]["y"],
        };
        continue;
      case "14":
        _0x4554f8[0x0] = {
          x: _0x53cdec["world"]["x"],
          y: _0x53cdec["world"]["y"],
        };
        continue;
      case "15":
        var _0x4554f8 = null;
        continue;
      case "16":
        tmpCircle2["y"] = tmpLineNormal2["end"]["y"];
        continue;
      case "17":
        tmpLine["start"]["y"] = _0x53cdec["world"]["y"];
        continue;
      case "18":
        _0x4554f8[0x2] = {
          x: tmpLineNormal2["end"]["x"],
          y: tmpLineNormal2["end"]["y"],
        };
        continue;
      case "19":
        _0x4554f8 = tmpLine["coordinatesOnLine"](
          Math["floor"](
            _0x4fdb60["CQOHl"](_0x4fdb60["qURnM"](tmpLine["length"], 0x5), 0.5)
          )
        );
        continue;
      case "20":
        tmpCircle1["x"] = tmpLineNormal1["end"]["x"];
        continue;
    }
    break;
  }
}
function createIngameText(_0x18ed4e, _0x2f9d55, _0x44fa0e, _0x409faf) {
  var _0x7e77f8 = {
    XsmDF: "2|3|5|0|1|4|6",
    UQwfP: "#FFFFFF",
    XRWPy: function (_0x8b9358, _0x6f7e74) {
      return _0x8b9358 + _0x6f7e74;
    },
    RZLGs: function (_0x2bb57a, _0x65a62f) {
      return _0x2bb57a || _0x65a62f;
    },
    fbPmr: "px\x20gameFont",
    ndsVh: function (_0x591469, _0x3e70a0, _0x133518) {
      return _0x591469(_0x3e70a0, _0x133518);
    },
    OiwUQ: "#660000",
    FhBFb: function (_0x5d7729, _0x147f3b, _0x5bd695) {
      return _0x5d7729(_0x147f3b, _0x5bd695);
    },
  };
  var _0x1b102a = _0x7e77f8["XsmDF"]["split"]("|"),
    _0x12ece0 = 0x0;
  while ([]) {
    switch (_0x1b102a[_0x12ece0++]) {
      case "0":
        _0x18ed4e["shadowOffsetX"] = 0x3;
        continue;
      case "1":
        _0x18ed4e["shadowOffsetY"] = 0x3;
        continue;
      case "2":
        _0x18ed4e = new Phaser["Text"](game, _0x18ed4e, _0x2f9d55, _0x44fa0e, {
          fill: _0x7e77f8["UQwfP"],
          font: _0x7e77f8["XRWPy"](
            _0x7e77f8["RZLGs"](_0x409faf, "25"),
            _0x7e77f8["fbPmr"]
          ),
        });
        continue;
      case "3":
        _0x18ed4e["anchor"]["x"] = _0x7e77f8["ndsVh"](
          getCorrectAnchorX,
          _0x18ed4e,
          0.5
        );
        continue;
      case "4":
        _0x18ed4e["shadowColor"] = _0x7e77f8["OiwUQ"];
        continue;
      case "5":
        _0x18ed4e["anchor"]["y"] = _0x7e77f8["FhBFb"](
          getCorrectAnchorY,
          _0x18ed4e,
          0.5
        );
        continue;
      case "6":
        return _0x18ed4e;
    }
    break;
  }
}
function createResultText(_0x4925c4, _0x4f8ba8, _0xb78241, _0x34c071) {
  var _0x8431d1 = {
    kGaXs: "4|0|3|1|6|7|2|5",
    CeIeu: function (_0x5e98cd, _0x486fbc, _0x81b646) {
      return _0x5e98cd(_0x486fbc, _0x81b646);
    },
    OBTFH: "#5b2121",
    xGyWL: "#ffffff",
    nBwHn: function (_0x22165d, _0x1ac842) {
      return _0x22165d + _0x1ac842;
    },
    CkSJc: function (_0x44b4ad, _0xd2ddb2) {
      return _0x44b4ad || _0xd2ddb2;
    },
    YmtGP: "px\x20gameFont",
  };
  var _0x56d031 = _0x8431d1["kGaXs"]["split"]("|"),
    _0x23a32a = 0x0;
  while ([]) {
    switch (_0x56d031[_0x23a32a++]) {
      case "0":
        _0x4925c4["anchor"]["x"] = _0x8431d1["CeIeu"](
          getCorrectAnchorX,
          _0x4925c4,
          0.5
        );
        continue;
      case "1":
        _0x4925c4["shadowOffsetX"] = 0x2;
        continue;
      case "2":
        _0x4925c4["shadowFill"] = _0x8431d1["OBTFH"];
        continue;
      case "3":
        _0x4925c4["anchor"]["y"] = _0x8431d1["CeIeu"](
          getCorrectAnchorY,
          _0x4925c4,
          0.5
        );
        continue;
      case "4":
        _0x4925c4 = new Phaser["Text"](game, _0x4925c4, _0x4f8ba8, _0xb78241, {
          fill: _0x8431d1["xGyWL"],
          font: _0x8431d1["nBwHn"](
            _0x8431d1["CkSJc"](_0x34c071, "25"),
            _0x8431d1["YmtGP"]
          ),
        });
        continue;
      case "5":
        return _0x4925c4;
      case "6":
        _0x4925c4["shadowOffsetY"] = 0x2;
        continue;
      case "7":
        _0x4925c4["shadowColor"] = _0x8431d1["OBTFH"];
        continue;
    }
    break;
  }
}
function createButtonWithIcon(
  _0x1abe10,
  _0x122815,
  _0x10aadb,
  _0x24ccac,
  _0x797edc
) {
  var _0x14c2c5 = {
    VrQTv: "7|0|5|2|4|1|6|3",
    zKtby: function (_0x43dcee, _0x5ec263, _0x2be533, _0x3aaab9, _0xf65d2a) {
      return _0x43dcee(_0x5ec263, _0x2be533, _0x3aaab9, _0xf65d2a);
    },
    nxOmj: "pak1",
    vUGgY: function (_0x4c1551, _0x428825) {
      return _0x4c1551 + _0x428825;
    },
    eeMhp: function (_0x54ba23, _0x197784) {
      return _0x54ba23 + _0x197784;
    },
    qToaK: "icons_",
    ZfDju: ".png",
    rVILk: "button_0.png",
  };
  var _0x2218d5 = _0x14c2c5["VrQTv"]["split"]("|"),
    _0x2793d0 = 0x0;
  while ([]) {
    switch (_0x2218d5[_0x2793d0++]) {
      case "0":
        _0x1abe10["anchor"]["set"](0.5);
        continue;
      case "1":
        _0x24ccac["anchor"]["set"](0.5);
        continue;
      case "2":
        _0x14c2c5["zKtby"](
          AddButtonEvents,
          _0x1abe10,
          _0x797edc,
          ButtonOnInputOver,
          ButtonOnInputOut
        );
        continue;
      case "3":
        return _0x1abe10;
      case "4":
        _0x24ccac = new Phaser["Sprite"](
          game,
          0x0,
          -0x3,
          _0x14c2c5["nxOmj"],
          _0x14c2c5["vUGgY"](
            _0x14c2c5["eeMhp"](_0x14c2c5["qToaK"], _0x24ccac),
            _0x14c2c5["ZfDju"]
          )
        );
        continue;
      case "5":
        _0x1abe10["inputEnabled"] = !0x0;
        continue;
      case "6":
        _0x1abe10["addChild"](_0x24ccac);
        continue;
      case "7":
        _0x1abe10 = _0x1abe10["create"](
          _0x122815,
          _0x10aadb,
          _0x14c2c5["nxOmj"],
          _0x14c2c5["rVILk"]
        );
        continue;
    }
    break;
  }
}
function createInstructionsText(_0x35216e, _0x50293d, _0x110c24, _0x59b4bc) {
  var _0xfba17e = {
    CjMhD: "4|5|6|3|0|2|1|7",
    VbWty: "#555555",
    ykeVm: "#FFFFFF",
    FStei: "24px\x20gameFont",
    BKPKl: "center",
    DXdGE: function (_0x3193cd, _0x1c8121, _0x2554c0) {
      return _0x3193cd(_0x1c8121, _0x2554c0);
    },
  };
  var _0x19322c = _0xfba17e["CjMhD"]["split"]("|"),
    _0x277eb4 = 0x0;
  while ([]) {
    switch (_0x19322c[_0x277eb4++]) {
      case "0":
        _0x35216e["shadowOffsetY"] = 0x2;
        continue;
      case "1":
        _0x35216e["shadowFill"] = _0xfba17e["VbWty"];
        continue;
      case "2":
        _0x35216e["shadowColor"] = _0xfba17e["VbWty"];
        continue;
      case "3":
        _0x35216e["shadowOffsetX"] = 0x2;
        continue;
      case "4":
        _0x35216e = new Phaser["Text"](game, _0x35216e, _0x50293d, _0x110c24, {
          fill: _0xfba17e["ykeVm"],
          font: _0xfba17e["FStei"],
          wordWrap: !0x0,
          wordWrapWidth: _0x59b4bc,
          align: _0xfba17e["BKPKl"],
        });
        continue;
      case "5":
        _0x35216e["anchor"]["x"] = _0xfba17e["DXdGE"](
          getCorrectAnchorX,
          _0x35216e,
          0.5
        );
        continue;
      case "6":
        _0x35216e["anchor"]["y"] = _0xfba17e["DXdGE"](
          getCorrectAnchorY,
          _0x35216e,
          0.5
        );
        continue;
      case "7":
        return _0x35216e;
    }
    break;
  }
}
function tweenTint(_0x3e050f, _0x1538f4, _0x480c08, _0x3bd492) {
  var _0x3bb46a = { Qyxfa: "0|3|4|2|1" };
  var _0x465ddd = _0x3bb46a["Qyxfa"]["split"]("|"),
    _0x3f6bf4 = 0x0;
  while ([]) {
    switch (_0x465ddd[_0x3f6bf4++]) {
      case "0":
        var _0x95691f = { step: 0x0 };
        continue;
      case "1":
        _0x3bd492["start"]();
        continue;
      case "2":
        _0x3e050f["tint"] = _0x1538f4;
        continue;
      case "3":
        _0x3bd492 = game["add"]
          ["tween"](_0x95691f)
          ["to"]({ step: 0x64 }, _0x3bd492);
        continue;
      case "4":
        _0x3bd492["onUpdateCallback"](function () {
          _0x3e050f["tint"] = Phaser["Color"]["interpolateColor"](
            _0x1538f4,
            _0x480c08,
            0x64,
            _0x95691f["step"]
          );
        });
        continue;
    }
    break;
  }
}
function tweenBackgroundColor(
  _0x30a638,
  _0x94009d,
  _0x38afb0,
  _0x2c1a6f,
  _0x1b4d62,
  _0x6aa336
) {
  var _0x238832 = { GixfS: "0|4|3|1|2" };
  var _0x1ec0bd = _0x238832["GixfS"]["split"]("|"),
    _0x303a0f = 0x0;
  while ([]) {
    switch (_0x1ec0bd[_0x303a0f++]) {
      case "0":
        var _0xfc3a62 = { step: 0x0 };
        continue;
      case "1":
        _0x30a638["backgroundColor"] = _0x94009d;
        continue;
      case "2":
        _0x6aa336["start"]();
        continue;
      case "3":
        _0x6aa336["onUpdateCallback"](function () {
          _0x30a638["backgroundColor"] = Phaser["Color"][
            "interpolateColorWithRGB"
          ](_0x94009d, _0x38afb0, _0x2c1a6f, _0x1b4d62, 0xa, _0xfc3a62["step"]);
        });
        continue;
      case "4":
        _0x6aa336 = game["add"]
          ["tween"](_0xfc3a62)
          ["to"]({ step: 0xa }, _0x6aa336);
        continue;
    }
    break;
  }
}
var IMAGE_FOLDER = "img_480/";
function loadSplash(_0x3dec82) {
  var _0x3eaed0 = {
    pZlQy: "lang_strings",
    hfYSX: "assets/dat/m.xml",
    StwSX: "void",
    ZZgkN: function (_0xd08c61, _0x25ae69) {
      return _0xd08c61 + _0x25ae69;
    },
    FInbx: function (_0x7f2584, _0x40800b) {
      return _0x7f2584 + _0x40800b;
    },
    Hylnn: "assets/",
    cFzpU: "void.png",
    NCCct: "splash_img",
    jolUW: function (_0x399da5, _0x474e67) {
      return _0x399da5 + _0x474e67;
    },
    HvZGQ: "game_logo.png",
    ttydP: "frame",
    yVuqg: function (_0x3ccabf, _0x234625) {
      return _0x3ccabf + _0x234625;
    },
    qbEGD: function (_0x4a73a3, _0xd2f86e) {
      return _0x4a73a3 + _0xd2f86e;
    },
    SCDWS: "frame.png",
  };
  _0x3dec82["load"]["text"](_0x3eaed0["pZlQy"], _0x3eaed0["hfYSX"]);
  _0x3dec82["load"]["image"](
    _0x3eaed0["StwSX"],
    _0x3eaed0["ZZgkN"](
      _0x3eaed0["FInbx"](_0x3eaed0["Hylnn"], IMAGE_FOLDER),
      _0x3eaed0["cFzpU"]
    )
  );
  _0x3dec82["load"]["image"](
    _0x3eaed0["NCCct"],
    _0x3eaed0["FInbx"](
      _0x3eaed0["jolUW"](_0x3eaed0["Hylnn"], IMAGE_FOLDER),
      _0x3eaed0["HvZGQ"]
    )
  );
  _0x3dec82["load"]["image"](
    _0x3eaed0["ttydP"],
    _0x3eaed0["yVuqg"](
      _0x3eaed0["qbEGD"](_0x3eaed0["Hylnn"], IMAGE_FOLDER),
      _0x3eaed0["SCDWS"]
    )
  );
}
function loadImages(_0x7f334a) {
  var _0x47b75e = {
    ghRvP: "5|6|7|0|3|1|4|2",
    cRbfO: "puzzle_piece",
    sjdnx: function (_0x131879, _0xa3081a) {
      return _0x131879 + _0xa3081a;
    },
    jAJBl: function (_0x119711, _0x4bf0d6) {
      return _0x119711 + _0x4bf0d6;
    },
    HavCo: "assets/",
    LdLfq: "pieces.png",
    eikrv: "menu_back",
    WOOJK: function (_0x295db4, _0x282fd6) {
      return _0x295db4 + _0x282fd6;
    },
    GDGqC: "table_l.png",
    CwQNz: "menu_window",
    kuoxQ: function (_0x5e63d1, _0x1339a5) {
      return _0x5e63d1 + _0x1339a5;
    },
    qCpqf: "win_back.png",
    SbsOu: "puzzle_piece_outline",
    AwPvd: function (_0x3cbb27, _0x10b398) {
      return _0x3cbb27 + _0x10b398;
    },
    ncjgc: function (_0x278803, _0x5de9d4) {
      return _0x278803 + _0x5de9d4;
    },
    reSvC: "pieces_outline.png",
    uBfeZ: "menu_back_p",
    pOVrq: function (_0x37e848, _0x5a88d8) {
      return _0x37e848 + _0x5a88d8;
    },
    LJdLz: "table_p.png",
    qQYye: "pak1",
    aXAwA: "pak1.png",
    vEKxM: function (_0x5304a1, _0x2394e3) {
      return _0x5304a1 + _0x2394e3;
    },
    VpGNr: "pak1.json",
    ScIVA: "bakground",
    dTBkG: function (_0x5088a7, _0x425070) {
      return _0x5088a7 + _0x425070;
    },
    FTPcI: function (_0x38e9b7, _0x5bdf41) {
      return _0x38e9b7 + _0x5bdf41;
    },
    iqJtm: "bg.png",
  };
  var _0x184238 = _0x47b75e["ghRvP"]["split"]("|"),
    _0x51f906 = 0x0;
  while ([]) {
    switch (_0x184238[_0x51f906++]) {
      case "0":
        _0x7f334a["load"]["spritesheet"](
          _0x47b75e["cRbfO"],
          _0x47b75e["sjdnx"](
            _0x47b75e["jAJBl"](_0x47b75e["HavCo"], IMAGE_FOLDER),
            _0x47b75e["LdLfq"]
          ),
          0x1f4,
          0x1f4
        );
        continue;
      case "1":
        _0x7f334a["load"]["image"](
          _0x47b75e["eikrv"],
          _0x47b75e["jAJBl"](
            _0x47b75e["WOOJK"](_0x47b75e["HavCo"], IMAGE_FOLDER),
            _0x47b75e["GDGqC"]
          )
        );
        continue;
      case "2":
        _0x7f334a["load"]["image"](
          _0x47b75e["CwQNz"],
          _0x47b75e["WOOJK"](
            _0x47b75e["kuoxQ"](_0x47b75e["HavCo"], IMAGE_FOLDER),
            _0x47b75e["qCpqf"]
          )
        );
        continue;
      case "3":
        _0x7f334a["load"]["spritesheet"](
          _0x47b75e["SbsOu"],
          _0x47b75e["AwPvd"](
            _0x47b75e["ncjgc"](_0x47b75e["HavCo"], IMAGE_FOLDER),
            _0x47b75e["reSvC"]
          ),
          0x1f4,
          0x1f4
        );
        continue;
      case "4":
        _0x7f334a["load"]["image"](
          _0x47b75e["uBfeZ"],
          _0x47b75e["ncjgc"](
            _0x47b75e["pOVrq"](_0x47b75e["HavCo"], IMAGE_FOLDER),
            _0x47b75e["LJdLz"]
          )
        );
        continue;
      case "5":
        GROUP_SIZE = 0x8;
        continue;
      case "6":
        _0x7f334a["load"]["atlas"](
          _0x47b75e["qQYye"],
          _0x47b75e["pOVrq"](
            _0x47b75e["pOVrq"](_0x47b75e["HavCo"], IMAGE_FOLDER),
            _0x47b75e["aXAwA"]
          ),
          _0x47b75e["pOVrq"](
            _0x47b75e["vEKxM"](_0x47b75e["HavCo"], IMAGE_FOLDER),
            _0x47b75e["VpGNr"]
          )
        );
        continue;
      case "7":
        _0x7f334a["load"]["image"](
          _0x47b75e["ScIVA"],
          _0x47b75e["dTBkG"](
            _0x47b75e["FTPcI"](_0x47b75e["HavCo"], IMAGE_FOLDER),
            _0x47b75e["iqJtm"]
          )
        );
        continue;
    }
    break;
  }
}
function loadSounds(_0x372739) {
  var _0x3fc28c = {
    ZIejU: "2|3|1|4|5|0",
    TErJv: "game_completed",
    fWyWs: "assets/audio/puzzle_completed.ogg",
    vwTEG: "assets/audio/puzzle_completed.mp3",
    QfQXa: "tile_pop",
    cnego: "assets/audio/Tile_in.ogg",
    qvMqM: "assets/audio/Tile_in.mp3",
    ZFSqM: "music_menu",
    IODcq: "assets/audio/music_menu.ogg",
    rowxd: "assets/audio/music_menu.mp3",
    NrVLy: "menu-click1",
    lhmEI: "assets/audio/menu-click1.ogg",
    BKBrM: "assets/audio/menu-click1.mp3",
    qHMqr: "tile_return",
    aoCSA: "assets/audio/wrong_move_tile_in.ogg",
    BVRLC: "assets/audio/wrong_move_tile_in.mp3",
    uPOQk: "pop_balloon",
    XHWne: "assets/audio/popsfx.ogg",
    dByar: "assets/audio/popsfx.mp3",
  };
  var _0x22f62f = _0x3fc28c["ZIejU"]["split"]("|"),
    _0x6f79d6 = 0x0;
  while ([]) {
    switch (_0x22f62f[_0x6f79d6++]) {
      case "0":
        _0x372739["load"]["audio"](_0x3fc28c["TErJv"], [
          _0x3fc28c["fWyWs"],
          _0x3fc28c["vwTEG"],
        ]);
        continue;
      case "1":
        _0x372739["load"]["audio"](_0x3fc28c["QfQXa"], [
          _0x3fc28c["cnego"],
          _0x3fc28c["qvMqM"],
        ]);
        continue;
      case "2":
        _0x372739["load"]["audio"](_0x3fc28c["ZFSqM"], [
          _0x3fc28c["IODcq"],
          _0x3fc28c["rowxd"],
        ]);
        continue;
      case "3":
        _0x372739["load"]["audio"](_0x3fc28c["NrVLy"], [
          _0x3fc28c["lhmEI"],
          _0x3fc28c["BKBrM"],
        ]);
        continue;
      case "4":
        _0x372739["load"]["audio"](_0x3fc28c["qHMqr"], [
          _0x3fc28c["aoCSA"],
          _0x3fc28c["BVRLC"],
        ]);
        continue;
      case "5":
        _0x372739["load"]["audio"](_0x3fc28c["uPOQk"], [
          _0x3fc28c["XHWne"],
          _0x3fc28c["dByar"],
        ]);
        continue;
    }
    break;
  }
}
function getPakFrames(_0x17bb0a, _0x52c9a1) {
  var _0x55ee5c = {
    uRfyy: function (_0x4a81d4, _0xde140f) {
      return _0x4a81d4 < _0xde140f;
    },
    xuMfj: function (_0x27c478, _0x58924e) {
      return _0x27c478 + _0x58924e;
    },
    kwepn: function (_0xfcb7e9, _0x6b2df0) {
      return _0xfcb7e9 + _0x6b2df0;
    },
    VuQKe: ".png",
  };
  output = [];
  for (
    var _0x3025c3 = 0x0;
    _0x55ee5c["uRfyy"](_0x3025c3, _0x52c9a1["length"]);
    _0x3025c3++
  )
    output[_0x3025c3] = _0x55ee5c["xuMfj"](
      _0x55ee5c["kwepn"](_0x17bb0a, _0x52c9a1[_0x3025c3]),
      _0x55ee5c["VuQKe"]
    );
  return output;
}
var Splash = function (_0x5468a6) {};
function enterIncorrectOrientation() {
  var _0x9f54f3 = {
    ozrRi: function (_0x3e6d9c, _0x2cbbd7) {
      return _0x3e6d9c(_0x2cbbd7);
    },
    DqpwA: "enterIncorrectOrientation()",
    Zvbnf: "wrongRotation",
    FtkFb: function (_0x4ff397, _0x2aaaa8) {
      return _0x4ff397 != _0x2aaaa8;
    },
  };
  _0x9f54f3["ozrRi"](LOG, _0x9f54f3["DqpwA"]);
  _0x9f54f3["ozrRi"](showDiv, _0x9f54f3["Zvbnf"]);
  if (_0x9f54f3["FtkFb"](null, gameState)) gameState["onGamePause"]();
}
function leaveIncorrectOrientation() {
  var _0x23fafa = {
    nQdnw: function (_0x36747e, _0x1f4ee4) {
      return _0x36747e(_0x1f4ee4);
    },
    tExXP: "leaveIncorrectOrientation()",
    dWxPj: "wrongRotation",
    sozoC: function (_0x4a7ca4, _0x469f2f) {
      return _0x4a7ca4 != _0x469f2f;
    },
  };
  _0x23fafa["nQdnw"](LOG, _0x23fafa["tExXP"]);
  _0x23fafa["nQdnw"](hideDiv, _0x23fafa["dWxPj"]);
  if (_0x23fafa["sozoC"](null, gameState)) gameState["onGameResume"]();
}
Splash["prototype"] = {
  preload: function () {
    var _0x451db2 = {
      AhdhN: "7|12|2|8|0|9|10|11|5|1|4|3|6",
      zbLrc: "resize",
      CTQnn: "gameCanvas",
      bmupH: "fixed",
      WcxaM: "Anonymous",
      oqjCN: function (_0x22289c) {
        return _0x22289c();
      },
      XtlYM: function (_0x136120, _0x13c050) {
        return _0x136120(_0x13c050);
      },
      hTBoH: function (_0x322413) {
        return _0x322413();
      },
    };
    var _0x35517d = _0x451db2["AhdhN"]["split"]("|"),
      _0x2233da = 0x0;
    while ([]) {
      switch (_0x35517d[_0x2233da++]) {
        case "0":
          game["scale"]["fullScreenScaleMode"] =
            Phaser["ScaleManager"]["SHOW_ALL"];
          continue;
        case "1":
          window["addEventListener"](_0x451db2["zbLrc"], function () {
            _0x2d3217["VGPyH"](onGameResize);
          });
          continue;
        case "2":
          document["getElementById"](_0x451db2["CTQnn"])["style"]["position"] =
            _0x451db2["bmupH"];
          continue;
        case "3":
          game["load"]["crossOrigin"] = _0x451db2["WcxaM"];
          continue;
        case "4":
          _0x451db2["oqjCN"](onGameResize);
          continue;
        case "5":
          game["scale"]["refresh"]();
          continue;
        case "6":
          _0x451db2["XtlYM"](loadSplash, this["game"]);
          continue;
        case "7":
          var _0x2d3217 = {
            VGPyH: function (_0x522d2e) {
              return _0x451db2["hTBoH"](_0x522d2e);
            },
          };
          continue;
        case "8":
          this["game"]["stage"]["backgroundColor"] = 0x0;
          continue;
        case "9":
          game["scale"]["scaleMode"] = Phaser["ScaleManager"]["SHOW_ALL"];
          continue;
        case "10":
          game["scale"]["pageAlignHorizontally"] = !0x0;
          continue;
        case "11":
          game["scale"]["pageAlignVertically"] = !0x0;
          continue;
        case "12":
          game["canvas"]["id"] = _0x451db2["CTQnn"];
          continue;
      }
      break;
    }
  },
  create: function () {
    var _0x336521 = {
      CJvlZ: "6|1|3|4|0|5|2",
      TgkXg: "frame",
      TcBhY: "splash_img",
    };
    var _0x5235c3 = _0x336521["CJvlZ"]["split"]("|"),
      _0xb0b7da = 0x0;
    while ([]) {
      switch (_0x5235c3[_0xb0b7da++]) {
        case "0":
          this["imgFrame"]["anchor"]["set"](0.5);
          continue;
        case "1":
          this["splashImg"]["anchor"]["set"](0.5);
          continue;
        case "2":
          this["loadContinue"]();
          continue;
        case "3":
          this["splashImg"]["alpha"] = 0x1;
          continue;
        case "4":
          this["imgFrame"] = this["game"]["add"]["sprite"](
            this["game"]["world"]["centerX"],
            this["game"]["world"]["centerY"],
            _0x336521["TgkXg"]
          );
          continue;
        case "5":
          this["imgFrame"]["alpha"] = 0x1;
          continue;
        case "6":
          this["splashImg"] = this["add"]["sprite"](
            this["game"]["world"]["centerX"],
            this["game"]["world"]["centerY"],
            _0x336521["TcBhY"]
          );
          continue;
      }
      break;
    }
  },
  loadContinue: function () {
    this["splashImg"]["inputEnabled"] = !0x0;
    this["splashImg"]["events"]["onInputDown"]["add"](
      this["startPreload"],
      this
    );
    this["startPreload"]();
  },
  hideLogo: function () {
    var _0x476a9c = {
      lyfXU: function (_0x523d4b, _0x3df9a1) {
        return _0x523d4b * _0x3df9a1;
      },
    };
    game["add"]
      ["tween"](this["logo"])
      ["to"](
        { alpha: 0x0 },
        _0x476a9c["lyfXU"](0x3, ScenesTransitions["TRANSITION_LENGTH"]),
        ANIMATION_CUBIC_IO,
        !0x0,
        0x0,
        0x0,
        !0x1
      );
    game["add"]
      ["tween"](this["splashImg"])
      ["to"](
        { alpha: 0x0 },
        _0x476a9c["lyfXU"](0x3, ScenesTransitions["TRANSITION_LENGTH"]),
        ANIMATION_CUBIC_IO,
        !0x0,
        0x0,
        0x0,
        !0x1
      );
  },
  startPreload: function () {
    var _0x3b42ee = { LWaQt: "PreloadState" };
    this["game"]["state"]["start"](_0x3b42ee["LWaQt"]);
  },
};
var savedClientWidth = 0x0,
  savedClientHeight = 0x0;
function onGameResize() {
  var _0x3c83f6 = {
    OKswd: function (_0x370a66, _0x345c37) {
      return _0x370a66(_0x345c37);
    },
    ZmTuu: "onGameResize()",
    nSxUF: function (_0x4d9f5b, _0x135422) {
      return _0x4d9f5b !== _0x135422;
    },
    bBKAi: "9|4|7|11|2|0|10|8|12|1|6|5|3",
    UClBZ: function (_0x259d11, _0x5d404b) {
      return _0x259d11 != _0x5d404b;
    },
    EZeUM: function (_0x49a1a6, _0x50cdf1) {
      return _0x49a1a6 > _0x50cdf1;
    },
    jsjjr: function (_0x219e17, _0x5ab565) {
      return _0x219e17 > _0x5ab565;
    },
    RUkJH: function (_0x447b38, _0x45a3b8) {
      return _0x447b38 * _0x45a3b8;
    },
    TUDMM: function (_0x258785, _0x5e93a9) {
      return _0x258785 / _0x5e93a9;
    },
    ZXFCR: function (_0x23c311, _0x36df35) {
      return _0x23c311(_0x36df35);
    },
    JsJBZ: function (_0x3d7ebb, _0x5946a1) {
      return _0x3d7ebb < _0x5946a1;
    },
    URUhj: function (_0xaefdb1, _0x3f045b) {
      return _0xaefdb1(_0x3f045b);
    },
    FJhIo: function (_0x1f2aac, _0x581307) {
      return _0x1f2aac < _0x581307;
    },
    VEetS: function (_0x19d5b6, _0x21e0bb) {
      return _0x19d5b6 > _0x21e0bb;
    },
  };
  _0x3c83f6["OKswd"](LOG, _0x3c83f6["ZmTuu"]);
  if (_0x3c83f6["nSxUF"](null, game)) {
    var _0xfd7168 = _0x3c83f6["bBKAi"]["split"]("|"),
      _0xb9a1ba = 0x0;
    while ([]) {
      switch (_0xfd7168[_0xb9a1ba++]) {
        case "0":
          game["scale"]["fullScreenScaleMode"] =
            Phaser["ScaleManager"]["SHOW_ALL"];
          continue;
        case "1":
          game["scale"]["refresh"]();
          continue;
        case "2":
          savedClientHeight = _0x302c8a;
          continue;
        case "3":
          if (_0x3c83f6["UClBZ"](null, preloadState))
            preloadState["onResolutionChange"]();
          continue;
        case "4":
          isIOS &&
            _0x3c83f6["EZeUM"](_0x5c1357, _0x302c8a) &&
            ((_0x5c1357 = window["innerWidth"]),
            (_0x302c8a = window["innerHeight"]));
          continue;
        case "5":
          if (_0x3c83f6["UClBZ"](null, gameState))
            gameState["onResolutionChange"]();
          continue;
        case "6":
          game["scale"]["setGameSize"](resolutionX, resolutionY);
          continue;
        case "7":
          _0x3c83f6["jsjjr"](_0x302c8a, _0x5c1357)
            ? ((GAME_CURRENT_ORIENTATION = ORIENTATION_PORTRAIT),
              (resolutionX = game_resolutions[GAME_CURRENT_ORIENTATION]["x"]),
              (resolutionY = _0x3c83f6["RUkJH"](
                _0x3c83f6["TUDMM"](_0x302c8a, _0x5c1357),
                resolutionX
              )),
              _0x3c83f6["ZXFCR"](isNaN, resolutionY) && (resolutionY = 0x0),
              _0x3c83f6["JsJBZ"](
                resolutionY,
                game_resolutions[GAME_CURRENT_ORIENTATION]["yMin"]
              ) &&
                (resolutionY =
                  game_resolutions[GAME_CURRENT_ORIENTATION]["yMin"]),
              _0x3c83f6["jsjjr"](
                resolutionY,
                game_resolutions[GAME_CURRENT_ORIENTATION]["yMax"]
              ) &&
                (resolutionY =
                  game_resolutions[GAME_CURRENT_ORIENTATION]["yMax"]))
            : ((GAME_CURRENT_ORIENTATION = ORIENTATION_LANDSCAPE),
              (resolutionY = game_resolutions[GAME_CURRENT_ORIENTATION]["y"]),
              (resolutionX = _0x3c83f6["RUkJH"](
                _0x3c83f6["TUDMM"](_0x5c1357, _0x302c8a),
                resolutionY
              )),
              _0x3c83f6["URUhj"](isNaN, resolutionX) && (resolutionX = 0x0),
              _0x3c83f6["FJhIo"](
                resolutionX,
                game_resolutions[GAME_CURRENT_ORIENTATION]["xMin"]
              ) &&
                (resolutionX =
                  game_resolutions[GAME_CURRENT_ORIENTATION]["xMin"]),
              _0x3c83f6["VEetS"](
                resolutionX,
                game_resolutions[GAME_CURRENT_ORIENTATION]["xMax"]
              ) &&
                (resolutionX =
                  game_resolutions[GAME_CURRENT_ORIENTATION]["xMax"]));
          continue;
        case "8":
          game["scale"]["pageAlignHorizontally"] = !0x0;
          continue;
        case "9":
          var _0x5c1357 = document["documentElement"]["clientWidth"],
            _0x302c8a = document["documentElement"]["clientHeight"];
          continue;
        case "10":
          game["scale"]["scaleMode"] = Phaser["ScaleManager"]["SHOW_ALL"];
          continue;
        case "11":
          savedClientWidth = _0x5c1357;
          continue;
        case "12":
          game["scale"]["pageAlignVertically"] = !0x0;
          continue;
      }
      break;
    }
  }
}
var Preloader = function (_0x3d1889) {},
  loaderPosY,
  preloadState;
Preloader["prototype"] = {
  preload: function () {
    var _0x1be621 = {
      seKnT:
        "6|3|7|1|19|21|25|26|11|24|23|13|17|2|5|0|10|20|16|8|12|15|9|4|22|14|18",
      PMpij: function (_0x120f2c, _0x436932) {
        return _0x120f2c + _0x436932;
      },
      Lprrr: function (_0x435746, _0x3daf1e) {
        return _0x435746 / _0x3daf1e;
      },
      UYGmr: function (_0x2aafa9, _0xdc951) {
        return _0x2aafa9 / _0xdc951;
      },
      hDUnw: "void",
      VfNJr: function (_0x4cb090, _0x3df478) {
        return _0x4cb090(_0x3df478);
      },
      paTNQ: function (_0x2fc0f1, _0xbf13b7) {
        return _0x2fc0f1 - _0xbf13b7;
      },
      hmvYC: "0\x20%",
      msseX: "35px\x20\x22Arial\x20Black\x22",
      TtdrP: "#FFFFFF",
      sJqCc: function (_0x33811c, _0x2a25c0) {
        return _0x33811c + _0x2a25c0;
      },
      IsDvu: function (_0x1c8445, _0x17e00a) {
        return _0x1c8445 / _0x17e00a;
      },
      ouove: function (_0x5f909d, _0x3e7c15) {
        return _0x5f909d * _0x3e7c15;
      },
      Xkhxb: function (_0x53b3f9, _0xd339bc) {
        return _0x53b3f9 / _0xd339bc;
      },
      ekPKd: "splash_img",
      fTtfG: "frame",
    };
    var _0x3f02f8 = _0x1be621["seKnT"]["split"]("|"),
      _0x3cbf90 = 0x0;
    while ([]) {
      switch (_0x3f02f8[_0x3cbf90++]) {
        case "0":
          grpScenePreload["add"](imgSplash);
          continue;
        case "1":
          this["game"]["stage"]["backgroundColor"] = 0x0;
          continue;
        case "2":
          imgFrame["height"] = _0x1be621["PMpij"](imgSplash["height"], 0x7);
          continue;
        case "3":
          sceneLanguages = null;
          continue;
        case "4":
          this["game"]["load"]["onFileComplete"]["add"](
            this["fileComplete"],
            this
          );
          continue;
        case "5":
          grpScenePreload["add"](imgFrame);
          continue;
        case "6":
          grpScenePreload = game["add"]["group"]();
          continue;
        case "7":
          startTime = Date["now"]();
          continue;
        case "8":
          imgBtn["scale"]["y"] = _0x1be621["PMpij"](
            _0x1be621["Lprrr"](game["height"], 0x64),
            0.2
          );
          continue;
        case "9":
          percentageText["anchor"]["set"](0.5);
          continue;
        case "10":
          imgBtn = this["game"]["add"]["sprite"](
            _0x1be621["Lprrr"](game["width"], 0x2),
            _0x1be621["UYGmr"](game["height"], 0x2),
            _0x1be621["hDUnw"]
          );
          continue;
        case "11":
          imgFrame["alpha"] = 0x1;
          continue;
        case "12":
          new Languages();
          continue;
        case "13":
          imgSplash["alpha"] = 0x1;
          continue;
        case "14":
          SOUNDS_ENABLED && _0x1be621["VfNJr"](loadSounds, this["game"]);
          continue;
        case "15":
          percentageText = this["game"]["add"]["text"](
            this["game"]["world"]["centerX"],
            _0x1be621["paTNQ"](this["game"]["height"], 0x14),
            _0x1be621["hmvYC"],
            { font: _0x1be621["msseX"], fill: _0x1be621["TtdrP"] }
          );
          continue;
        case "16":
          imgBtn["scale"]["x"] = _0x1be621["sJqCc"](
            _0x1be621["IsDvu"](game["width"], 0x64),
            0.2
          );
          continue;
        case "17":
          imgFrame["width"] = _0x1be621["sJqCc"](imgSplash["width"], 0x7);
          continue;
        case "18":
          this["getLangFromSystem"]();
          continue;
        case "19":
          preloadState = this;
          continue;
        case "20":
          imgBtn["anchor"]["set"](0.5);
          continue;
        case "21":
          loaderPosY = _0x1be621["ouove"](
            _0x1be621["Xkhxb"](this["game"]["world"]["height"], 0x5),
            4.5
          );
          continue;
        case "22":
          _0x1be621["VfNJr"](loadImages, this["game"]);
          continue;
        case "23":
          imgSplash["anchor"]["set"](0.5);
          continue;
        case "24":
          imgSplash = this["game"]["make"]["sprite"](
            this["game"]["world"]["centerX"],
            this["game"]["world"]["centerY"],
            _0x1be621["ekPKd"]
          );
          continue;
        case "25":
          imgFrame = this["game"]["make"]["sprite"](
            this["game"]["world"]["centerX"],
            this["game"]["world"]["centerY"],
            _0x1be621["fTtfG"]
          );
          continue;
        case "26":
          imgFrame["anchor"]["set"](0.5);
          continue;
      }
      break;
    }
  },
  fileComplete: function (
    _0x60df90,
    _0x4ce544,
    _0x111381,
    _0x360c43,
    _0x2151ce
  ) {
    var _0x1e902a = {
      xpJLC: function (_0x3c9630, _0x5d7c8d) {
        return _0x3c9630 + _0x5d7c8d;
      },
      WUsBI: function (_0x56a686, _0x4c3138) {
        return _0x56a686 <= _0x4c3138;
      },
    };
    percentageText["text"] = _0x1e902a["xpJLC"](_0x60df90, "\x20%");
    _0x1e902a["WUsBI"](0x64, _0x60df90) && this["_create"]();
  },
  _create: function () {
    var _0x522291 = {
      FjUEB: function (_0x412cf0, _0x1ec0f2) {
        return _0x412cf0 * _0x1ec0f2;
      },
      JicUL: "Linear",
      ELPHO: function (_0x16cddd, _0x394b66) {
        return _0x16cddd * _0x394b66;
      },
      pVtSH: function (_0x2ac022, _0x381eec) {
        return _0x2ac022(_0x381eec);
      },
      WlaUP: "TTC",
    };
    game["input"]["onDown"]["add"](this["startGame"], this);
    game["add"]
      ["tween"](percentageText)
      ["to"](
        { alpha: 0x0 },
        _0x522291["FjUEB"](0x3, ScenesTransitions["TRANSITION_LENGTH"]),
        _0x522291["JicUL"],
        !0x0,
        _0x522291["ELPHO"](0x4, ScenesTransitions["TRANSITION_LENGTH"]),
        -0x1,
        !0x0
      );
    Date["now"]();
    percentageText["text"] = _0x522291["pVtSH"](STR, _0x522291["WlaUP"]);
  },
  createMenuText: function (_0x2bd9e7, _0x46fba2, _0x5ef8ee) {
    var _0x49318c = {
      JaFhz: "6|3|2|4|0|1|5",
      gSTVu: "#660000",
      oNEwi: function (_0x54a1cf, _0x464466, _0x16e841) {
        return _0x54a1cf(_0x464466, _0x16e841);
      },
      yMqRs: function (_0x5d8c2d, _0x514928, _0x4ac19e) {
        return _0x5d8c2d(_0x514928, _0x4ac19e);
      },
      QIWqc: "#FED87F",
    };
    var _0x154ff5 = _0x49318c["JaFhz"]["split"]("|"),
      _0x4a473a = 0x0;
    while ([]) {
      switch (_0x154ff5[_0x4a473a++]) {
        case "0":
          _0x2bd9e7["shadowOffsetY"] = 0x3;
          continue;
        case "1":
          _0x2bd9e7["shadowColor"] = _0x49318c["gSTVu"];
          continue;
        case "2":
          _0x2bd9e7["anchor"]["y"] = _0x49318c["oNEwi"](
            getCorrectAnchorY,
            _0x2bd9e7,
            0.5
          );
          continue;
        case "3":
          _0x2bd9e7["anchor"]["x"] = _0x49318c["yMqRs"](
            getCorrectAnchorX,
            _0x2bd9e7,
            0.5
          );
          continue;
        case "4":
          _0x2bd9e7["shadowOffsetX"] = 0x3;
          continue;
        case "5":
          return _0x2bd9e7;
        case "6":
          _0x2bd9e7 = new Phaser["Text"](
            game,
            _0x2bd9e7,
            _0x46fba2,
            _0x5ef8ee,
            { fill: _0x49318c["QIWqc"] }
          );
          continue;
      }
      break;
    }
  },
  getLangFromSystem: function () {
    var _0x3cf847 = {
      oFKnQ: "0|7|5|2|6|3|9|8|4|1",
      bwDbZ: function (_0x558c16, _0x39e38c) {
        return _0x558c16 !== _0x39e38c;
      },
      GBGyr: function (_0x1fe2a8, _0x358522) {
        return _0x1fe2a8 !== _0x358522;
      },
      yUTik: function (_0x5c550f, _0x24ce0a) {
        return _0x5c550f !== _0x24ce0a;
      },
      RTWVV: function (_0x203f5e, _0x14512c) {
        return _0x203f5e !== _0x14512c;
      },
      aToVU: function (_0x8a712c, _0x17976c) {
        return _0x8a712c !== _0x17976c;
      },
    };
    var _0x551ddc = _0x3cf847["oFKnQ"]["split"]("|"),
      _0x3a239d = 0x0;
    while ([]) {
      switch (_0x551ddc[_0x3a239d++]) {
        case "0":
          Languages["instance"]["language"] = "en";
          continue;
        case "1":
          _0x3cf847["bwDbZ"](-0x1, _0x2a4d89["indexOf"]("ru")) &&
            (Languages["instance"]["language"] = "ru");
          continue;
        case "2":
          _0x3cf847["bwDbZ"](-0x1, _0x2a4d89["indexOf"]("it")) &&
            (Languages["instance"]["language"] = "it");
          continue;
        case "3":
          _0x3cf847["GBGyr"](-0x1, _0x2a4d89["indexOf"]("es")) &&
            (Languages["instance"]["language"] = "es");
          continue;
        case "4":
          _0x3cf847["GBGyr"](-0x1, _0x2a4d89["indexOf"]("nl")) &&
            (Languages["instance"]["language"] = "nl");
          continue;
        case "5":
          _0x3cf847["yUTik"](-0x1, _0x2a4d89["indexOf"]("fr")) &&
            (Languages["instance"]["language"] = "fr");
          continue;
        case "6":
          _0x3cf847["RTWVV"](-0x1, _0x2a4d89["indexOf"]("de")) &&
            (Languages["instance"]["language"] = "de");
          continue;
        case "7":
          var _0x2a4d89 = navigator["userLanguage"] || navigator["language"],
            _0x2a4d89 = _0x2a4d89["toLowerCase"]();
          continue;
        case "8":
          _0x3cf847["aToVU"](-0x1, _0x2a4d89["indexOf"]("tr")) &&
            (Languages["instance"]["language"] = "tr");
          continue;
        case "9":
          _0x3cf847["aToVU"](-0x1, _0x2a4d89["indexOf"]("br")) &&
            (Languages["instance"]["language"] = "br");
          continue;
      }
      break;
    }
  },
  inputListener: function () {
    this["startGame"]();
  },
  startGame: function () {
    var _0x49a72b = {
      QzVhC: function (_0x17451b, _0x4ff52b) {
        return _0x17451b == _0x4ff52b;
      },
      kCoIc: "2|0|5|3|1|6|4",
      WQwaY: "pwrwl-lang",
      WkYOO: function (_0x4ea7b1, _0x257e96) {
        return _0x4ea7b1 + _0x257e96;
      },
      hgCNf: "GameState",
    };
    if (_0x49a72b["QzVhC"](null, sceneLanguages)) {
      var _0x440a5e = _0x49a72b["kCoIc"]["split"]("|"),
        _0x52173b = 0x0;
      while ([]) {
        switch (_0x440a5e[_0x52173b++]) {
          case "0":
            imgBtn["events"]["onInputDown"]["dispose"]();
            continue;
          case "1":
            languageLoaded = !0x0;
            continue;
          case "2":
            imgBtn["inputEnabled"] = !0x1;
            continue;
          case "3":
            try {
              localStorage["setItem"](
                _0x49a72b["WQwaY"],
                _0x49a72b["WkYOO"]("", systemLang)
              );
            } catch (_0x2b376b) {}
            continue;
          case "4":
            _0x49a72b["QzVhC"](null, gameState)
              ? game["state"]["start"](_0x49a72b["hgCNf"])
              : gameState["updateTexts"]();
            continue;
          case "5":
            ScenesTransitions["hideSceneAlpha"](percentageText);
            continue;
          case "6":
            this["HideAnimated"]();
            continue;
        }
        break;
      }
    }
  },
  onResolutionChange: function () {
    var _0x38d7a9 = {
      SPVcq: "3|0|6|1|5|4|2|7",
      MQebl: function (_0x18c102, _0x36d518) {
        return _0x18c102 / _0x36d518;
      },
      TggCA: function (_0x13509d, _0x4627cf) {
        return _0x13509d / _0x4627cf;
      },
      SPWDF: function (_0x104a44, _0x2c0272) {
        return _0x104a44 / _0x2c0272;
      },
      FjBHi: function (_0xddf7cb, _0x18919f) {
        return _0xddf7cb - _0x18919f;
      },
      jNdRL: function (_0x5642e4, _0x11244b) {
        return _0x5642e4 * _0x11244b;
      },
      dwcjN: function (_0x20de0e, _0x28eb16) {
        return _0x20de0e + _0x28eb16;
      },
      QCwIP: function (_0x571359, _0x3e6ef7) {
        return _0x571359 / _0x3e6ef7;
      },
      bADoY: function (_0x11a886, _0xbe67ee) {
        return _0x11a886 / _0xbe67ee;
      },
      PGexo: function (_0x4437d7, _0x575f0f) {
        return _0x4437d7 !== _0x575f0f;
      },
      VvbIs: function (_0x3d7d82, _0x1a17ae) {
        return _0x3d7d82 != _0x1a17ae;
      },
    };
    var _0x2dadcc = _0x38d7a9["SPVcq"]["split"]("|"),
      _0x385533 = 0x0;
    while ([]) {
      switch (_0x2dadcc[_0x385533++]) {
        case "0":
          imgSplash["reset"](
            _0x38d7a9["MQebl"](game["width"], 0x2),
            _0x38d7a9["MQebl"](game["height"], 0x2)
          );
          continue;
        case "1":
          imgBtn["reset"](
            _0x38d7a9["TggCA"](game["width"], 0x2),
            _0x38d7a9["SPWDF"](game["height"], 0x2)
          );
          continue;
        case "2":
          percentageText["reset"](
            this["game"]["world"]["centerX"],
            _0x38d7a9["FjBHi"](this["game"]["height"], 0x14)
          );
          continue;
        case "3":
          loaderPosY = _0x38d7a9["jNdRL"](
            _0x38d7a9["SPWDF"](this["game"]["world"]["height"], 0x5),
            4.5
          );
          continue;
        case "4":
          imgBtn["scale"]["y"] = _0x38d7a9["dwcjN"](
            _0x38d7a9["QCwIP"](game["height"], 0x64),
            0.2
          );
          continue;
        case "5":
          imgBtn["scale"]["x"] = _0x38d7a9["dwcjN"](
            _0x38d7a9["QCwIP"](game["width"], 0x64),
            0.2
          );
          continue;
        case "6":
          imgFrame["reset"](
            _0x38d7a9["bADoY"](game["width"], 0x2),
            _0x38d7a9["bADoY"](game["height"], 0x2)
          );
          continue;
        case "7":
          if (
            _0x38d7a9["PGexo"](void 0x0, sceneLanguages) &&
            _0x38d7a9["VvbIs"](null, sceneLanguages)
          )
            sceneLanguages["onResolutionChange"]();
          continue;
      }
      break;
    }
  },
  HideAnimated: function () {
    ScenesTransitions["TRANSITION_EFFECT_OUT"] =
      Phaser["Easing"]["Linear"]["Out"];
    ScenesTransitions["hideSceneAlpha"](
      grpScenePreload,
      ScenesTransitions["TRANSITION_LENGTH"],
      0x64
    );
    ScenesTransitions["TRANSITION_EFFECT_OUT"] =
      Phaser["Easing"]["Linear"]["Out"];
  },
};
var GameData = function () {};
GameData["BuildTitle"] = "Ferrari\x20488\x20GT3\x20Evo\x20Jigsaw\x20Puzzle";
GameData["BuildDebug"] = !0x1;
GameData["Copyright"] = "GamesFine.com";
console["info"](
  "%c\x20%c\x20\x20\x20" +
    GameData["Copyright"] +
    "\x20|\x20" +
    GameData["BuildTitle"] +
    "\x20\x20%c\x20",
  "background:#353AFB",
  "background:#000080;color:#fff",
  "background:#353AFB"
);
var LevelsLocks = {},
  LevelsMedals = {};
GameData["Reset"] = function () {
  var _0x27e87e = {
    hKoCV: function (_0x282296, _0x219158) {
      return _0x282296 > _0x219158;
    },
    NnkhJ: function (_0x8f7f60, _0x33498a) {
      return _0x8f7f60 + _0x33498a;
    },
    GuaEp: function (_0x2d822a, _0x6e3232) {
      return _0x2d822a + _0x6e3232;
    },
  };
  for (var _0x3679aa = 0x0; _0x27e87e["hKoCV"](0x32, _0x3679aa); _0x3679aa++)
    (LevelsLocks[_0x3679aa] = !0x0),
      (LevelsLocks[_0x27e87e["NnkhJ"](_0x3679aa, 0x32)] = !0x0),
      (LevelsLocks[_0x27e87e["NnkhJ"](_0x3679aa, 0x64)] = !0x0),
      (LevelsMedals[_0x3679aa] = -0x1),
      (LevelsMedals[_0x27e87e["GuaEp"](_0x3679aa, 0x32)] = -0x1),
      (LevelsMedals[_0x27e87e["GuaEp"](_0x3679aa, 0x64)] = -0x1);
  LevelsLocks[0x0] = !0x1;
  LevelsLocks[0x32] = !0x1;
  LevelsLocks[0x64] = !0x1;
};
GameData["Load"] = function () {
  GameData["Reset"]();
  var _0x537ee2 = null;
  try {
    (_0x537ee2 = JSON["parse"](
      localStorage["getItem"](GameData["ProfileName"])
    )),
      (LevelsMedals = _0x537ee2["LevelsMedals"]),
      (LevelsLocks = _0x537ee2["LevelsLocks"]);
  } catch (_0x12ffcf) {}
};
GameData["Save"] = function () {
  var _0x5e60c2 = {};
  _0x5e60c2["LevelsMedals"] = LevelsMedals;
  _0x5e60c2["LevelsLocks"] = LevelsLocks;
  try {
    localStorage["setItem"](
      GameData["ProfileName"],
      JSON["stringify"](_0x5e60c2)
    );
  } catch (_0x4d46d9) {}
};
GameData["ProfileResetVars"] = function () {};
GameData["ProfileSetVars"] = function () {};
GameData["ProfileGetVars"] = function (_0xee3c84) {};
var ID_MODE_EASY = 0x0,
  ID_MODE_MEDIUM = 0x1,
  ID_MODE_HARD = 0x2,
  MATCHED_PAIRS_TO_COMBO = 0x3,
  SCORE_MATCHING_PAIR = 0x64,
  UNDO_PENAULTY_SCORE = 0xc8,
  TIME_BONUS = 0x64,
  ONE_TILE_TIME = 0x3,
  COMBO_TIME = 0x2,
  AUTOHINTING_TIME = 0x5,
  MESSAGE_TIME = 0xf0,
  WAITING_TIME = 0x14,
  TILES_X = 0xa,
  TILES_Y = 0x8,
  TILE_LAYER_DSPX = 0x0,
  TILE_LAYER_DSPY = 0xe,
  TILE_WIDTH = 0x56,
  TILE_HEIGHT = 0x6e,
  TILE_TYPES = 0x7,
  TILES_ID_CIRCLE1 = 0x0,
  TILES_ID_CIRCLE2 = 0x1,
  TILES_ID_CIRCLE3 = 0x2,
  TILES_ID_CIRCLE4 = 0x3,
  TILES_ID_CIRCLE5 = 0x4,
  TILES_ID_CIRCLE6 = 0x5,
  TILES_ID_CIRCLE7 = 0x6,
  TILES_ID_CIRCLE8 = 0x7,
  TILES_ID_CIRCLE9 = 0x8,
  TILES_ID_WIND1 = 0x9,
  TILES_ID_WIND2 = 0xa,
  TILES_ID_WIND3 = 0xb,
  TILES_ID_WIND4 = 0xc,
  TILES_ID_DRAGON1 = 0xd,
  TILES_ID_DRAGON2 = 0xe,
  TILES_ID_DRAGON3 = 0xf,
  TILES_ID_BAMBOO1 = 0x10,
  TILES_ID_BAMBOO2 = 0x11,
  TILES_ID_BAMBOO3 = 0x12,
  TILES_ID_BAMBOO4 = 0x13,
  TILES_ID_BAMBOO5 = 0x14,
  TILES_ID_BAMBOO6 = 0x15,
  TILES_ID_BAMBOO7 = 0x16,
  TILES_ID_BAMBOO8 = 0x17,
  TILES_ID_BAMBOO9 = 0x18,
  TILES_ID_CHARACTER1 = 0x19,
  TILES_ID_CHARACTER2 = 0x1a,
  TILES_ID_CHARACTER3 = 0x1b,
  TILES_ID_CHARACTER4 = 0x1c,
  TILES_ID_CHARACTER5 = 0x1d,
  TILES_ID_CHARACTER6 = 0x1e,
  TILES_ID_CHARACTER7 = 0x1f,
  TILES_ID_CHARACTER8 = 0x20,
  TILES_ID_CHARACTER9 = 0x21,
  TILES_ID_SEASON1 = 0x22,
  TILES_ID_SEASON2 = 0x23,
  TILES_ID_SEASON3 = 0x24,
  TILES_ID_SEASON4 = 0x25,
  TILES_ID_FLOWER1 = 0x26,
  TILES_ID_FLOWER2 = 0x27,
  TILES_ID_FLOWER3 = 0x28,
  TILES_ID_FLOWER4 = 0x29,
  CIRCLE_TILES = 0x0,
  BAMBOO_TILES = 0x1,
  CHARACTER_TILES = 0x2,
  WIND_TILES = 0x3,
  DRAGON_TILES = 0x4,
  FLOWER_TILES = 0x5,
  SEASON_TILES = 0x6,
  ID_COUNTS_FOR_TILE_TYPES = [
    0x4, 0x4, 0x4, 0x0, 0x0, 0x0, 0x0, 0x2, 0x4, 0x4, 0x4, 0x0, 0x0, 0x0, 0x4,
    0x4, 0x4, 0x4, 0x0, 0x0, 0x0, 0x6, 0x6, 0x4, 0x4, 0x0, 0x0, 0x0, 0x8, 0x4,
    0x4, 0x4, 0x4, 0x0, 0x0, 0x4, 0x4, 0x4, 0x4, 0x4, 0x0, 0x0, 0x8, 0x8, 0x8,
    0x4, 0x0, 0x0, 0x0, 0x8, 0x8, 0x8, 0x0, 0x4, 0x0, 0x0, 0x8, 0x8, 0x8, 0x4,
    0x0, 0x4, 0x0, 0x8, 0x8, 0xc, 0x4, 0x4, 0x4, 0x0, 0x8, 0x8, 0x8, 0x0, 0x4,
    0x4, 0x0, 0x8, 0x8, 0x8, 0x4, 0x4, 0x0, 0x0, 0x8, 0x8, 0x8, 0x4, 0x4, 0x4,
    0x0, 0x8, 0x8, 0x8, 0x4, 0x4, 0x4, 0x0, 0xa, 0xa, 0xc, 0x2, 0x6, 0x4, 0x0,
    0x8, 0x8, 0x8, 0x2, 0x6, 0x4, 0x0, 0x8, 0x8, 0x8, 0x4, 0x4, 0x4, 0x4, 0x8,
    0x8, 0x8, 0x4, 0x4, 0x4, 0x4, 0xc, 0x8, 0x8, 0x4, 0x4, 0x4, 0x4, 0xc, 0xc,
    0xc, 0x4, 0x4, 0x4, 0x4, 0xc, 0xa, 0x6, 0x4, 0x4, 0x4, 0x4, 0xc, 0x8, 0x8,
    0x8, 0x4, 0x4, 0x4, 0xc, 0xc, 0x8, 0x4, 0x4, 0x4, 0x4, 0xc, 0xc, 0xc, 0x4,
    0x4, 0x4, 0x4, 0xa, 0xc, 0x10, 0x8, 0x6, 0x4, 0x4, 0xc, 0xa, 0xa, 0x8, 0x4,
    0x4, 0x4, 0xc, 0xc, 0xc, 0x8, 0x4, 0x4, 0x4, 0x10, 0xc, 0xc, 0x4, 0x4, 0x4,
    0x4, 0x10, 0x10, 0xc, 0x4, 0x4, 0x4, 0x4, 0x10, 0x10, 0xe, 0x8, 0x6, 0x4,
    0x4, 0xe, 0x10, 0xa, 0x8, 0x4, 0x4, 0x4, 0x10, 0x10, 0xc, 0x4, 0x8, 0x4,
    0x4, 0x10, 0x10, 0x10, 0x4, 0x4, 0x4, 0x4, 0x10, 0x10, 0x10, 0x8, 0x4, 0x4,
    0x4, 0x10, 0x16, 0x14, 0x8, 0x2, 0x4, 0x4, 0x10, 0x14, 0x10, 0x8, 0x0, 0x4,
    0x4, 0x10, 0x10, 0x10, 0xc, 0x4, 0x4, 0x4, 0x10, 0x10, 0x10, 0x8, 0x8, 0x4,
    0x4, 0x14, 0x10, 0x10, 0x8, 0x8, 0x4, 0x4, 0x14, 0x10, 0x18, 0x8, 0x8, 0x4,
    0x4, 0x10, 0x10, 0x10, 0xc, 0x8, 0x4, 0x4, 0x14, 0x10, 0x10, 0x8, 0xc, 0x4,
    0x4, 0x14, 0x14, 0x10, 0x8, 0x8, 0x4, 0x4, 0x14, 0x14, 0x14, 0x8, 0x8, 0x4,
    0x4, 0x18, 0x16, 0x16, 0xc, 0x4, 0x4, 0x4, 0x14, 0x18, 0x10, 0x8, 0x8, 0x4,
    0x4, 0x14, 0x14, 0x14, 0x8, 0xc, 0x4, 0x4, 0x14, 0x14, 0x14, 0xc, 0x8, 0x4,
    0x4, 0x14, 0x14, 0x14, 0xc, 0xc, 0x4, 0x4, 0x16, 0x18, 0x1a, 0xc, 0x8, 0x4,
    0x4, 0x18, 0x1a, 0x12, 0xc, 0x4, 0x4, 0x4, 0x14, 0x14, 0x14, 0x10, 0xc, 0x4,
    0x4, 0x18, 0x14, 0x14, 0xc, 0xc, 0x4, 0x4, 0x18, 0x18, 0x14, 0xc, 0xc, 0x4,
    0x4, 0x18, 0x18, 0x1c, 0xc, 0x8, 0x8, 0x4, 0x18, 0x1a, 0x14, 0x8, 0xc, 0x4,
    0x8, 0x18, 0x18, 0x14, 0x10, 0xc, 0x4, 0x4, 0x18, 0x18, 0x18, 0xc, 0xc, 0x4,
    0x4, 0x18, 0x18, 0x18, 0x10, 0xc, 0x4, 0x4, 0x18, 0x18, 0x20, 0x8, 0xc, 0x8,
    0x8, 0x1e, 0x1c, 0x14, 0x8, 0x6, 0x8, 0x8, 0x18, 0x18, 0x1c, 0x10, 0xc, 0x4,
    0x4, 0x1c, 0x18, 0x18, 0x10, 0xc, 0x4, 0x4, 0x1c, 0x1c, 0x18, 0x10, 0xc,
    0x4, 0x4, 0x1e, 0x20, 0x20, 0xc, 0x6, 0x8, 0x4, 0x1a, 0x1e, 0x14, 0x10, 0xc,
    0x8, 0x4, 0x1c, 0x20, 0x18, 0x10, 0xc, 0x4, 0x4, 0x1c, 0x1c, 0x1c, 0x10,
    0xc, 0x4, 0x4, 0x20, 0x1c, 0x1c, 0x10, 0xc, 0x4, 0x4, 0x22, 0x22, 0x24, 0x8,
    0xc, 0x4, 0x4, 0x20, 0x1c, 0x1c, 0xc, 0xc, 0x8, 0x8, 0x20, 0x1c, 0x20, 0x10,
    0xc, 0x4, 0x4, 0x20, 0x20, 0x1c, 0x10, 0xc, 0x4, 0x4, 0x20, 0x20, 0x20,
    0x10, 0xc, 0x4, 0x4, 0x20, 0x22, 0x26, 0xc, 0xc, 0x8, 0x4, 0x22, 0x22, 0x1e,
    0xc, 0x6, 0x8, 0x8, 0x20, 0x20, 0x24, 0x10, 0xc, 0x4, 0x4, 0x24, 0x20, 0x20,
    0x10, 0xc, 0x4, 0x4, 0x24, 0x20, 0x24, 0x10, 0xc, 0x4, 0x4, 0x24, 0x20,
    0x28, 0x10, 0xc, 0x8, 0x4, 0x24, 0x24, 0x20, 0x10, 0x8, 0x4, 0x8, 0x24,
    0x24, 0x20, 0x10, 0xc, 0x4, 0x4, 0x24, 0x24, 0x20, 0x10, 0xc, 0x4, 0x8,
    0x24, 0x24, 0x24, 0x10, 0xc, 0x4, 0x4, 0x20, 0x20, 0x2c, 0x10, 0xc, 0x8,
    0x8, 0x24, 0x28, 0x1c, 0x10, 0xc, 0x8, 0x4, 0x24, 0x24, 0x24, 0x10, 0xc,
    0x8, 0x4, 0x26, 0x26, 0x26, 0x10, 0x6, 0x8, 0x4, 0x2a, 0x28, 0x1e, 0xc, 0xc,
    0x8, 0x8, 0x28, 0x28, 0x2a, 0x10, 0x6, 0x8, 0x8, 0x2a, 0x2c, 0x20, 0xc, 0x6,
    0x8, 0x8, 0x2c, 0x28, 0x24, 0xc, 0xc, 0x8, 0x4, 0x28, 0x2e, 0x26, 0xc, 0xc,
    0x0, 0x8, 0x30, 0x2c, 0x26, 0xc, 0x6, 0x4, 0x8, 0x2e, 0x28, 0x2e, 0xc, 0xc,
    0x4, 0x8, 0x2a, 0x2c, 0x1e, 0xc, 0xc, 0x8, 0xc, 0x2c, 0x32, 0x22, 0xc, 0xc,
    0x8, 0x4, 0x32, 0x32, 0x22, 0x8, 0x6, 0x8, 0x8, 0x26, 0x28, 0x2e, 0x10, 0xc,
    0xc, 0x8, 0x2c, 0x2e, 0x24, 0x10, 0x12, 0xc, 0x8,
  ];
function getIDCountsForTileTypes(_0x25a7b1, _0x123cae) {
  var _0x36e73a = {
    WZTLu: function (_0x510b95, _0x3b6d4c) {
      return _0x510b95 + _0x3b6d4c;
    },
    aRPEk: function (_0x4a023a, _0x23e100) {
      return _0x4a023a < _0x23e100;
    },
    RVcgp: function (_0x543d48, _0x3107da) {
      return _0x543d48 * _0x3107da;
    },
  };
  var _0x1401a4 = 0x0;
  switch (_0x25a7b1) {
    case ID_MODE_EASY:
      _0x1401a4 = _0x123cae;
      break;
    case ID_MODE_MEDIUM:
      _0x1401a4 = _0x36e73a["WZTLu"](_0x123cae, 0x14);
      break;
    case ID_MODE_HARD:
      _0x1401a4 = _0x36e73a["WZTLu"](_0x123cae, 0x32);
  }
  for (
    var _0x23c3c8 = [], _0x3fd397 = 0x0;
    _0x36e73a["aRPEk"](_0x3fd397, TILE_TYPES);
    _0x3fd397++
  )
    _0x23c3c8[_0x3fd397] =
      ID_COUNTS_FOR_TILE_TYPES[
        _0x36e73a["WZTLu"](_0x36e73a["RVcgp"](_0x1401a4, TILE_TYPES), _0x3fd397)
      ];
  return _0x23c3c8;
}
function AddButtonEvents(
  _0x1da47e,
  _0x922ec5,
  _0x25d639,
  _0x29f1b6,
  _0x1d5f0b
) {
  var _0x2fb460 = {
    hGSfF: "1|8|2|6|7|3|4|0|5",
    sCCBS: function (_0x428f9a, _0x32ed21) {
      return _0x428f9a === _0x32ed21;
    },
    xwJPT: function (_0x3046c8, _0x1b9155) {
      return _0x3046c8 != _0x1b9155;
    },
  };
  var _0x4cfb7e = _0x2fb460["hGSfF"]["split"]("|"),
    _0x10f4ca = 0x0;
  while ([]) {
    switch (_0x4cfb7e[_0x10f4ca++]) {
      case "0":
        _0x1da47e["events"]["onInputOut"]["add"](_0x29f1b6, {
          button: _0x1da47e,
        });
        continue;
      case "1":
        _0x2fb460["sCCBS"](void 0x0, _0x1d5f0b) && (_0x1d5f0b = null);
        continue;
      case "2":
        _0x1da47e["buttonPressed"] = !0x1;
        continue;
      case "3":
        _0x1da47e["events"]["onInputDown"]["add"](ButtonOnInputDown, {
          button: _0x1da47e,
          callback: _0x922ec5,
        });
        continue;
      case "4":
        _0x1da47e["events"]["onInputOver"]["add"](_0x25d639, {
          button: _0x1da47e,
        });
        continue;
      case "5":
        _0x2fb460["xwJPT"](null, _0x1d5f0b) &&
          _0x1da47e["events"]["onInputUp"]["add"](_0x1d5f0b, {
            button: _0x1da47e,
          });
        continue;
      case "6":
        _0x1da47e["onInputOut"] = _0x29f1b6;
        continue;
      case "7":
        _0x1da47e["onInputUp"] = _0x1d5f0b;
        continue;
      case "8":
        _0x1da47e["inputEnabled"] = !0x0;
        continue;
    }
    break;
  }
}
function ButtonOnInputDown(_0x33832c) {
  var _0x360d37 = { ZvXhh: "spriteHighlighted" };
  ScenesTransitions["transitionActive"] ||
    (this["button"]["hasOwnProperty"](_0x360d37["ZvXhh"]) &&
      (this["button"]["spriteHighlighted"]["tint"] = 0xffffff),
    (this["button"]["tint"] = 0xffffff),
    this["callback"](_0x33832c),
    this["button"]["onInputOut"](this["button"]),
    (this["button"]["buttonPressed"] = !0x0),
    (this["button"]["buttonPressedTime"] =
      game["time"]["totalElapsedSeconds"]()));
}
function ButtonOnInputOver(_0x23e257) {
  var _0x1466ea = {
    KlTtG: function (_0xfa5a8b, _0x317f2c) {
      return _0xfa5a8b === _0x317f2c;
    },
    hRlUS: "spriteHighlighted",
  };
  _0x23e257 = _0x23e257 || this["button"];
  Phaser["Device"]["desktop"] &&
    (_0x1466ea["KlTtG"](void 0x0, _0x23e257["overFrame"])
      ? (_0x23e257["hasOwnProperty"](_0x1466ea["hRlUS"]) &&
          (_0x23e257["spriteHighlighted"]["tint"] = 0x999999),
        (_0x23e257["tint"] = 0x999999))
      : (_0x23e257["frameName"] = _0x23e257["overFrame"]),
    (_0x23e257["cachedTint"] = -0x1));
}
function ButtonOnInputOut(_0x516f23) {
  var _0x2e2d70 = {
    VdjOx: function (_0x38c7ca, _0x205fe5) {
      return _0x38c7ca === _0x205fe5;
    },
    yklsL: "spriteHighlighted",
    duZuO: function (_0x422882, _0x501ff9) {
      return _0x422882 != _0x501ff9;
    },
  };
  _0x516f23 = _0x516f23 || this["button"];
  if (
    Phaser["Device"]["desktop"] &&
    (_0x2e2d70["VdjOx"](void 0x0, _0x516f23["outFrame"])
      ? (_0x516f23["hasOwnProperty"](_0x2e2d70["yklsL"]) &&
          (_0x516f23["spriteHighlighted"]["tint"] = 0xffffff),
        (_0x516f23["tint"] = 0xffffff))
      : (_0x516f23["frameName"] = _0x516f23["outFrame"]),
    (_0x516f23["cachedTint"] = -0x1),
    _0x516f23["buttonPressed"] &&
      ((_0x516f23["buttonPressed"] = !0x1),
      _0x2e2d70["duZuO"](null, _0x516f23["onInputUp"])))
  )
    _0x516f23["onInputUp"](_0x516f23);
}
var ScenesTransitions = function () {};
ScenesTransitions["TRANSITION_LENGTH"] = 0xc8;
ScenesTransitions["TRANSITION_EFFECT_IN"] = Phaser["Easing"]["Linear"]["In"];
ScenesTransitions["TRANSITION_EFFECT_OUT"] = Phaser["Easing"]["Linear"]["Out"];
ScenesTransitions["transitionActive"] = !0x1;
ScenesTransitions["transitionStarted"] = function () {
  ScenesTransitions["transitionActive"] = !0x0;
};
ScenesTransitions["transitionFinished"] = function () {
  ScenesTransitions["transitionActive"] = !0x1;
};
ScenesTransitions["shakeScene"] = function (
  _0x559723,
  _0x45bf72,
  _0x1d3730,
  _0x459bc9,
  _0x4dddc5,
  _0x385f18
) {
  var _0x56dfd7 = {
    PsoHX: "6|11|9|3|4|12|1|0|8|13|5|7|14|10|2",
    BtlKa: function (_0x39ec8b, _0x3f7dfe) {
      return _0x39ec8b === _0x3f7dfe;
    },
    RmDaa: function (_0xc77114, _0x56384b) {
      return _0xc77114 + _0x56384b;
    },
    mmaRs: function (_0x302c59, _0x530c89) {
      return _0x302c59(_0x530c89);
    },
    NideL: function (_0x112211, _0x1c24be) {
      return _0x112211 != _0x1c24be;
    },
    oZHyv: function (_0x36d511, _0x188928) {
      return _0x36d511 === _0x188928;
    },
    BhZPW: function (_0x62be90, _0x2d1083) {
      return _0x62be90 === _0x2d1083;
    },
    FZhMT: function (_0x3176e7, _0x4eccde) {
      return _0x3176e7 === _0x4eccde;
    },
  };
  var _0x52bdb7 = _0x56dfd7["PsoHX"]["split"]("|"),
    _0x39f5b2 = 0x0;
  while ([]) {
    switch (_0x52bdb7[_0x39f5b2++]) {
      case "0":
        var _0x1912d2 = game["add"]["tween"](_0x559723["position"]);
        continue;
      case "1":
        game["tweens"]["removeFrom"](_0x559723, !0x0);
        continue;
      case "2":
        return _0x1912d2;
      case "3":
        _0x56dfd7["BtlKa"](void 0x0, _0x459bc9) &&
          (_0x459bc9 = ScenesTransitions["TRANSITION_LENGTH"]);
        continue;
      case "4":
        _0x56dfd7["BtlKa"](void 0x0, _0x4dddc5) && (_0x4dddc5 = null);
        continue;
      case "5":
        _0x559723["position"]["shakeAmount"] = _0x45bf72;
        continue;
      case "6":
        var _0x213cdc = {
          WFzPw: function (_0x2fa9ca, _0x4c7f46) {
            return _0x56dfd7["RmDaa"](_0x2fa9ca, _0x4c7f46);
          },
          ZCFLG: function (_0x43eff2, _0x43e144) {
            return _0x56dfd7["mmaRs"](_0x43eff2, _0x43e144);
          },
          ZfMvV: function (_0x5d0820, _0x5ec8bd) {
            return _0x56dfd7["RmDaa"](_0x5d0820, _0x5ec8bd);
          },
          daTIn: function (_0x4827f3, _0x2551e2) {
            return _0x56dfd7["NideL"](_0x4827f3, _0x2551e2);
          },
          DRvgf: function (_0x404484, _0x2110b0) {
            return _0x56dfd7["NideL"](_0x404484, _0x2110b0);
          },
        };
        continue;
      case "7":
        _0x1912d2["to"](
          { x: _0x559723["position"]["x"], y: _0x559723["position"]["y"] },
          _0x459bc9,
          Phaser["Easing"]["Cubic"]["InOut"],
          !0x0,
          _0x1d3730
        );
        continue;
      case "8":
        _0x559723["position"]["orgX"] = _0x559723["position"]["x"];
        continue;
      case "9":
        _0x56dfd7["oZHyv"](void 0x0, _0x1d3730) && (_0x1d3730 = 0x0);
        continue;
      case "10":
        _0x1912d2["onComplete"]["add"](
          function () {
            this["scene"]["position"]["x"] = this["scene"]["position"]["orgX"];
            this["scene"]["position"]["y"] = this["scene"]["position"]["orgY"];
            _0x213cdc["DRvgf"](null, this["callbackOnComplete"]) &&
              this["callbackOnComplete"]();
          },
          { scene: _0x559723, callbackOnComplete: _0x4dddc5 }
        );
        continue;
      case "11":
        _0x56dfd7["BhZPW"](void 0x0, _0x45bf72) && (_0x45bf72 = 0x3);
        continue;
      case "12":
        _0x56dfd7["FZhMT"](void 0x0, _0x385f18) && (_0x385f18 = null);
        continue;
      case "13":
        _0x559723["position"]["orgY"] = _0x559723["position"]["y"];
        continue;
      case "14":
        _0x1912d2["onUpdateCallback"](
          function (_0x429cb4, _0x3beccf, _0x1ad4cb) {
            _0x429cb4["target"]["x"] = _0x213cdc["WFzPw"](
              _0x429cb4["target"]["orgX"],
              _0x213cdc["ZCFLG"](
                getRandomInt,
                _0x429cb4["target"]["shakeAmount"]
              )
            );
            _0x429cb4["target"]["y"] = _0x213cdc["ZfMvV"](
              _0x429cb4["target"]["orgY"],
              _0x213cdc["ZCFLG"](
                getRandomInt,
                _0x429cb4["target"]["shakeAmount"]
              )
            );
            _0x213cdc["daTIn"](null, this["callbackOnUpdate"]) &&
              this["callbackOnUpdate"](_0x3beccf);
          },
          { callbackOnUpdate: _0x385f18 }
        );
        continue;
    }
    break;
  }
};
ScenesTransitions["showSceneAlpha"] = function (
  _0x217857,
  _0x5dd88b,
  _0x42e261,
  _0x55c604,
  _0x43f4db
) {
  var _0x546c86 = {
    kyflt: "2|5|4|6|0|8|1|9|3|7|10",
    mgMHO: function (_0x41cfaa, _0x2c1d74) {
      return _0x41cfaa === _0x2c1d74;
    },
    LxovX: function (_0x5c26e5, _0x195c94) {
      return _0x5c26e5 === _0x195c94;
    },
    sgQIU: function (_0x566c80, _0x1a167d) {
      return _0x566c80 === _0x1a167d;
    },
    mCuCF: function (_0x2951cc, _0x51488f) {
      return _0x2951cc / _0x51488f;
    },
  };
  var _0x5177b7 = _0x546c86["kyflt"]["split"]("|"),
    _0x591fe4 = 0x0;
  while ([]) {
    switch (_0x5177b7[_0x591fe4++]) {
      case "0":
        game["tweens"]["removeFrom"](_0x217857, !0x1);
        continue;
      case "1":
        _0x217857["alpha"] = 0x0;
        continue;
      case "2":
        _0x546c86["mgMHO"](void 0x0, _0x5dd88b) && (_0x5dd88b = 0x0);
        continue;
      case "3":
        _0x5dd88b["onComplete"]["add"](ScenesTransitions["onSceneShown"], {
          shownScene: _0x217857,
          callback: _0x55c604,
        });
        continue;
      case "4":
        _0x546c86["LxovX"](void 0x0, _0x55c604) && (_0x55c604 = null);
        continue;
      case "5":
        _0x546c86["sgQIU"](void 0x0, _0x42e261) &&
          (_0x42e261 = _0x546c86["mCuCF"](
            ScenesTransitions["TRANSITION_LENGTH"],
            0x2
          ));
        continue;
      case "6":
        _0x546c86["sgQIU"](void 0x0, _0x43f4db) && (_0x43f4db = 0x1);
        continue;
      case "7":
        _0x5dd88b["start"]();
        continue;
      case "8":
        _0x217857["visible"] = !0x0;
        continue;
      case "9":
        _0x5dd88b = game["add"]
          ["tween"](_0x217857)
          ["to"](
            { alpha: _0x43f4db },
            _0x42e261,
            ScenesTransitions["TRANSITION_EFFECT_IN"],
            !0x1,
            _0x5dd88b
          );
        continue;
      case "10":
        _0x217857["showTween"] = _0x5dd88b;
        continue;
    }
    break;
  }
};
ScenesTransitions["showSceneH"] = function (
  _0x308c5e,
  _0x52a86a,
  _0x51a047,
  _0x78b797,
  _0x3e5ea3
) {
  var _0x1875fa = {
    yKNiZ: "8|2|4|5|0|7|9|6|1|3",
    EUeuj: function (_0x5e6e02, _0x110bd3) {
      return _0x5e6e02 * _0x110bd3;
    },
    RjtCs: function (_0x23e478, _0x2bb110) {
      return _0x23e478 === _0x2bb110;
    },
  };
  var _0x3188b9 = _0x1875fa["yKNiZ"]["split"]("|"),
    _0x1552e6 = 0x0;
  while ([]) {
    switch (_0x3188b9[_0x1552e6++]) {
      case "0":
        _0x308c5e["x"] = _0x1875fa["EUeuj"](
          game["width"],
          _0x52a86a ? -0x2 : 0x2
        );
        continue;
      case "1":
        showTween["start"]();
        continue;
      case "2":
        _0x1875fa["RjtCs"](void 0x0, _0x3e5ea3) && (_0x3e5ea3 = null);
        continue;
      case "3":
        _0x308c5e["showTween"] = showTween;
        continue;
      case "4":
        game["tweens"]["removeFrom"](_0x308c5e, !0x0);
        continue;
      case "5":
        _0x308c5e["visible"] = !0x0;
        continue;
      case "6":
        showTween["onComplete"]["add"](ScenesTransitions["onSceneShown"], {
          shownScene: _0x308c5e,
          callback: _0x3e5ea3,
        });
        continue;
      case "7":
        _0x308c5e["y"] = 0x0;
        continue;
      case "8":
        _0x1875fa["RjtCs"](void 0x0, _0x78b797) &&
          (_0x78b797 = ScenesTransitions["TRANSITION_LENGTH"]);
        continue;
      case "9":
        showTween = game["add"]
          ["tween"](_0x308c5e)
          ["to"](
            { x: 0x0 },
            _0x78b797,
            ScenesTransitions["TRANSITION_EFFECT_IN"],
            !0x1
          );
        continue;
    }
    break;
  }
};
ScenesTransitions["showSceneFromLeft"] = function (
  _0x47e8fe,
  _0x4dcff6,
  _0x2e8abd,
  _0x811772
) {
  var _0x29865f = {
    WxzTC: function (_0x395f7e, _0x3d498d) {
      return _0x395f7e === _0x3d498d;
    },
    FlOIH: function (_0x344735, _0x2e0877) {
      return _0x344735 === _0x2e0877;
    },
  };
  _0x29865f["WxzTC"](void 0x0, _0x4dcff6) && (_0x4dcff6 = 0x0);
  _0x29865f["FlOIH"](void 0x0, _0x2e8abd) &&
    (_0x2e8abd = ScenesTransitions["TRANSITION_LENGTH"]);
  _0x29865f["FlOIH"](void 0x0, _0x811772) && (_0x811772 = null);
  return ScenesTransitions["showSceneH"](
    _0x47e8fe,
    !0x0,
    _0x4dcff6,
    _0x2e8abd,
    _0x811772
  );
};
ScenesTransitions["showSceneV"] = function (
  _0x820528,
  _0x1b52c7,
  _0x2a9e2e,
  _0x5bc3d7,
  _0x39eb62
) {
  var _0x3bbc4a = {
    YMwPM: "1|9|10|4|7|8|3|5|2|6|0",
    BmIqD: function (_0x43a68d, _0x170d44) {
      return _0x43a68d === _0x170d44;
    },
    LJqul: function (_0x555f9e, _0x5cecd7) {
      return _0x555f9e * _0x5cecd7;
    },
    ussfo: function (_0x4cdde6, _0x257776) {
      return _0x4cdde6 === _0x257776;
    },
  };
  var _0x4e360c = _0x3bbc4a["YMwPM"]["split"]("|"),
    _0xb8fc47 = 0x0;
  while ([]) {
    switch (_0x4e360c[_0xb8fc47++]) {
      case "0":
        _0x820528["showTween"] = showTween;
        continue;
      case "1":
        _0x3bbc4a["BmIqD"](void 0x0, _0x2a9e2e) && (_0x2a9e2e = 0x0);
        continue;
      case "2":
        showTween["onComplete"]["add"](ScenesTransitions["onSceneShown"], {
          shownScene: _0x820528,
          callback: _0x39eb62,
        });
        continue;
      case "3":
        _0x820528["y"] = _0x3bbc4a["LJqul"](
          game["height"],
          _0x1b52c7 ? -0x2 : 0x2
        );
        continue;
      case "4":
        game["tweens"]["removeFrom"](_0x820528, !0x0);
        continue;
      case "5":
        showTween = game["add"]
          ["tween"](_0x820528)
          ["to"](
            { y: 0x0 },
            _0x5bc3d7,
            ScenesTransitions["TRANSITION_EFFECT_IN"],
            !0x1,
            _0x2a9e2e
          );
        continue;
      case "6":
        showTween["start"]();
        continue;
      case "7":
        _0x820528["visible"] = !0x0;
        continue;
      case "8":
        _0x820528["x"] = 0x0;
        continue;
      case "9":
        _0x3bbc4a["ussfo"](void 0x0, _0x5bc3d7) &&
          (_0x5bc3d7 = ScenesTransitions["TRANSITION_LENGTH"]);
        continue;
      case "10":
        _0x3bbc4a["ussfo"](void 0x0, _0x39eb62) && (_0x39eb62 = null);
        continue;
    }
    break;
  }
};
ScenesTransitions["showSceneFromTop"] = function (
  _0x5035fe,
  _0x562de7,
  _0x273e02,
  _0x24e241
) {
  var _0xc13b9f = {
    RnGkG: function (_0x14eb37, _0x458e5d) {
      return _0x14eb37 === _0x458e5d;
    },
    IxfYh: function (_0x243893, _0x12c4c5) {
      return _0x243893 === _0x12c4c5;
    },
  };
  _0xc13b9f["RnGkG"](void 0x0, _0x562de7) && (_0x562de7 = 0x0);
  _0xc13b9f["RnGkG"](void 0x0, _0x273e02) &&
    (_0x273e02 = ScenesTransitions["TRANSITION_LENGTH"]);
  _0xc13b9f["IxfYh"](void 0x0, _0x24e241) && (_0x24e241 = null);
  ScenesTransitions["showSceneV"](
    _0x5035fe,
    !0x0,
    _0x562de7,
    _0x273e02,
    _0x24e241
  );
};
ScenesTransitions["showSceneFromBottom"] = function (
  _0x12ab4b,
  _0x505a69,
  _0x40ace6,
  _0x3fdf3c
) {
  var _0x756305 = {
    eTIAe: function (_0x51ac06, _0x423282) {
      return _0x51ac06 === _0x423282;
    },
    XiAYq: function (_0x4d7670, _0xee100c) {
      return _0x4d7670 === _0xee100c;
    },
    RAaAb: function (_0x543547, _0x968b4a) {
      return _0x543547 === _0x968b4a;
    },
  };
  _0x756305["eTIAe"](void 0x0, _0x505a69) && (_0x505a69 = 0x0);
  _0x756305["XiAYq"](void 0x0, _0x40ace6) &&
    (_0x40ace6 = ScenesTransitions["TRANSITION_LENGTH"]);
  _0x756305["RAaAb"](void 0x0, _0x3fdf3c) && (_0x3fdf3c = null);
  return ScenesTransitions["showSceneV"](
    _0x12ab4b,
    !0x1,
    _0x505a69,
    _0x40ace6,
    _0x3fdf3c
  );
};
ScenesTransitions["showSceneFromRight"] = function (
  _0x4ac2c4,
  _0x5aa8e7,
  _0x8865ed,
  _0x10d7b3
) {
  var _0x3a5007 = {
    DMpoU: function (_0x2f6035, _0x433129) {
      return _0x2f6035 === _0x433129;
    },
    cvVfl: function (_0x147159, _0x456e39) {
      return _0x147159 === _0x456e39;
    },
  };
  _0x3a5007["DMpoU"](void 0x0, _0x5aa8e7) && (_0x5aa8e7 = 0x0);
  _0x3a5007["cvVfl"](void 0x0, _0x8865ed) &&
    (_0x8865ed = ScenesTransitions["TRANSITION_LENGTH"]);
  _0x3a5007["cvVfl"](void 0x0, _0x10d7b3) && (_0x10d7b3 = null);
  return ScenesTransitions["showSceneH"](
    _0x4ac2c4,
    !0x1,
    _0x5aa8e7,
    _0x8865ed,
    _0x10d7b3
  );
};
ScenesTransitions["hideSceneAlpha"] = function (
  _0x35e3b7,
  _0x1e9ca8,
  _0x52052e,
  _0x4e175d
) {
  var _0x500d14 = {
    lhLjd: "6|2|8|3|4|5|7|0|1",
    rZGkC: function (_0x7786bd, _0x5e7c45) {
      return _0x7786bd === _0x5e7c45;
    },
    BefjY: function (_0x512a3e, _0x579297) {
      return _0x512a3e / _0x579297;
    },
    AdfvJ: function (_0x33ef53, _0x3dfc8e) {
      return _0x33ef53 === _0x3dfc8e;
    },
  };
  var _0x339d9d = _0x500d14["lhLjd"]["split"]("|"),
    _0x59eeaf = 0x0;
  while ([]) {
    switch (_0x339d9d[_0x59eeaf++]) {
      case "0":
        _0x318caf["start"]();
        continue;
      case "1":
        return (_0x35e3b7["hideTween"] = _0x318caf);
      case "2":
        _0x500d14["rZGkC"](void 0x0, _0x52052e) &&
          (_0x52052e = _0x500d14["BefjY"](
            ScenesTransitions["TRANSITION_LENGTH"],
            0x2
          ));
        continue;
      case "3":
        game["tweens"]["removeFrom"](_0x35e3b7, !0x0);
        continue;
      case "4":
        var _0x318caf = game["add"]["tween"](_0x35e3b7);
        continue;
      case "5":
        _0x318caf["to"](
          { alpha: 0x0 },
          _0x52052e,
          ScenesTransitions["TRANSITION_EFFECT_OUT"],
          !0x1,
          _0x1e9ca8
        );
        continue;
      case "6":
        _0x500d14["rZGkC"](void 0x0, _0x1e9ca8) && (_0x1e9ca8 = 0x0);
        continue;
      case "7":
        _0x318caf["onComplete"]["add"](ScenesTransitions["onSceneHidden"], {
          hiddenScene: _0x35e3b7,
          callback: _0x4e175d,
        });
        continue;
      case "8":
        _0x500d14["AdfvJ"](void 0x0, _0x4e175d) && (_0x4e175d = null);
        continue;
    }
    break;
  }
};
ScenesTransitions["hideSceneH"] = function (
  _0x1bb9c7,
  _0x3aea45,
  _0xb7ea1c,
  _0x1784c0,
  _0x2b18af
) {
  var _0x4928c1 = {
    dFMLv: "6|4|0|1|5|2|7|3",
    uuMpP: function (_0x5cefc7, _0x49a313) {
      return _0x5cefc7 === _0x49a313;
    },
    nDTxk: function (_0x1005fa, _0x59decf) {
      return _0x1005fa * _0x59decf;
    },
    vugkX: function (_0x14dc39, _0xfda9f5) {
      return _0x14dc39 === _0xfda9f5;
    },
  };
  var _0x44fff8 = _0x4928c1["dFMLv"]["split"]("|"),
    _0x4e9a29 = 0x0;
  while ([]) {
    switch (_0x44fff8[_0x4e9a29++]) {
      case "0":
        game["tweens"]["removeFrom"](_0x1bb9c7, !0x0);
        continue;
      case "1":
        _0x1784c0 = game["add"]["tween"](_0x1bb9c7);
        continue;
      case "2":
        _0x1784c0["onComplete"]["add"](ScenesTransitions["onSceneHidden"], {
          hiddenScene: _0x1bb9c7,
          callback: _0x2b18af,
        });
        continue;
      case "3":
        return (_0x1bb9c7["hideTween"] = _0x1784c0);
      case "4":
        _0x4928c1["uuMpP"](void 0x0, _0x2b18af) && (_0x2b18af = null);
        continue;
      case "5":
        _0x1784c0["to"](
          { x: _0x4928c1["nDTxk"](game["width"], _0x3aea45 ? -0x2 : 0x2) },
          ScenesTransitions["TRANSITION_LENGTH"],
          ScenesTransitions["TRANSITION_EFFECT_OUT"],
          _0xb7ea1c
        );
        continue;
      case "6":
        _0x4928c1["vugkX"](void 0x0, _0xb7ea1c) && (_0xb7ea1c = 0x0);
        continue;
      case "7":
        _0x1784c0["start"]();
        continue;
    }
    break;
  }
};
ScenesTransitions["hideSceneToLeft"] = function (
  _0x48b1d6,
  _0x26f6e3,
  _0x37a291,
  _0x156acc
) {
  var _0x4ab715 = {
    vgauq: function (_0x4e3c54, _0x124d84) {
      return _0x4e3c54 === _0x124d84;
    },
  };
  _0x4ab715["vgauq"](void 0x0, _0x26f6e3) && (_0x26f6e3 = 0x0);
  _0x4ab715["vgauq"](void 0x0, _0x37a291) &&
    (_0x37a291 = ScenesTransitions["TRANSITION_LENGTH"]);
  _0x4ab715["vgauq"](void 0x0, _0x156acc) && (_0x156acc = null);
  return ScenesTransitions["hideSceneH"](
    _0x48b1d6,
    !0x0,
    _0x26f6e3,
    _0x37a291,
    _0x156acc
  );
};
ScenesTransitions["hideSceneToRight"] = function (
  _0x408853,
  _0x593f28,
  _0xc8546d,
  _0x400167
) {
  var _0x3e8754 = {
    zppJG: function (_0x4f77fb, _0x41a82a) {
      return _0x4f77fb === _0x41a82a;
    },
  };
  _0x3e8754["zppJG"](void 0x0, _0x593f28) && (_0x593f28 = 0x0);
  _0x3e8754["zppJG"](void 0x0, _0xc8546d) &&
    (_0xc8546d = ScenesTransitions["TRANSITION_LENGTH"]);
  _0x3e8754["zppJG"](void 0x0, _0x400167) && (_0x400167 = null);
  return ScenesTransitions["hideSceneH"](
    _0x408853,
    !0x1,
    _0x593f28,
    _0xc8546d,
    _0x400167
  );
};
ScenesTransitions["hideSceneV"] = function (
  _0x3c25a0,
  _0x25a7a7,
  _0x43c802,
  _0x34e8a8,
  _0x31c67f
) {
  var _0x361bef = {
    sdTkU: "3|1|0|4|5|2|6",
    ITnCb: function (_0xac9ed, _0xd3e15b) {
      return _0xac9ed === _0xd3e15b;
    },
    XnxSs: function (_0x3b2b50, _0x51161b) {
      return _0x3b2b50 * _0x51161b;
    },
  };
  var _0x1dae4c = _0x361bef["sdTkU"]["split"]("|"),
    _0x405447 = 0x0;
  while ([]) {
    switch (_0x1dae4c[_0x405447++]) {
      case "0":
        _0x43c802 = game["add"]["tween"](_0x3c25a0);
        continue;
      case "1":
        game["tweens"]["removeFrom"](_0x3c25a0, !0x0);
        continue;
      case "2":
        _0x43c802["start"]();
        continue;
      case "3":
        _0x361bef["ITnCb"](void 0x0, _0x31c67f) && (_0x31c67f = null);
        continue;
      case "4":
        _0x43c802["to"](
          { y: _0x361bef["XnxSs"](game["height"], _0x25a7a7 ? -0x2 : 0x2) },
          ScenesTransitions["TRANSITION_LENGTH"],
          ScenesTransitions["TRANSITION_EFFECT_OUT"]
        );
        continue;
      case "5":
        _0x43c802["onComplete"]["add"](ScenesTransitions["onSceneHidden"], {
          hiddenScene: _0x3c25a0,
          callback: _0x31c67f,
        });
        continue;
      case "6":
        return (_0x3c25a0["hideTween"] = _0x43c802);
    }
    break;
  }
};
ScenesTransitions["hideSceneToTop"] = function (
  _0x279935,
  _0x2c08f1,
  _0x4e99cd,
  _0x26da54
) {
  var _0x29ff14 = {
    FUWwH: function (_0x1190ec, _0x1922d0) {
      return _0x1190ec === _0x1922d0;
    },
    SsURJ: function (_0xbb5282, _0x2fd01b) {
      return _0xbb5282 === _0x2fd01b;
    },
    SiTkR: function (_0x52f308, _0x146684) {
      return _0x52f308 === _0x146684;
    },
  };
  _0x29ff14["FUWwH"](void 0x0, _0x2c08f1) && (_0x2c08f1 = 0x0);
  _0x29ff14["SsURJ"](void 0x0, _0x4e99cd) &&
    (_0x4e99cd = ScenesTransitions["TRANSITION_LENGTH"]);
  _0x29ff14["SiTkR"](void 0x0, _0x26da54) && (_0x26da54 = null);
  return ScenesTransitions["hideSceneV"](
    _0x279935,
    !0x0,
    _0x2c08f1,
    _0x4e99cd,
    _0x26da54
  );
};
ScenesTransitions["hideSceneToBottom"] = function (
  _0x1e18be,
  _0x540e6f,
  _0x1a1f52,
  _0x35fdeb
) {
  var _0x6360a1 = {
    SQllQ: function (_0x1026a1, _0x352673) {
      return _0x1026a1 === _0x352673;
    },
    eUAnA: function (_0x3abc2d, _0x285f20) {
      return _0x3abc2d === _0x285f20;
    },
  };
  _0x6360a1["SQllQ"](void 0x0, _0x540e6f) && (_0x540e6f = 0x0);
  _0x6360a1["eUAnA"](void 0x0, _0x1a1f52) &&
    (_0x1a1f52 = ScenesTransitions["TRANSITION_LENGTH"]);
  _0x6360a1["eUAnA"](void 0x0, _0x35fdeb) && (_0x35fdeb = null);
  return ScenesTransitions["hideSceneV"](
    _0x1e18be,
    !0x1,
    _0x540e6f,
    _0x1a1f52,
    _0x35fdeb
  );
};
ScenesTransitions["onSceneHidden"] = function () {
  var _0x19c6dd = {
    mXQSN: function (_0x40e239, _0x222809) {
      return _0x40e239(_0x222809);
    },
    XiEgM: function (_0x24fa42, _0x3e194b) {
      return _0x24fa42 + _0x3e194b;
    },
    QCNLM: "onSceneHidden\x20:\x20",
    UkwVv: function (_0x10729c, _0x347119) {
      return _0x10729c != _0x347119;
    },
  };
  _0x19c6dd["mXQSN"](
    LOG,
    _0x19c6dd["XiEgM"](_0x19c6dd["QCNLM"], this["hiddenScene"]["name"])
  );
  this["hiddenScene"]["visible"] = !0x1;
  _0x19c6dd["UkwVv"](null, this["callback"]) && this["callback"]();
};
ScenesTransitions["onSceneShown"] = function () {
  var _0x4910dc = {
    rpBCb: function (_0x189255, _0x26e07d) {
      return _0x189255(_0x26e07d);
    },
    VHyDp: function (_0x317f42, _0xe142d8) {
      return _0x317f42 + _0xe142d8;
    },
    Lhnyp: "onSceneShown:\x20",
    Vrlur: function (_0x58ad43, _0x3be0f4) {
      return _0x58ad43 != _0x3be0f4;
    },
  };
  _0x4910dc["rpBCb"](
    LOG,
    _0x4910dc["VHyDp"](_0x4910dc["Lhnyp"], this["shownScene"]["name"])
  );
  _0x4910dc["Vrlur"](null, this["callback"]) && this["callback"]();
};
ScenesTransitions["showSceneScale"] = function (
  _0x2a7a26,
  _0x57bf80,
  _0x270c8a,
  _0x1c5830,
  _0x52d4d2,
  _0x219b0b
) {
  var _0x165cd0 = {
    JYogC: "8|6|5|7|4|10|3|1|2|9|0",
    GHlHX: function (_0xafb7ec, _0x4fdb6a) {
      return _0xafb7ec === _0x4fdb6a;
    },
    QOCIf: function (_0xfd40f1, _0xfb4023) {
      return _0xfd40f1 / _0xfb4023;
    },
    HsRwb: function (_0x5059f4, _0x2a450f) {
      return _0x5059f4 === _0x2a450f;
    },
  };
  var _0x15d818 = _0x165cd0["JYogC"]["split"]("|"),
    _0x271f33 = 0x0;
  while ([]) {
    switch (_0x15d818[_0x271f33++]) {
      case "0":
        _0x2a7a26["showTween"] = _0x57bf80;
        continue;
      case "1":
        _0x57bf80 = game["add"]
          ["tween"](_0x2a7a26["scale"])
          ["to"](
            { x: _0x219b0b, y: _0x219b0b },
            _0x270c8a,
            _0x52d4d2,
            !0x1,
            _0x57bf80
          );
        continue;
      case "2":
        _0x57bf80["onComplete"]["add"](ScenesTransitions["onSceneShown"], {
          shownScene: _0x2a7a26,
          callback: _0x1c5830,
        });
        continue;
      case "3":
        _0x2a7a26["visible"] = !0x0;
        continue;
      case "4":
        _0x165cd0["GHlHX"](void 0x0, _0x219b0b) && (_0x219b0b = 0x1);
        continue;
      case "5":
        _0x165cd0["GHlHX"](void 0x0, _0x1c5830) && (_0x1c5830 = null);
        continue;
      case "6":
        _0x165cd0["GHlHX"](void 0x0, _0x270c8a) &&
          (_0x270c8a = _0x165cd0["QOCIf"](
            ScenesTransitions["TRANSITION_LENGTH"],
            0x2
          ));
        continue;
      case "7":
        _0x165cd0["HsRwb"](void 0x0, _0x52d4d2) &&
          (_0x52d4d2 = ScenesTransitions["TRANSITION_EFFECT_IN"]);
        continue;
      case "8":
        _0x165cd0["HsRwb"](void 0x0, _0x57bf80) && (_0x57bf80 = 0x0);
        continue;
      case "9":
        _0x57bf80["start"]();
        continue;
      case "10":
        _0x2a7a26["scale"]["set"](0x0);
        continue;
    }
    break;
  }
};
ScenesTransitions["hideSceneScale"] = function (
  _0x11e77d,
  _0x209b6f,
  _0x3df91e,
  _0x3e53db,
  _0x327f13
) {
  var _0x169a74 = {
    VqgQK: "3|6|2|8|0|7|4|1|5",
    OqMTR: function (_0x2e6287, _0x417d1b) {
      return _0x2e6287 === _0x417d1b;
    },
    SqDJP: function (_0x1ba4f7, _0x558789) {
      return _0x1ba4f7 / _0x558789;
    },
    prfZv: function (_0x2d3428, _0x55c60d) {
      return _0x2d3428 === _0x55c60d;
    },
  };
  var _0x5d319c = _0x169a74["VqgQK"]["split"]("|"),
    _0x12bb48 = 0x0;
  while ([]) {
    switch (_0x5d319c[_0x12bb48++]) {
      case "0":
        _0x11e77d["visible"] = !0x0;
        continue;
      case "1":
        _0x209b6f["start"]();
        continue;
      case "2":
        _0x169a74["OqMTR"](void 0x0, _0x3e53db) && (_0x3e53db = null);
        continue;
      case "3":
        _0x169a74["OqMTR"](void 0x0, _0x209b6f) && (_0x209b6f = 0x0);
        continue;
      case "4":
        _0x209b6f["onComplete"]["add"](ScenesTransitions["onSceneHidden"], {
          hiddenScene: _0x11e77d,
          callback: _0x3e53db,
        });
        continue;
      case "5":
        _0x11e77d["hideTween"] = _0x209b6f;
        continue;
      case "6":
        _0x169a74["OqMTR"](void 0x0, _0x3df91e) &&
          (_0x3df91e = _0x169a74["SqDJP"](
            ScenesTransitions["TRANSITION_LENGTH"],
            0x2
          ));
        continue;
      case "7":
        _0x209b6f = game["add"]
          ["tween"](_0x11e77d["scale"])
          ["to"]({ x: 0x0, y: 0x0 }, _0x3df91e, _0x327f13, !0x1, _0x209b6f);
        continue;
      case "8":
        _0x169a74["prfZv"](void 0x0, _0x327f13) &&
          (_0x327f13 = ScenesTransitions["TRANSITION_EFFECT_IN"]);
        continue;
    }
    break;
  }
};
var SceneBackground = function () {
  SceneBackground["instance"] = this;
  this["create"]();
};
SceneBackground["instance"] = null;
SceneBackground["prototype"] = {
  create: function () {
    grpSceneBackgroundCenter = game["add"]["group"]();
  },
  onResolutionChange: function () {},
  update: function () {},
  ShowAnimated: function () {},
};
var SceneLogo = function () {
  SceneLogo["instance"] = this;
  this["create"]();
};
SceneLogo["instance"] = null;
SceneLogo["prototype"] = {
  create: function () {
    grpSceneLogo = game["add"]["group"]();
    grpSceneLogo["visible"] = !0x1;
  },
  onResolutionChange: function () {},
  ShowAnimated: function () {
    ScenesTransitions["showSceneAlpha"](grpSceneLogo);
  },
  HideAnimated: function () {
    ScenesTransitions["hideSceneAlpha"](grpSceneLogo);
  },
};
var MODE_MAIN_MENU = 0x0,
  MODE_PARENTAL_LOCK = 0x1,
  MODE_SETTINGS = 0x2,
  MODE_ABOUT = 0x3,
  MODE_INSTRUCTIONS = 0x4,
  mainMenuMode = MODE_MAIN_MENU,
  androidApp = !0x1,
  enableDebugging = !0x1,
  scrollToTouchTween = null,
  minScrollX,
  maxScrollY,
  WINDOW_HIDE_POS_Y = -0xc8,
  SceneMenu = function () {
    var _0x3a99c3 = {
      iVRnP:
        "36|35|25|49|9|31|40|38|6|24|8|48|23|30|21|2|45|13|33|32|11|14|3|42|43|17|0|27|28|19|46|5|37|15|7|18|34|41|1|20|10|39|12|22|47|4|16|26|29|44",
    };
    var _0x4d19d4 = _0x3a99c3["iVRnP"]["split"]("|"),
      _0x2d7101 = 0x0;
    while ([]) {
      switch (_0x4d19d4[_0x2d7101++]) {
        case "0":
          this["topBounds"];
          continue;
        case "1":
          this["btn3"];
          continue;
        case "2":
          this["selectedMode"] = 0x0;
          continue;
        case "3":
          this["pageWidth"];
          continue;
        case "4":
          this["buttonWidth"];
          continue;
        case "5":
          this["windowSettings"];
          continue;
        case "6":
          this["maxScale"] = 0.8;
          continue;
        case "7":
          this["animationTime"] = 0x96;
          continue;
        case "8":
          this["pageW"];
          continue;
        case "9":
          this["imageGroupY"];
          continue;
        case "10":
          this["groupPositionX"];
          continue;
        case "11":
          this["wheelScrolled"];
          continue;
        case "12":
          this["menuButtonPosY_L"];
          continue;
        case "13":
          this["contentMoveType"] = null;
          continue;
        case "14":
          this["pageHeight"];
          continue;
        case "15":
          this["windowAbout"];
          continue;
        case "16":
          this["buttonSpace"];
          continue;
        case "17":
          this["create"]();
          continue;
        case "18":
          this["question"];
          continue;
        case "19":
          this["windowQuit"];
          continue;
        case "20":
          this["buttonWidth"];
          continue;
        case "21":
          this["actualX"];
          continue;
        case "22":
          this["menuButtonPosY_P"];
          continue;
        case "23":
          this["ScrollPositionY"] = 0x0;
          continue;
        case "24":
          this["startPosX"] = 0x0;
          continue;
        case "25":
          this["dragTime"] = 0x2ee;
          continue;
        case "26":
          this["buttonSpace_L"];
          continue;
        case "27":
          this["leftButton"];
          continue;
        case "28":
          this["rightButton"];
          continue;
        case "29":
          this["buttonSpace_P"];
          continue;
        case "30":
          this["scrollTotalWidth"];
          continue;
        case "31":
          this["groupImages"];
          continue;
        case "32":
          this["contentOriginY"];
          continue;
        case "33":
          this["initClickY"];
          continue;
        case "34":
          this["btn1"];
          continue;
        case "35":
          this["dragInfo"] = null;
          continue;
        case "36":
          SceneMenu["instance"] = this;
          continue;
        case "37":
          this["windowInstructions"];
          continue;
        case "38":
          this["minScale"] = 0.5;
          continue;
        case "39":
          this["menuButtonPosY"];
          continue;
        case "40":
          this["groupShadows"];
          continue;
        case "41":
          this["btn2"];
          continue;
        case "42":
          this["iTouchX"];
          continue;
        case "43":
          this["iTouchY"];
          continue;
        case "44":
          this["scrollPosY"];
          continue;
        case "45":
          this["okTickImg"];
          continue;
        case "46":
          this["windowParent"];
          continue;
        case "47":
          this["buttonGroup"];
          continue;
        case "48":
          this["pageH"];
          continue;
        case "49":
          this["imageGroupX"];
          continue;
      }
      break;
    }
  };
SceneMenu["instance"] = null;
SceneMenu["prototype"] = {
  create: function () {
    var _0xb82502 = {
      IqxDL:
        "36|31|45|61|2|51|22|20|63|43|17|53|33|14|62|4|48|38|27|21|35|47|8|64|40|34|59|68|49|1|10|30|25|11|55|6|60|5|58|19|67|15|18|52|13|29|42|12|24|56|26|28|46|3|44|65|16|66|32|0|57|50|54|9|41|37|39|7|23",
      adVbj: "tmpBtn",
      hZlZA: function (_0x586982, _0x1837aa) {
        return _0x586982 == _0x1837aa;
      },
      efsUu: "pak1",
      QEalz: "button_menu_0",
      UZtej: function (_0x8acb01, _0x85a421) {
        return _0x8acb01 / _0x85a421;
      },
      hrXez: function (_0x9c0a7c, _0x52f606) {
        return _0x9c0a7c / _0x52f606;
      },
      mmtPQ: function (_0x5df365, _0x3b9fcb) {
        return _0x5df365 * _0x3b9fcb;
      },
      xJxub: "white_point",
      SxIBh: function (_0x3edf27, _0x3828fa) {
        return _0x3edf27 >> _0x3828fa;
      },
      xhYGR: function (_0x58fa0d, _0x450da8) {
        return _0x58fa0d - _0x450da8;
      },
      fChfr: function (_0x1e5ec1, _0x4f0aa9) {
        return _0x1e5ec1 >> _0x4f0aa9;
      },
      eQTgF: "menu_back_p",
      lCrOy: function (_0x2498d4, _0x3ca969) {
        return _0x2498d4 == _0x3ca969;
      },
      uvFhe: function (_0x564588, _0x456691, _0x960155, _0x339ebb, _0x3feb3c) {
        return _0x564588(_0x456691, _0x960155, _0x339ebb, _0x3feb3c);
      },
      XfKDF: "0x000000",
      aLMxM: function (_0xa646de, _0x3e4c88, _0x20985f, _0x2fed6e, _0x25ff2c) {
        return _0xa646de(_0x3e4c88, _0x20985f, _0x2fed6e, _0x25ff2c);
      },
      NemHN: function (_0x23deae, _0x5917b2) {
        return _0x23deae + _0x5917b2;
      },
      bXHmZ: function (_0x520a0c, _0x45348e) {
        return _0x520a0c / _0x45348e;
      },
      eXWJI: "grpSceneMenu",
      AWCSl: "icons_all_0",
      kzWPi: "menu_back",
      ZnHrC: function (_0x207f3e, _0x5ce0ed) {
        return _0x207f3e / _0x5ce0ed;
      },
      yCadP: function (_0x242721, _0x35b23a) {
        return _0x242721 / _0x35b23a;
      },
      jWErZ: function (_0x69b66f, _0x78d4e1, _0x5ce82c, _0x14c960, _0x50a6e1) {
        return _0x69b66f(_0x78d4e1, _0x5ce82c, _0x14c960, _0x50a6e1);
      },
      pOBGX: function (_0xf289da, _0x44b662, _0x49a983, _0x5c9798) {
        return _0xf289da(_0x44b662, _0x49a983, _0x5c9798);
      },
      kOqHi: "buttons_2",
      IRCVE: function (_0x13e0e2, _0x1cbfe9) {
        return _0x13e0e2 / _0x1cbfe9;
      },
      SZgKs: function (_0x7972f5, _0x3962a6) {
        return _0x7972f5 / _0x3962a6;
      },
      IxeiL: "fajka",
      wZXFH: function (_0x59fb8e) {
        return _0x59fb8e();
      },
      aaHLS: function (_0x3b1b91, _0x1178a0, _0x151528, _0x4c7466) {
        return _0x3b1b91(_0x1178a0, _0x151528, _0x4c7466);
      },
      SQHmo: "tmpBtn3",
      czIAa: "buttons_3",
    };
    var _0x584ff1 = _0xb82502["IqxDL"]["split"]("|"),
      _0x33079c = 0x0;
    while ([]) {
      switch (_0x584ff1[_0x33079c++]) {
        case "0":
          grpSceneMenu["add"](this["rightButton"]);
          continue;
        case "1":
          this["buttonWidth"] = game["cache"]["getBitmapData"](
            _0xb82502["adVbj"]
          )["width"];
          continue;
        case "2":
          imgBackground["position"]["set"](
            game["world"]["centerX"],
            game["world"]["centerY"]
          );
          continue;
        case "3":
          buttonGroup["anchor"]["set"](0.5);
          continue;
        case "4":
          shadow["width"] = _0x23450a[0x0];
          continue;
        case "5":
          this["okTickImg"]["anchor"]["set"](0.5);
          continue;
        case "6":
          this["menuButtonPosY"] = _0xb82502["hZlZA"](
            GAME_CURRENT_ORIENTATION,
            ORIENTATION_PORTRAIT
          )
            ? this["menuButtonPosY_P"]
            : this["menuButtonPosY_L"];
          continue;
        case "7":
          this["onResolutionChange"]();
          continue;
        case "8":
          this["rightButton"] = game["add"]["sprite"](
            game["width"],
            0x0,
            _0xb82502["efsUu"],
            _0xb82502["QEalz"]
          );
          continue;
        case "9":
          this["createSettingsWindow"]();
          continue;
        case "10":
          this["buttonSpace_L"] = _0xb82502["UZtej"](this["buttonWidth"], 0x4);
          continue;
        case "11":
          this["menuButtonPosY_L"] = _0xb82502["hrXez"](
            _0xb82502["mmtPQ"](
              0x21,
              game["cache"]["getBitmapData"](_0xb82502["adVbj"])["height"]
            ),
            0xc
          );
          continue;
        case "12":
          _0x2d8da1["idx"] = 0x2;
          continue;
        case "13":
          _0x4d07ad["idx"] = 0x1;
          continue;
        case "14":
          shadow = game["make"]["sprite"](
            0x0,
            0x0,
            _0xb82502["efsUu"],
            _0xb82502["xJxub"]
          );
          continue;
        case "15":
          _0x1ed1eb["idx"] = 0x0;
          continue;
        case "16":
          buttonGroup["addChild"](_0x2d8da1);
          continue;
        case "17":
          poly_l = new Phaser["Polygon"]([
            new Phaser["Point"](-0x119, 0x3c),
            new Phaser["Point"](0x122, 0x3c),
            new Phaser["Point"](0x170, 0x98),
            new Phaser["Point"](-0x167, 0x98),
          ]);
          continue;
        case "18":
          var _0x4d07ad = game["add"]["sprite"](
            _0xb82502["SxIBh"](game["width"], 0x1),
            0x0,
            game["cache"]["getBitmapData"](_0xb82502["adVbj"]),
            0x1
          );
          continue;
        case "19":
          var _0x1ed1eb = game["add"]["sprite"](
            _0xb82502["xhYGR"](
              _0xb82502["xhYGR"](
                _0xb82502["fChfr"](game["width"], 0x1),
                this["buttonWidth"]
              ),
              this["buttonSpace"]
            ),
            0x0,
            game["cache"]["getBitmapData"](_0xb82502["adVbj"]),
            0x1
          );
          continue;
        case "20":
          tmpMask = game["add"]["graphics"](
            _0xb82502["fChfr"](game["width"], 0x1),
            _0xb82502["fChfr"](game["height"], 0x1)
          );
          continue;
        case "21":
          grpSceneMenu["add"](imgBackground);
          continue;
        case "22":
          enableDebugging
            ? imgBackground["loadTexture"](_0xb82502["eQTgF"])
            : ((imgBackground["width"] = game["world"]["width"]),
              (imgBackground["scale"]["y"] = imgBackground["scale"]["x"]));
          continue;
        case "23":
          particlesTile = null;
          continue;
        case "24":
          _0xb82502["hZlZA"](0x0, this["selectedMode"])
            ? _0x1ed1eb["addChild"](this["okTickImg"])
            : _0xb82502["hZlZA"](0x1, this["selectedMode"])
            ? _0x4d07ad["addChild"](this["okTickImg"])
            : _0xb82502["lCrOy"](0x2, this["selectedMode"]) &&
              _0x2d8da1["addChild"](this["okTickImg"]);
          continue;
        case "25":
          this["buttonSpace"] = _0xb82502["lCrOy"](
            GAME_CURRENT_ORIENTATION,
            ORIENTATION_PORTRAIT
          )
            ? this["buttonSpace_P"]
            : this["buttonSpace_L"];
          continue;
        case "26":
          _0xb82502["uvFhe"](
            AddButtonEvents,
            _0x4d07ad,
            this["buttonPress"],
            ButtonOnInputOver,
            ButtonOnInputOut
          );
          continue;
        case "27":
          shadow["tint"] = _0xb82502["XfKDF"];
          continue;
        case "28":
          _0xb82502["aLMxM"](
            AddButtonEvents,
            _0x2d8da1,
            this["buttonPress"],
            ButtonOnInputOver,
            ButtonOnInputOut
          );
          continue;
        case "29":
          var _0x2d8da1 = game["add"]["sprite"](
            _0xb82502["NemHN"](
              _0xb82502["NemHN"](
                _0xb82502["fChfr"](game["width"], 0x1),
                this["buttonWidth"]
              ),
              this["buttonSpace"]
            ),
            0x0,
            game["cache"]["getBitmapData"](_0xb82502["adVbj"]),
            0x1
          );
          continue;
        case "30":
          this["buttonSpace_P"] = _0xb82502["bXHmZ"](this["buttonWidth"], 0x4);
          continue;
        case "31":
          grpSceneMenu["name"] = _0xb82502["eXWJI"];
          continue;
        case "32":
          grpSceneMenu["addChild"](shadow);
          continue;
        case "33":
          this["createImageScroll"]();
          continue;
        case "34":
          _0xb82502["aLMxM"](
            AddButtonEvents,
            this["rightButton"],
            this["rightPress"],
            ButtonOnInputOver,
            ButtonOnInputOut
          );
          continue;
        case "35":
          grpSceneMenu["add"](this["groupShadows"]);
          continue;
        case "36":
          grpSceneMenu = game["add"]["group"]();
          continue;
        case "37":
          this["createAboutWindow"]();
          continue;
        case "38":
          shadow["alpha"] = 0x0;
          continue;
        case "39":
          grpSceneMenu["visible"] = !0x1;
          continue;
        case "40":
          this["rightButton"]["addChild"](
            game["make"]["sprite"](
              -this["rightButton"]["width"],
              0x0,
              _0xb82502["efsUu"],
              _0xb82502["AWCSl"]
            )
          );
          continue;
        case "41":
          this["createInstructionWindow"]();
          continue;
        case "42":
          this["createButton"](0x18, _0x23450a, _0x2d8da1, _0x36e9f4);
          continue;
        case "43":
          tmpMask["alpha"] = 0.55;
          continue;
        case "44":
          buttonGroup["addChild"](_0x1ed1eb);
          continue;
        case "45":
          imgBackground = game["make"]["sprite"](0x0, 0x0, _0xb82502["kzWPi"]);
          continue;
        case "46":
          buttonGroup = game["make"]["sprite"](0x0, 0x0);
          continue;
        case "47":
          grpSceneMenu["add"](this["groupImages"]);
          continue;
        case "48":
          shadow["height"] = _0x23450a[0x1];
          continue;
        case "49":
          var _0x23450a = _0xb82502["ZnHrC"](
              -game["cache"]["getBitmapData"](_0xb82502["adVbj"])["height"],
              0x19
            ),
            _0x36e9f4 = game["cache"]["getBitmapData"](_0xb82502["adVbj"])[
              "width"
            ];
          continue;
        case "50":
          this["createQuitWindow"]();
          continue;
        case "51":
          this["scrollPosY"] = 0x50;
          continue;
        case "52":
          this["createButton"](0xc, _0x23450a, _0x4d07ad, _0x36e9f4);
          continue;
        case "53":
          poly_p = new Phaser["Polygon"]([
            new Phaser["Point"](-0xd3, 0x76),
            new Phaser["Point"](0xda, 0x76),
            new Phaser["Point"](0x112, 0xbc),
            new Phaser["Point"](-0x10c, 0xbc),
          ]);
          continue;
        case "54":
          this["createParentWindow"]();
          continue;
        case "55":
          this["menuButtonPosY_P"] = _0xb82502["yCadP"](
            _0xb82502["mmtPQ"](
              0x2c,
              game["cache"]["getBitmapData"](_0xb82502["adVbj"])["height"]
            ),
            0xe
          );
          continue;
        case "56":
          _0xb82502["jWErZ"](
            AddButtonEvents,
            _0x1ed1eb,
            this["buttonPress"],
            ButtonOnInputOver,
            ButtonOnInputOut
          );
          continue;
        case "57":
          this["updateButtonsPosition"]();
          continue;
        case "58":
          this["okTickImg"]["scale"]["set"](0x1);
          continue;
        case "59":
          _0xb82502["pOBGX"](
            create1x3HeightWindowBitmap,
            0x96,
            _0xb82502["adVbj"],
            _0xb82502["kOqHi"]
          );
          continue;
        case "60":
          this["okTickImg"] = game["make"]["sprite"](
            _0xb82502["IRCVE"](_0xb82502["mmtPQ"](0x4, _0x36e9f4), 0xa),
            _0xb82502["SZgKs"](-_0x36e9f4, 0xa),
            _0xb82502["efsUu"],
            _0xb82502["IxeiL"]
          );
          continue;
        case "61":
          imgBackground["anchor"]["set"](0.5);
          continue;
        case "62":
          var _0x23450a = _0xb82502["wZXFH"](getMaxGameResolution);
          continue;
        case "63":
          tmpMask["anchor"]["set"](0.5);
          continue;
        case "64":
          this["rightButton"]["anchor"]["set"](0x1, 0x0);
          continue;
        case "65":
          buttonGroup["addChild"](_0x4d07ad);
          continue;
        case "66":
          grpSceneMenu["add"](buttonGroup);
          continue;
        case "67":
          this["createButton"](0x6, _0x23450a, _0x1ed1eb, _0x36e9f4);
          continue;
        case "68":
          _0xb82502["aaHLS"](
            create1x3HeightWindowBitmap,
            0x64,
            _0xb82502["SQHmo"],
            _0xb82502["czIAa"]
          );
          continue;
      }
      break;
    }
  },
  reinitParticles: function () {
    var _0x1beb8 = {
      Swjxw: function (_0x545b01, _0x396c54) {
        return _0x545b01 > _0x396c54;
      },
    };
    generateNewParticle = !0x0;
    game["time"]["events"]["add"](
      0x1388,
      function () {
        generateNewParticle = !0x1;
      },
      this
    );
    for (i = 0x0; _0x1beb8["Swjxw"](0xa, i); i++)
      this["reinitParticle"](i, !0x0);
  },
  reinitParticle: function (_0x338710, _0x2e2a92) {
    var _0x1bfc1a = {
      COajB: function (_0x2b450b, _0xee2c35) {
        return _0x2b450b * _0xee2c35;
      },
      WQqzW: "pak1",
      fLdRl: "Ball2",
      xqDtM: function (_0x191b35, _0x2f912b) {
        return _0x191b35 / _0x2f912b;
      },
      edngj: function (_0x36306, _0x3f84f7) {
        return _0x36306 / _0x3f84f7;
      },
      TtXbg: function (_0x4c6f8c, _0x2cdddc) {
        return _0x4c6f8c / _0x2cdddc;
      },
      uqVzT: function (_0x4b15d1, _0x421e15) {
        return _0x4b15d1 + _0x421e15;
      },
      lxmiS: function (_0x4062bc, _0x3ee0f9) {
        return _0x4062bc * _0x3ee0f9;
      },
      NKDyI: function (_0x4a2858, _0x28cccf) {
        return _0x4a2858 * _0x28cccf;
      },
      RmUaJ: function (_0x4edc27, _0x38c1a6) {
        return _0x4edc27 * _0x38c1a6;
      },
    };
    generateNewParticle &&
      ((particlesTile[_0x338710] = game["add"]["sprite"](
        _0x1bfc1a["COajB"](-0x14, game["rnd"]["integerInRange"](0x1, 0xa)),
        _0x1bfc1a["COajB"](0xa, game["rnd"]["integerInRange"](0x1, 0xa)),
        _0x1bfc1a["WQqzW"],
        _0x1bfc1a["fLdRl"]
      )),
      particlesTile[_0x338710]["anchor"]["set"](0.5),
      game["physics"]["arcade"]["enable"](
        [particlesTile[_0x338710], kolider],
        !0x0
      ),
      particlesTile[_0x338710]["body"]["setSize"](
        _0x1bfc1a["xqDtM"](
          _0x1bfc1a["xqDtM"](particlesTile[_0x338710]["width"], 0x2),
          particlesTile[i]["scale"]["x"]
        ),
        _0x1bfc1a["xqDtM"](
          _0x1bfc1a["edngj"](particlesTile[i]["height"], 0x2),
          particlesTile[i]["scale"]["y"]
        ),
        _0x1bfc1a["TtXbg"](particlesTile[i]["width"], 0x4),
        _0x1bfc1a["TtXbg"](particlesTile[i]["height"], 0x4)
      ),
      _0x2e2a92 &&
        (particlesTile[_0x338710]["body"]["bounce"]["y"] = _0x1bfc1a["uqVzT"](
          0.7,
          _0x1bfc1a["lxmiS"](0.05, game["rnd"]["integerInRange"](0x1, 0x5))
        )),
      (particlesTile[_0x338710]["body"]["velocity"]["x"] = _0x1bfc1a["uqVzT"](
        0x3c,
        _0x1bfc1a["NKDyI"](0x19, game["rnd"]["integerInRange"](0x1, 0xa))
      )),
      (particlesTile[_0x338710]["body"]["velocity"]["y"] = _0x1bfc1a["RmUaJ"](
        0x32,
        game["rnd"]["integerInRange"](0x1, 0xa)
      )));
  },
  updateBallParticles: function () {
    var _0x463f66 = {
      ySiFR: function (_0x2bfb3c, _0x3c1e50) {
        return _0x2bfb3c != _0x3c1e50;
      },
      fLbJd: function (_0x53bf98, _0x561e85) {
        return _0x53bf98 < _0x561e85;
      },
      GkvWf: function (_0x300086, _0x147e6c) {
        return _0x300086 > _0x147e6c;
      },
      PwIey: function (_0x1ae8b6, _0x4527da) {
        return _0x1ae8b6 > _0x4527da;
      },
      YCjzL: function (_0x45e32b, _0x1c578a) {
        return _0x45e32b >= _0x1c578a;
      },
    };
    if (_0x463f66["ySiFR"](null, particlesTile)) {
      game["physics"]["arcade"]["collide"](particlesTile, kolider);
      for (i = 0x0; _0x463f66["fLbJd"](i, particlesTile["length"]); i++)
        if (
          ((particlesTile[i]["angle"] += 0x3),
          _0x463f66["GkvWf"](particlesTile[i]["x"], game["width"]) ||
            _0x463f66["PwIey"](particlesTile[i]["y"], game["height"]))
        )
          generateNewParticle
            ? this["reinitParticle"](i, !0x0)
            : particlesTile["splice"](i, 0x1);
      _0x463f66["YCjzL"](0x0, particlesTile["length"]) &&
        this["reinitParticles"]();
    }
  },
  createButton: function (_0x4b52cd, _0x3c5352, _0x57e7ba, _0x1e2fdb) {
    var _0x4c15a8 = {
      cwGPf: "9|12|11|2|0|6|7|10|5|4|3|8|15|14|13|1",
      XDLgy: "pak1",
      qVFmo: "icons_all_4",
      mJzvX: "#000000",
      KATxj: function (_0x4c3268, _0x2ba222) {
        return _0x4c3268 + _0x2ba222;
      },
      zPEDP: function (_0x344d13, _0x110dc0) {
        return _0x344d13 + _0x110dc0;
      },
      UEQFM: "#FFFFFF",
      DTsEX: "30px\x20",
      tvxNB: "left",
      PKKtW: function (_0x2b216b, _0x52910c, _0x51822c) {
        return _0x2b216b(_0x52910c, _0x51822c);
      },
      NkhvE: function (_0x38cca2, _0x5bd822, _0xfac1e) {
        return _0x38cca2(_0x5bd822, _0xfac1e);
      },
    };
    var _0x9900c5 = _0x4c15a8["cwGPf"]["split"]("|"),
      _0x2461ac = 0x0;
    while ([]) {
      switch (_0x9900c5[_0x2461ac++]) {
        case "0":
          _0x4b52cd["shadowOffsetY"] = 0x2;
          continue;
        case "1":
          return _0x4b52cd;
        case "2":
          _0x4b52cd["shadowOffsetX"] = 0x2;
          continue;
        case "3":
          _0x3c5352["anchor"]["set"](0x0, 0.5);
          continue;
        case "4":
          _0x3c5352 = game["make"]["sprite"](
            0x0,
            _0x3c5352,
            _0x4c15a8["XDLgy"],
            _0x4c15a8["qVFmo"]
          );
          continue;
        case "5":
          _0x4b52cd["lineSpacing"] = -0x7;
          continue;
        case "6":
          _0x4b52cd["shadowColor"] = _0x4c15a8["mJzvX"];
          continue;
        case "7":
          _0x4b52cd["shadowFill"] = _0x4c15a8["mJzvX"];
          continue;
        case "8":
          _0x3c5352["scale"]["set"](0.7);
          continue;
        case "9":
          _0x4b52cd = new Phaser["Text"](
            game,
            0x0,
            _0x4c15a8["KATxj"](_0x3c5352, 0x2),
            _0x4c15a8["zPEDP"](_0x4b52cd, "\x20"),
            {
              fill: _0x4c15a8["UEQFM"],
              font: _0x4c15a8["zPEDP"](_0x4c15a8["DTsEX"], GAME_FONT),
              wordWrap: !0x0,
              wordWrapWidth: 0x1e0,
              align: _0x4c15a8["tvxNB"],
            }
          );
          continue;
        case "10":
          _0x4b52cd["shadowBlur"] = 0x5;
          continue;
        case "11":
          _0x4b52cd["anchor"]["y"] = _0x4c15a8["PKKtW"](
            getCorrectAnchorY,
            _0x4b52cd,
            0.5
          );
          continue;
        case "12":
          _0x4b52cd["anchor"]["x"] = _0x4c15a8["NkhvE"](
            getCorrectAnchorX,
            _0x4b52cd,
            0x1
          );
          continue;
        case "13":
          _0x57e7ba["anchor"]["set"](0.5);
          continue;
        case "14":
          _0x57e7ba["addChild"](_0x4b52cd);
          continue;
        case "15":
          _0x57e7ba["addChild"](_0x3c5352);
          continue;
      }
      break;
    }
  },
  onResolutionChange: function () {
    var _0xd79301 = {
      nsOnZ: "5|12|2|0|4|11|9|10|8|13|14|1|3|15|7|6",
      EVzxe: function (_0x5057dd, _0x1eabf8) {
        return _0x5057dd - _0x1eabf8;
      },
      nYnHo: function (_0x94e4c2, _0x15cf1c) {
        return _0x94e4c2 + _0x15cf1c;
      },
      sIoYO: function (_0x4d27c4, _0x34c016) {
        return _0x4d27c4 - _0x34c016;
      },
      CvtWF: function (_0x5811e7, _0x56e39f) {
        return _0x5811e7 / _0x56e39f;
      },
      Pfazn: function (_0xc7ca55, _0x5595ed) {
        return _0xc7ca55 * _0x5595ed;
      },
      NbEeG: function (_0x4f4bc6, _0x270860) {
        return _0x4f4bc6 + _0x270860;
      },
      KAqwi: function (_0x3a865e, _0x47aa11) {
        return _0x3a865e == _0x47aa11;
      },
      DnRoj: function (_0x23fe9d, _0x3db449) {
        return _0x23fe9d >> _0x3db449;
      },
      jsizi: function (_0x305b9f, _0x40d635) {
        return _0x305b9f - _0x40d635;
      },
      FPFoE: function (_0x213eb2, _0x46fdf7) {
        return _0x213eb2 / _0x46fdf7;
      },
      ouzkQ: function (_0x46777f, _0x3e2023) {
        return _0x46777f >> _0x3e2023;
      },
      XLgUQ: "menu_back_p",
      KAmFl: function (_0x117f81, _0x823546) {
        return _0x117f81 <= _0x823546;
      },
      cguYY: function (_0x71d9a9, _0x5336b8) {
        return _0x71d9a9 / _0x5336b8;
      },
      FGzxW: "menu_back",
      jCXgN: function (_0x2a7b61, _0x71f8ff) {
        return _0x2a7b61 < _0x71f8ff;
      },
      UKxcw: function (_0x30032a, _0x3383aa) {
        return _0x30032a / _0x3383aa;
      },
      ixDnZ: function (_0x42bd6d, _0x52f45f) {
        return _0x42bd6d / _0x52f45f;
      },
      xmQsT: function (_0x1b5a5b, _0x151903) {
        return _0x1b5a5b * _0x151903;
      },
      jMdVl: function (_0x1f9d94, _0x5d4e80) {
        return _0x1f9d94 < _0x5d4e80;
      },
      CUVtO: function (_0x2a41f9, _0x305561) {
        return _0x2a41f9 <= _0x305561;
      },
    };
    var _0x281859 = _0xd79301["nsOnZ"]["split"]("|"),
      _0x5eff17 = 0x0;
    while ([]) {
      switch (_0x281859[_0x5eff17++]) {
        case "0":
          maxScrollX = _0xd79301["EVzxe"](
            _0xd79301["nYnHo"](
              _0xd79301["sIoYO"](minScrollX, this["groupTotalWidth"]),
              this["pageWidth"]
            ),
            _0xd79301["CvtWF"](_0xd79301["Pfazn"](0x2, game["width"]), 0x9)
          );
          continue;
        case "1":
          this["windowAbout"]["x"] = _0x512ac4;
          continue;
        case "2":
          minScrollX = _0xd79301["NbEeG"](
            _0xd79301["CvtWF"](game["width"], 0x2),
            _0xd79301["CvtWF"](game["width"], 0x9)
          );
          continue;
        case "3":
          _0xd79301["KAqwi"](GAME_CURRENT_ORIENTATION, ORIENTATION_PORTRAIT) &&
            (this["groupImages"]["y"] = _0xd79301["sIoYO"](
              buttonGroup["y"],
              _0xd79301["CvtWF"](
                _0xd79301["Pfazn"](0x4, this["pageHeight"]),
                0x5
              )
            ));
          continue;
        case "4":
          imgBackground["position"]["setTo"](
            _0xd79301["DnRoj"](game["width"], 0x1),
            _0xd79301["DnRoj"](game["height"], 0x1)
          );
          continue;
        case "5":
          this["rightButton"]["x"] = game["width"];
          continue;
        case "6":
          this["iTouchY"] = _0xd79301["jsizi"](
            this["groupImages"]["y"],
            _0xd79301["FPFoE"](this["pageHeight"], 0x2)
          );
          continue;
        case "7":
          this["iTouchX"] = 0x0;
          continue;
        case "8":
          this["windowParent"]["x"] = _0x512ac4;
          continue;
        case "9":
          var _0x512ac4 = _0xd79301["ouzkQ"](game["width"], 0x1);
          continue;
        case "10":
          this["windowQuit"]["x"] = _0x512ac4;
          continue;
        case "11":
          this["updateButtonsPosition"]();
          continue;
        case "12":
          enableDebugging ||
            (_0xd79301["KAqwi"](GAME_CURRENT_ORIENTATION, ORIENTATION_PORTRAIT)
              ? (imgBackground["loadTexture"](_0xd79301["XLgUQ"]),
                _0xd79301["KAmFl"](
                  _0xd79301["jsizi"](game["width"], imgBackground["width"]),
                  _0xd79301["jsizi"](game["height"], imgBackground["height"])
                )
                  ? ((imgBackground["height"] = game["height"]),
                    (imgBackground["scale"]["x"] = imgBackground["scale"]["y"]))
                  : ((imgBackground["width"] = game["width"]),
                    (imgBackground["scale"]["y"] =
                      imgBackground["scale"]["x"])),
                (this["groupImages"]["y"] = _0xd79301["jsizi"](
                  buttonGroup["y"],
                  _0xd79301["cguYY"](
                    _0xd79301["Pfazn"](0x4, this["pageHeight"]),
                    0x5
                  )
                )))
              : (imgBackground["loadTexture"](_0xd79301["FGzxW"]),
                _0xd79301["jCXgN"](imgBackground["height"], game["height"])
                  ? ((imgBackground["height"] = game["height"]),
                    (imgBackground["scale"]["x"] = imgBackground["scale"]["y"]))
                  : ((imgBackground["width"] = game["width"]),
                    (imgBackground["scale"]["y"] =
                      imgBackground["scale"]["x"])),
                (this["groupImages"]["y"] = _0xd79301["UKxcw"](
                  _0xd79301["ixDnZ"](
                    _0xd79301["xmQsT"](0x2, imgBackground["height"]),
                    0x4
                  ),
                  imgBackground["scale"]["x"]
                ))));
          continue;
        case "13":
          this["windowSettings"]["x"] = _0x512ac4;
          continue;
        case "14":
          this["windowInstructions"]["x"] = _0x512ac4;
          continue;
        case "15":
          _0xd79301["jMdVl"](0x0, this["windowInstructions"]["y"]) &&
            _0xd79301["CUVtO"](0.49, shadow["alpha"]) &&
            this["windowInstructions"]["position"]["set"](
              game["world"]["centerX"],
              game["world"]["centerY"]
            );
          continue;
      }
      break;
    }
  },
  update: function () {
    var _0x3c46e0 = {
      heodT: "4|2|3|1|0",
      jqdpl: function (_0x17e701, _0x11ed3d) {
        return _0x17e701 / _0x11ed3d;
      },
      laUYR: "pak1",
      ACave: "img_1",
      xwbok: "3|1|4|2|5|0",
      Ttvuj: function (_0x4b6786, _0x19954b) {
        return _0x4b6786 < _0x19954b;
      },
      erlzN: function (_0x2f1303, _0x5c5cd8) {
        return _0x2f1303 + _0x5c5cd8;
      },
      ljocT: function (_0x50fb07, _0x29bd23) {
        return _0x50fb07 * _0x29bd23;
      },
      cExGw: function (_0x9cf63c, _0x34ed7e) {
        return _0x9cf63c - _0x34ed7e;
      },
      HLjix: function (_0xc26fc1, _0x4ff751) {
        return _0xc26fc1 / _0x4ff751;
      },
      qsHUP: function (_0x3e9d6d, _0x11fd42) {
        return _0x3e9d6d - _0x11fd42;
      },
      fRGeK: function (_0x401ff0, _0x53181f) {
        return _0x401ff0 / _0x53181f;
      },
      ZxVSR: function (_0x53790f, _0x1ea8ed) {
        return _0x53790f * _0x1ea8ed;
      },
    };
    var _0x2a63d0 = _0x3c46e0["heodT"]["split"]("|"),
      _0x5804d0 = 0x0;
    while ([]) {
      switch (_0x2a63d0[_0x5804d0++]) {
        case "0":
          this["updateBallParticles"]();
          continue;
        case "1":
          this["groupImages"]["forEach"](function (_0x5e749a) {
            var _0x25f0da = _0x322ea5["Wsffc"]["split"]("|"),
              _0xb3fad0 = 0x0;
            while ([]) {
              switch (_0x25f0da[_0xb3fad0++]) {
                case "0":
                  _0x4b96b8++;
                  continue;
                case "1":
                  _0x322ea5["omvtH"](_0x3d6b79, _0x1668ad) &&
                    (_0x3ee6e6 = _0x322ea5["CbxLx"](
                      0.4,
                      _0x322ea5["KUpQK"](
                        0.4,
                        _0x322ea5["RbLDb"](
                          0x1,
                          _0x322ea5["fZrOT"](_0x3d6b79, _0x1668ad)
                        )
                      )
                    ));
                  continue;
                case "2":
                  this["groupShadows"]
                    ["getChildAt"](_0x4b96b8)
                    ["scale"]["set"](_0x3ee6e6);
                  continue;
                case "3":
                  var _0x3d6b79 = Math["abs"](
                      _0x322ea5["EcXhw"](
                        _0x5e749a["worldPosition"]["x"],
                        _0x1668ad
                      )
                    ),
                    _0x3ee6e6 = 0.4;
                  continue;
                case "4":
                  _0x5e749a["scale"]["set"](_0x3ee6e6);
                  continue;
                case "5":
                  this["groupShadows"]["getChildAt"](_0x4b96b8)["y"] =
                    _0x322ea5["CbxLx"](
                      this["groupImages"]["y"],
                      _0x322ea5["iMZxH"](
                        _0x322ea5["TepNu"](_0x1d5271, _0x3ee6e6),
                        0x2
                      )
                    );
                  continue;
              }
              break;
            }
          }, this);
          continue;
        case "2":
          var _0x1668ad = _0x3c46e0["jqdpl"](game["width"], 0x2),
            _0x4b96b8 = 0x0,
            _0x1d5271 = game["cache"]["getFrameByName"](
              _0x3c46e0["laUYR"],
              _0x3c46e0["ACave"]
            )["height"];
          continue;
        case "3":
          this["groupShadows"]["x"] = this["dragInfo"]["grp"]["x"];
          continue;
        case "4":
          var _0x322ea5 = {
            Wsffc: _0x3c46e0["xwbok"],
            omvtH: function (_0x4b1994, _0x440626) {
              return _0x3c46e0["Ttvuj"](_0x4b1994, _0x440626);
            },
            CbxLx: function (_0x4106c3, _0x28649f) {
              return _0x3c46e0["erlzN"](_0x4106c3, _0x28649f);
            },
            KUpQK: function (_0xed28db, _0x2c12cd) {
              return _0x3c46e0["ljocT"](_0xed28db, _0x2c12cd);
            },
            RbLDb: function (_0x527e8e, _0x3190c1) {
              return _0x3c46e0["cExGw"](_0x527e8e, _0x3190c1);
            },
            fZrOT: function (_0x5e834f, _0x54a1c5) {
              return _0x3c46e0["HLjix"](_0x5e834f, _0x54a1c5);
            },
            EcXhw: function (_0x6050e2, _0xd8821d) {
              return _0x3c46e0["qsHUP"](_0x6050e2, _0xd8821d);
            },
            iMZxH: function (_0x4545ff, _0x35a36a) {
              return _0x3c46e0["fRGeK"](_0x4545ff, _0x35a36a);
            },
            TepNu: function (_0x3ef688, _0x34c353) {
              return _0x3c46e0["ZxVSR"](_0x3ef688, _0x34c353);
            },
          };
          continue;
      }
      break;
    }
  },
  render: function () {},
  updateTexts: function () {},
  showAds: function () {
    var _0x162177 = {
      BQnvM: function (_0x4811a6, _0x568f87) {
        return _0x4811a6 !== _0x568f87;
      },
      FAYfG: "undefined",
    };
    _0x162177["BQnvM"](_0x162177["FAYfG"], typeof sdk) &&
      _0x162177["BQnvM"](_0x162177["FAYfG"], sdk["showBanner"]) &&
      sdk["showBanner"]();
  },
  OnPressedPlay: function () {
    var _0x2ec172 = {
      HSgrw: "4|6|0|5|8|7|2|9|1|3",
      FlGYg: "levelsEasy",
      QSMrg: "menu-click1",
      QsmiU: function (_0x29c717, _0x49bfc9) {
        return _0x29c717 + _0x49bfc9;
      },
    };
    var _0x59646d = _0x2ec172["HSgrw"]["split"]("|"),
      _0xdb9189 = 0x0;
    while ([]) {
      switch (_0x59646d[_0xdb9189++]) {
        case "0":
          selectedLevelDiff = ID_MODE_EASY;
          continue;
        case "1":
          SceneGame["instance"]["ShowAnimated"]();
          continue;
        case "2":
          SceneMenu["instance"]["HideAnimated"]();
          continue;
        case "3":
          this["showAds"]();
          continue;
        case "4":
          ScenesTransitions["transitionStarted"]();
          continue;
        case "5":
          selectedLevelOffset = 0x0;
          continue;
        case "6":
          selectedLevelFile = _0x2ec172["FlGYg"];
          continue;
        case "7":
          soundManager["playSound"](_0x2ec172["QSMrg"]);
          continue;
        case "8":
          SceneGame["instance"]["startGame"](
            SceneMenu["instance"]["selectedMode"],
            _0x2ec172["QsmiU"](iActualIndex, 0x1)
          );
          continue;
        case "9":
          SceneLogo["instance"]["HideAnimated"]();
          continue;
      }
      break;
    }
  },
  OnPressedPauseLang: function () {
    var _0x487e64 = { zDSDR: "2|3|1|0|4", ABCPl: "menu-click1" };
    var _0x46c03b = _0x487e64["zDSDR"]["split"]("|"),
      _0x28bc2d = 0x0;
    while ([]) {
      switch (_0x46c03b[_0x28bc2d++]) {
        case "0":
          SceneMenu["instance"]["HideAnimated"]();
          continue;
        case "1":
          SceneLogo["instance"]["HideAnimated"]();
          continue;
        case "2":
          soundManager["playSound"](_0x487e64["ABCPl"]);
          continue;
        case "3":
          SceneToReturnFromLanguage = SceneMenu["instance"];
          continue;
        case "4":
          SceneLanguages["instance"]["ShowAnimated"]();
          continue;
      }
      break;
    }
  },
  OnPressedPauseInstructions: function () {
    var _0x37bccc = { fMiBd: "3|1|2|4|0", gIQET: "menu-click1" };
    var _0x10fce3 = _0x37bccc["fMiBd"]["split"]("|"),
      _0x5d4647 = 0x0;
    while ([]) {
      switch (_0x10fce3[_0x5d4647++]) {
        case "0":
          SceneInstructions["instance"]["ShowAnimated"]();
          continue;
        case "1":
          SceneToReturnFromInstructions = SceneMenu["instance"];
          continue;
        case "2":
          SceneLogo["instance"]["HideAnimated"]();
          continue;
        case "3":
          soundManager["playSound"](_0x37bccc["gIQET"]);
          continue;
        case "4":
          SceneMenu["instance"]["HideAnimated"]();
          continue;
      }
      break;
    }
  },
  ShowAnimated: function (_0x2f0b2b) {
    var _0x401a3f = {
      tqwhM: "5|4|2|3|0|1",
      rxyxz: function (_0x3c0e2f, _0x7b069d) {
        return _0x3c0e2f + _0x7b069d;
      },
      BDKum: "music_menu",
      DdVWp: function (_0x28ebf5, _0x43505b) {
        return _0x28ebf5 === _0x43505b;
      },
    };
    var _0x25884f = _0x401a3f["tqwhM"]["split"]("|"),
      _0x4cffa3 = 0x0;
    while ([]) {
      switch (_0x25884f[_0x4cffa3++]) {
        case "0":
          ScenesTransitions["showSceneAlpha"](
            grpSceneMenu,
            _0x401a3f["rxyxz"](_0x2f0b2b, 0x64),
            ScenesTransitions["TRANSITION_LENGTH"],
            ScenesTransitions["transitionFinished"]
          );
          continue;
        case "1":
          ScenesTransitions["TRANSITION_EFFECT_IN"] =
            Phaser["Easing"]["Linear"]["In"];
          continue;
        case "2":
          ScenesTransitions["transitionStarted"]();
          continue;
        case "3":
          ScenesTransitions["TRANSITION_EFFECT_IN"] =
            Phaser["Easing"]["Linear"]["In"];
          continue;
        case "4":
          soundManager["playMusic"](_0x401a3f["BDKum"]);
          continue;
        case "5":
          _0x401a3f["DdVWp"](void 0x0, _0x2f0b2b) && (_0x2f0b2b = 0x0);
          continue;
      }
      break;
    }
  },
  HideAnimated: function () {
    ScenesTransitions["transitionStarted"]();
    ScenesTransitions["TRANSITION_EFFECT_OUT"] =
      Phaser["Easing"]["Linear"]["Out"];
    ScenesTransitions["hideSceneAlpha"](
      grpSceneMenu,
      0x64,
      ScenesTransitions["TRANSITION_LENGTH"],
      ScenesTransitions["transitionFinished"]
    );
    ScenesTransitions["TRANSITION_EFFECT_OUT"] =
      Phaser["Easing"]["Linear"]["Out"];
  },
  screenClickStart: function (_0x449937, _0x2c20a0) {
    SceneMenu["instance"]["groupImages"]["visible"] &&
      ((SceneMenu["instance"]["initClickY"] = _0x2c20a0["y"]),
      (SceneMenu["instance"]["contentOriginY"] =
        SceneMenu["instance"]["groupImages"]["y"]),
      (SceneMenu["instance"]["contentMoveType"] = 0x0));
  },
  screenClickEnd: function (_0x3b94f6, _0x6ed220) {
    var _0x5a0dfe = {
      wbIfk: function (_0x2c86fb, _0x5aa554) {
        return _0x2c86fb - _0x5aa554;
      },
    };
    SceneMenu["instance"]["touchContentMove"] = Math["abs"](
      _0x5a0dfe["wbIfk"](SceneMenu["instance"]["initClickY"], _0x6ed220["y"])
    );
    SceneMenu["instance"]["initClickY"] = null;
    SceneMenu["instance"]["contentMoveType"] = null;
  },
  moveScreenContent: function (_0x4f9c00, _0x58e802) {},
  scrollToMaxLevel: function () {
    var _0x4bd72e = {
      llEvA: function (_0x472949, _0x212274) {
        return _0x472949 - _0x212274;
      },
      MOkCI: function (_0x685979, _0x47430e) {
        return _0x685979 / _0x47430e;
      },
      vSMMu: function (_0xc42884, _0x3043ca) {
        return _0xc42884 + _0x3043ca;
      },
      KQXlg: "level_box",
      PVQeb: function (_0x401872, _0x46e88f) {
        return _0x401872 * _0x46e88f;
      },
      GiTmC: function (_0x2c3a70, _0x24e2c4) {
        return _0x2c3a70 < _0x24e2c4;
      },
    };
    var _0xec2e95 = _0x4bd72e["llEvA"](
        Math["ceil"](
          _0x4bd72e["MOkCI"](_0x4bd72e["vSMMu"](maxLevel, 0x1), 0x4)
        ),
        0x6
      ),
      _0x67ffbe = game["cache"]["getImage"](_0x4bd72e["KQXlg"])["height"];
    SceneMenu["instance"]["groupImages"]["y"] = -_0x4bd72e["PVQeb"](
      _0xec2e95,
      _0x4bd72e["vSMMu"](_0x67ffbe, 0xa)
    );
    _0x4bd72e["GiTmC"](0x0, SceneMenu["instance"]["groupImages"]["y"]) &&
      (SceneMenu["instance"]["groupImages"]["y"] = 0x0);
  },
  updateLevelSelectionScreen: function () {},
  buttonPress: function (_0x3d9123) {
    var _0x2a4f7c = {
      EjAWe: function (_0x1a224d, _0x219209) {
        return _0x1a224d !== _0x219209;
      },
      jDvcs: function (_0x1fe534, _0x53ece8) {
        return _0x1fe534 !== _0x53ece8;
      },
      aNTku: "menu-click1",
    };
    _0x2a4f7c["EjAWe"](void 0x0, _0x3d9123["idx"]) &&
      _0x2a4f7c["jDvcs"](
        SceneMenu["instance"]["selectedMode"],
        _0x3d9123["idx"]
      ) &&
      (soundManager["playSound"](_0x2a4f7c["aNTku"]),
      _0x3d9123["addChildAt"](SceneMenu["instance"]["okTickImg"], 0x0),
      (SceneMenu["instance"]["selectedMode"] = _0x3d9123["idx"]),
      this["showAds"]);
  },
  createImageScroll: function () {
    var _0x4a2631 = {
      nfLrB: "17|2|16|0|15|14|10|6|4|5|13|3|19|12|18|7|1|11|8|9",
      LjYIY: function (_0x2680ce, _0x2daa08) {
        return _0x2680ce - _0x2daa08;
      },
      IziHX: function (_0x130028, _0x5e4a3d) {
        return _0x130028 + _0x5e4a3d;
      },
      PPOsT: function (_0x97a845, _0x17ecdd) {
        return _0x97a845 - _0x17ecdd;
      },
      HLEIE: function (_0x24ffc6, _0x573b93) {
        return _0x24ffc6 / _0x573b93;
      },
      HudiY: function (_0x3b9cd4, _0x19f86a) {
        return _0x3b9cd4 * _0x19f86a;
      },
      bupNl: function (_0x13bf04, _0x3e2e36) {
        return _0x13bf04 * _0x3e2e36;
      },
      mrsaS: function (_0x547e87, _0x25f1d6) {
        return _0x547e87 * _0x25f1d6;
      },
      VgekP: function (_0x3d3305, _0x5ae2b8) {
        return _0x3d3305 >> _0x5ae2b8;
      },
      qjIUj: function (_0x5bf0b7, _0xfb8cf5) {
        return _0x5bf0b7 >= _0xfb8cf5;
      },
      dBVCI: "4|2|0|1|3",
      XtYcL: function (_0x44aecd, _0x222c8c) {
        return _0x44aecd < _0x222c8c;
      },
      YKnoo: "pak1",
      yGaPc: function (_0x4cd3bb, _0x5e82b4) {
        return _0x4cd3bb + _0x5e82b4;
      },
      CsGed: "img_",
      qTQZQ: function (_0x39476f, _0x41abe2) {
        return _0x39476f * _0x41abe2;
      },
      ZxryB: "frame",
      zLVGe: "img_1",
      NMHZh: function (_0x43d048, _0x48cb77) {
        return _0x43d048 == _0x48cb77;
      },
      yubQE: function (_0x129f9c, _0x4e9d39) {
        return _0x129f9c <= _0x4e9d39;
      },
      bnewZ: "1|2|7|5|0|4|6|3",
      yomoJ: function (_0x4c6d5a, _0x49139e) {
        return _0x4c6d5a - _0x49139e;
      },
      PKHou: function (_0x5ac1de, _0xadeade) {
        return _0x5ac1de > _0xadeade;
      },
      dUQfb: "chips",
      pZDxC: function (_0x49eb1e, _0x212b06) {
        return _0x49eb1e < _0x212b06;
      },
      zSDib: "shadow",
      dedJo: function (_0xa12fbf, _0xa2c74) {
        return _0xa12fbf - _0xa2c74;
      },
      upmWn: function (_0x4d53c2, _0x2dbe7a) {
        return _0x4d53c2 + _0x2dbe7a;
      },
      cZWWv: function (_0xd30196, _0x438c49) {
        return _0xd30196 >> _0x438c49;
      },
    };
    var _0x3f643d = _0x4a2631["nfLrB"]["split"]("|"),
      _0xaed0ea = 0x0;
    while ([]) {
      switch (_0x3f643d[_0xaed0ea++]) {
        case "0":
          this["groupImages"] = game["add"]["group"]();
          continue;
        case "1":
          maxScrollX = _0x4a2631["LjYIY"](
            _0x4a2631["IziHX"](
              _0x4a2631["PPOsT"](minScrollX, this["groupTotalWidth"]),
              this["pageWidth"]
            ),
            _0x4a2631["HLEIE"](_0x4a2631["HudiY"](0x2, game["width"]), 0x9)
          );
          continue;
        case "2":
          iActualIndex = 0x1;
          continue;
        case "3":
          this["groupImages"]["x"] = _0x4a2631["PPOsT"](
            _0x4a2631["HLEIE"](game["width"], 0x2),
            _0x4a2631["bupNl"](this["pageWidth"], iActualIndex)
          );
          continue;
        case "4":
          this["pageWidth"] = _0x4a2631["bupNl"](_0x102ff5, this["maxScale"]);
          continue;
        case "5":
          this["groupTotalWidth"] = _0x4a2631["bupNl"](
            _0x4a2631["bupNl"](GROUP_SIZE, _0x102ff5),
            this["maxScale"]
          );
          continue;
        case "6":
          this["pageHeight"] = _0x4a2631["mrsaS"](_0x524112, this["maxScale"]);
          continue;
        case "7":
          minScrollX = _0x4a2631["IziHX"](
            _0x4a2631["HLEIE"](game["width"], 0x2),
            _0x4a2631["HLEIE"](game["width"], 0x9)
          );
          continue;
        case "8":
          this["groupImages"]["forEach"](function (_0x1b8b59) {
            _0x1b8b59 = game["add"]["sprite"](
              _0x1b8b59["x"],
              this["groupImages"]["y"],
              _0x29ce37["fMIOD"],
              _0x29ce37["RvqrK"]
            );
            _0x1b8b59["anchor"]["set"](0.5);
            this["groupShadows"]["addChild"](_0x1b8b59);
          }, this);
          continue;
        case "9":
          this["groupShadows"]["x"] = this["groupImages"]["x"];
          continue;
        case "10":
          this["imageGroupY"] = _0x4a2631["VgekP"](game["height"], 0x1);
          continue;
        case "11":
          if (_0x4a2631["qjIUj"](this["groupTotalWidth"], game["width"])) {
            var _0x440123 = _0x4a2631["dBVCI"]["split"]("|"),
              _0x2dd619 = 0x0;
            while ([]) {
              switch (_0x440123[_0x2dd619++]) {
                case "0":
                  game["input"]["onDown"]["add"](function () {
                    grpSceneMenu["visible"] &&
                      _0x29ce37["OtwCz"](0x0, game["input"]["x"]) &&
                      _0x29ce37["OtwCz"](game["input"]["x"], game["width"]) &&
                      _0x29ce37["NyhRK"](game["input"]["y"], this["iTouchY"]) &&
                      _0x29ce37["nPDqO"](
                        game["input"]["y"],
                        _0x29ce37["FWkIq"](this["iTouchY"], this["pageHeight"])
                      ) &&
                      !_0x24527e["canDrag"] &&
                      (_0x24527e["fadeOutTween"] &&
                        (_0x24527e["fadeOutTween"]["stop"](),
                        (_0x24527e["fadeOutTween"] = null)),
                      (_0x24527e["averageDelta"] = 0x0),
                      (_0x24527e["averageDeltaCount"] = 0x0),
                      (_0x24527e["deltaX"] = 0x0),
                      (_0x24527e["prevX"] = game["input"]["x"]),
                      (_0x24527e["prevY"] = game["input"]["y"]),
                      (_0x24527e["dragging"] = !0x1),
                      (_0x24527e["canDrag"] = !0x0),
                      (_0x24527e["touchUp"] = !0x1));
                  }, this);
                  continue;
                case "1":
                  game["input"]["onUp"]["add"](_0x24527e["onUp"], _0x24527e);
                  continue;
                case "2":
                  this["dragInfo"] = _0x24527e;
                  continue;
                case "3":
                  game["input"]["addMoveCallback"](function () {
                    if (grpSceneMenu["visible"] && _0x24527e["canDrag"]) {
                      var _0x3bce26 = _0x29ce37["QwZsh"]["split"]("|"),
                        _0x4a85e8 = 0x0;
                      while ([]) {
                        switch (_0x3bce26[_0x4a85e8++]) {
                          case "0":
                            _0x24527e["averageDeltaCount"]++;
                            continue;
                          case "1":
                            var _0x50e868 = _0x29ce37["GTNeQ"](
                              game["input"]["x"],
                              _0x24527e["prevX"]
                            );
                            continue;
                          case "2":
                            _0x24527e["prevX"] = game["input"]["x"];
                            continue;
                          case "3":
                            _0x29ce37["VJWFv"](
                              game["input"]["y"],
                              this["imageGroupY"]
                            ) &&
                              _0x29ce37["Ezghb"](
                                game["input"]["y"],
                                _0x29ce37["FWkIq"](
                                  this["imageGroupY"],
                                  this["pageHeight"]
                                )
                              ) &&
                              ((_0x24527e["canDrag"] = !0x1),
                              (_0x24527e["dragging"] = !0x1),
                              (_0x24527e["ghostChip"] = game["add"]["image"](
                                game["input"]["x"],
                                game["input"]["y"],
                                _0x29ce37["ZIODR"],
                                this["pressedChip"]
                              )),
                              (_0x24527e["ghostChip"]["y"] -=
                                _0x24527e["ghostChip"]["height"]),
                              _0x24527e["ghostChip"]["anchor"]["setTo"](0.5),
                              (_0x24527e["ghostChip"]["alpha"] = 0.75));
                            continue;
                          case "4":
                            _0x29ce37["Tjsli"](0x5, Math["abs"](_0x50e868))
                              ? (_0x24527e["dragging"] = !0x0)
                              : (_0x24527e["averageDelta"] /= 0x2);
                            continue;
                          case "5":
                            _0x24527e["averageDelta"] += _0x50e868;
                            continue;
                          case "6":
                            this["scrollChipBar"](_0x50e868);
                            continue;
                          case "7":
                            _0x24527e["deltaX"] = _0x50e868;
                            continue;
                        }
                        break;
                      }
                    }
                  }, this);
                  continue;
                case "4":
                  var _0x24527e = {
                    grp: this["groupImages"],
                    wid: this["pageWidth"],
                    onUp: function () {
                      grpSceneMenu["visible"] &&
                        ((this["touchUp"] = !0x0),
                        this["canDrag"] &&
                          ((this["canDrag"] = !0x1),
                          (this["deltaX"] = this["dragging"]
                            ? _0x29ce37["GCwhu"](
                                this["averageDelta"],
                                this["averageDeltaCount"]
                              )
                            : 0x0),
                          _0x29ce37["OtwCz"](
                            0x5,
                            Math["abs"](this["deltaX"])
                          ) &&
                            ((this["fadeOutTween"] = game["add"]
                              ["tween"](this)
                              ["to"](
                                { deltaX: 0x0 },
                                this["dragTime"],
                                Phaser["Easing"]["Exponential"]["Out"],
                                !0x0
                              )),
                            this["fadeOutTween"]["onUpdateCallback"](
                              function () {
                                SceneMenu["instance"]["scrollChipBar"](
                                  _0x24527e["deltaX"]
                                );
                              },
                              this
                            )),
                          _0x29ce37["GKreU"](null, this["fadeOutTween"]) &&
                            SceneMenu["instance"]["scrollChipBar"](0x0)));
                    },
                  };
                  continue;
              }
              break;
            }
          }
          continue;
        case "12":
          this["iTouchX"] = 0x0;
          continue;
        case "13":
          for (i = 0x0; _0x4a2631["XtYcL"](i, GROUP_SIZE); i++)
            this["groupImages"]["add"](
              game["make"]["sprite"](
                0x0,
                0x0,
                _0x4a2631["YKnoo"],
                _0x4a2631["yGaPc"](
                  _0x4a2631["CsGed"],
                  _0x4a2631["yGaPc"](i, 0x1)
                )
              )
            ),
              (_0x524112 = this["groupImages"]["getChildAt"](i)),
              _0x524112["anchor"]["set"](0.5),
              _0x524112["position"]["set"](
                _0x4a2631["mrsaS"](
                  _0x4a2631["qTQZQ"](i, _0x102ff5),
                  this["maxScale"]
                ),
                0x0
              ),
              _0x524112["scale"]["set"](this["minScale"]),
              (_0x524112["inputEnabled"] = !0x0),
              _0x524112["events"]["onInputUp"]["add"](
                SceneMenu["instance"]["imageClick"]
              ),
              _0x524112["events"]["onInputDown"]["add"](function () {
                SceneMenu["instance"]["groupPositionX"] =
                  SceneMenu["instance"]["groupImages"]["x"];
              }),
              (_0x524112["imageIdx"] = i),
              (_0x524112 = _0x524112["addChild"](
                game["make"]["sprite"](0x0, 0x0, _0x4a2631["ZxryB"])
              )),
              _0x524112["anchor"]["set"](0.5),
              _0x524112["scale"]["set"](0.39);
          continue;
        case "14":
          this["imageGroupX"] = 0x0;
          continue;
        case "15":
          var _0x102ff5 = game["cache"]["getFrameByName"](
              _0x4a2631["YKnoo"],
              _0x4a2631["zLVGe"]
            )["width"],
            _0x524112 = game["cache"]["getFrameByName"](
              _0x4a2631["YKnoo"],
              _0x4a2631["zLVGe"]
            )["height"];
          continue;
        case "16":
          this["groupShadows"] = game["make"]["sprite"](0x0, 0x0);
          continue;
        case "17":
          var _0x29ce37 = {
            GCwhu: function (_0x1f4172, _0xd4bb2f) {
              return _0x4a2631["HLEIE"](_0x1f4172, _0xd4bb2f);
            },
            OtwCz: function (_0xce7ee1, _0x3c721b) {
              return _0x4a2631["XtYcL"](_0xce7ee1, _0x3c721b);
            },
            GKreU: function (_0x433b10, _0x53d5f7) {
              return _0x4a2631["NMHZh"](_0x433b10, _0x53d5f7);
            },
            NyhRK: function (_0x3cf503, _0x2a1165) {
              return _0x4a2631["qjIUj"](_0x3cf503, _0x2a1165);
            },
            nPDqO: function (_0x35ba71, _0x23a817) {
              return _0x4a2631["yubQE"](_0x35ba71, _0x23a817);
            },
            FWkIq: function (_0x1e5cf6, _0x1e0920) {
              return _0x4a2631["yGaPc"](_0x1e5cf6, _0x1e0920);
            },
            QwZsh: _0x4a2631["bnewZ"],
            GTNeQ: function (_0x151e3f, _0x2aa5f6) {
              return _0x4a2631["yomoJ"](_0x151e3f, _0x2aa5f6);
            },
            VJWFv: function (_0x5f2f0a, _0x445236) {
              return _0x4a2631["XtYcL"](_0x5f2f0a, _0x445236);
            },
            Ezghb: function (_0x2a5d84, _0x5aa728) {
              return _0x4a2631["PKHou"](_0x2a5d84, _0x5aa728);
            },
            ZIODR: _0x4a2631["dUQfb"],
            Tjsli: function (_0x270b98, _0x44bbf8) {
              return _0x4a2631["pZDxC"](_0x270b98, _0x44bbf8);
            },
            fMIOD: _0x4a2631["YKnoo"],
            RvqrK: _0x4a2631["zSDib"],
          };
          continue;
        case "18":
          this["iTouchY"] = _0x4a2631["dedJo"](
            this["groupImages"]["y"],
            _0x4a2631["HLEIE"](this["pageHeight"], 0x2)
          );
          continue;
        case "19":
          this["groupImages"]["y"] = _0x4a2631["upmWn"](
            _0x4a2631["cZWWv"](game["height"], 0x1),
            _0x4a2631["qTQZQ"](this["scrollPosY"], imgBackground["scale"]["x"])
          );
          continue;
      }
      break;
    }
  },
  imageClick: function (_0x2c98a0) {
    var _0x401983 = {
      rpJfA: function (_0x4a0877, _0x535fed) {
        return _0x4a0877 >= _0x535fed;
      },
      EPqUG: function (_0x39b104, _0x119e73) {
        return _0x39b104 - _0x119e73;
      },
      KvLYP: function (_0xa493f7, _0x6fecca) {
        return _0xa493f7 / _0x6fecca;
      },
      zTmzH: function (_0x1195be, _0x28ca1e) {
        return _0x1195be - _0x28ca1e;
      },
      lReNR: function (_0x13a180, _0x30f9f6) {
        return _0x13a180 / _0x30f9f6;
      },
      huNRQ: function (_0x2bc952, _0x473923) {
        return _0x2bc952 == _0x473923;
      },
      tLVXy: function (_0x5ba6b0, _0x5780d9) {
        return _0x5ba6b0 >= _0x5780d9;
      },
      kROIu: function (_0x32c05f, _0xb15d4d) {
        return _0x32c05f % _0xb15d4d;
      },
      lRxob: function (_0x6d1c85, _0x328919) {
        return _0x6d1c85 - _0x328919;
      },
      DivkI: function (_0x3ca60f, _0x505983) {
        return _0x3ca60f / _0x505983;
      },
      VrmpV: function (_0x2ac282, _0x5e431d) {
        return _0x2ac282 * _0x5e431d;
      },
      NsKje: function (_0x49e3b3, _0x1cbe96) {
        return _0x49e3b3 / _0x1cbe96;
      },
    };
    _0x401983["rpJfA"](
      0x2,
      Math["abs"](
        _0x401983["EPqUG"](
          SceneMenu["instance"]["groupPositionX"],
          SceneMenu["instance"]["groupImages"]["x"]
        )
      )
    ) &&
      ((iActualIndex = Math["abs"](
        Math["round"](
          _0x401983["KvLYP"](
            _0x401983["zTmzH"](
              SceneMenu["instance"]["groupImages"]["x"],
              _0x401983["lReNR"](game["width"], 0x2)
            ),
            SceneMenu["instance"]["pageWidth"]
          )
        )
      )),
      _0x401983["huNRQ"](iActualIndex, _0x2c98a0["imageIdx"])
        ? _0x401983["tLVXy"](
            0x1,
            Math["abs"](
              Math["round"](
                _0x401983["kROIu"](
                  _0x401983["lRxob"](
                    SceneMenu["instance"]["groupImages"]["x"],
                    _0x401983["DivkI"](game["width"], 0x2)
                  ),
                  SceneMenu["instance"]["pageWidth"]
                )
              )
            )
          )
          ? SceneMenu["instance"]["OnPressedPlay"]()
          : (scrollToTouchTween = game["add"]
              ["tween"](SceneMenu["instance"]["groupImages"])
              ["to"](
                {
                  x: _0x401983["lRxob"](
                    _0x401983["DivkI"](game["width"], 0x2),
                    _0x401983["VrmpV"](
                      SceneMenu["instance"]["pageWidth"],
                      iActualIndex
                    )
                  ),
                },
                0xfa,
                Phaser["Easing"]["Exponential"]["Out"],
                !0x0
              )
              ["onComplete"]["add"](function () {
                scrollToTouchTween = null;
              }, this))
        : (scrollToTouchTween = game["add"]
            ["tween"](SceneMenu["instance"]["groupImages"])
            ["to"](
              {
                x: _0x401983["lRxob"](
                  _0x401983["NsKje"](game["width"], 0x2),
                  _0x401983["VrmpV"](
                    SceneMenu["instance"]["pageWidth"],
                    _0x2c98a0["imageIdx"]
                  )
                ),
              },
              0xfa,
              Phaser["Easing"]["Exponential"]["Out"],
              !0x0
            )
            ["onComplete"]["add"](function () {
              scrollToTouchTween = null;
            }, this)));
  },
  scrollChipBar: function (_0xaf80c4) {
    var _0x4cb19b = {
      tDWxQ: function (_0x1e31bc, _0x40d675) {
        return _0x1e31bc == _0x40d675;
      },
      VzcTR: function (_0x5bf953, _0x2b8a83) {
        return _0x5bf953 != _0x2b8a83;
      },
      KauAd: "6|1|3|5|2|4|0",
      omSHl: function (_0x4842c8, _0x463b6c) {
        return _0x4842c8 >= _0x463b6c;
      },
      otOpt: function (_0x2e9211, _0x404175) {
        return _0x2e9211 == _0x404175;
      },
      WLJVP: function (_0x245503, _0x1c355f) {
        return _0x245503 % _0x1c355f;
      },
      WjZzQ: function (_0x5ecf74, _0x4a6585) {
        return _0x5ecf74 - _0x4a6585;
      },
      tBVlw: function (_0x33b812, _0x2d1d75) {
        return _0x33b812 / _0x2d1d75;
      },
      dztcj: function (_0x28a741, _0xfe7581) {
        return _0x28a741 - _0xfe7581;
      },
      dLiJn: function (_0x2af03c, _0x45d6af) {
        return _0x2af03c * _0x45d6af;
      },
      MUTgN: function (_0x465325, _0x4b1a04) {
        return _0x465325 * _0x4b1a04;
      },
      XCbLs: function (_0x4ba97b, _0x248dbf) {
        return _0x4ba97b - _0x248dbf;
      },
      HLosg: function (_0x2911c7, _0x57f226) {
        return _0x2911c7 <= _0x57f226;
      },
      LqZmY: function (_0x146a1b, _0x4bad63) {
        return _0x146a1b > _0x4bad63;
      },
      qelaU: function (_0x1896b9, _0x176c57) {
        return _0x1896b9 < _0x176c57;
      },
    };
    if (
      _0x4cb19b["tDWxQ"](mainMenuMode, MODE_MAIN_MENU) &&
      _0x4cb19b["VzcTR"](0x0, _0xaf80c4)
    ) {
      var _0x5ec42f = _0x4cb19b["KauAd"]["split"]("|"),
        _0x14366e = 0x0;
      while ([]) {
        switch (_0x5ec42f[_0x14366e++]) {
          case "0":
            this["dragInfo"]["touchUp"] &&
              _0x4cb19b["omSHl"](0.3, Math["abs"](_0xaf80c4)) &&
              (_0x4cb19b["otOpt"](
                0x0,
                Math["abs"](
                  Math["round"](
                    _0x4cb19b["WLJVP"](
                      _0x4cb19b["WjZzQ"](
                        SceneMenu["instance"]["groupImages"]["x"],
                        _0x4cb19b["tBVlw"](game["width"], 0x2)
                      ),
                      SceneMenu["instance"]["pageWidth"]
                    )
                  )
                )
              )
                ? _0x4cb19b["VzcTR"](
                    void 0x0,
                    this["dragInfo"]["fadeOutTween"]
                  ) &&
                  (this["dragInfo"]["fadeOutTween"]["stop"](),
                  (this["dragInfo"]["fadeOutTween"] = null))
                : (_0x4cb19b["VzcTR"](
                    void 0x0,
                    this["dragInfo"]["fadeOutTween"]
                  ) &&
                    (this["dragInfo"]["fadeOutTween"]["stop"](),
                    (this["dragInfo"]["fadeOutTween"] = null)),
                  game["add"]
                    ["tween"](SceneMenu["instance"]["groupImages"])
                    ["to"](
                      {
                        x: _0x4cb19b["dztcj"](
                          _0x4cb19b["tBVlw"](game["width"], 0x2),
                          _0x4cb19b["dLiJn"](
                            SceneMenu["instance"]["pageWidth"],
                            iActualIndex
                          )
                        ),
                      },
                      0xfa,
                      Phaser["Easing"]["Exponential"]["Out"],
                      !0x0
                    ),
                  game["add"]
                    ["tween"](SceneMenu["instance"]["groupShadows"])
                    ["to"](
                      {
                        x: _0x4cb19b["dztcj"](
                          _0x4cb19b["tBVlw"](game["width"], 0x2),
                          _0x4cb19b["MUTgN"](
                            SceneMenu["instance"]["pageWidth"],
                            iActualIndex
                          )
                        ),
                      },
                      0xfa,
                      Phaser["Easing"]["Exponential"]["Out"],
                      !0x0
                    )));
            continue;
          case "1":
            _0x3c385e["x"] += _0xaf80c4;
            continue;
          case "2":
            this["groupShadows"]["x"] = this["dragInfo"]["grp"]["x"];
            continue;
          case "3":
            _0x3c385e["x"] = Math["floor"](_0x3c385e["x"]);
            continue;
          case "4":
            iActualIndex = Math["abs"](
              Math["round"](
                _0x4cb19b["tBVlw"](
                  _0x4cb19b["XCbLs"](
                    _0x3c385e["x"],
                    _0x4cb19b["tBVlw"](game["width"], 0x2)
                  ),
                  this["dragInfo"]["wid"]
                )
              )
            );
            continue;
          case "5":
            _0x4cb19b["HLosg"](_0x3c385e["x"], maxScrollX) &&
            _0x4cb19b["LqZmY"](0x0, _0xaf80c4)
              ? ((_0x3c385e["x"] = maxScrollX), (_0xaf80c4 = 0x0))
              : _0x4cb19b["omSHl"](_0x3c385e["x"], minScrollX) &&
                _0x4cb19b["qelaU"](0x0, _0xaf80c4) &&
                ((_0x3c385e["x"] = minScrollX), (_0xaf80c4 = 0x0));
            continue;
          case "6":
            var _0x3c385e = this["dragInfo"]["grp"];
            continue;
        }
        break;
      }
    }
  },
  leftPress: function (_0x57974a) {
    var _0x1077f5 = {
      hLzAA: function (_0x25c37e, _0x55b1b3) {
        return _0x25c37e == _0x55b1b3;
      },
    };
    _0x1077f5["hLzAA"](mainMenuMode, MODE_MAIN_MENU) &&
      SceneMenu["instance"]["hideButtons"](MODE_INSTRUCTIONS);
  },
  rightPress: function (_0x23b55f) {
    var _0x2aa66f = {
      lFAdB: "menu-click1",
      gFcmF: function (_0x4727b4, _0x3cd6fc) {
        return _0x4727b4 == _0x3cd6fc;
      },
      bgfOc: function (_0x5b6f48, _0x28c1e3) {
        return _0x5b6f48 == _0x28c1e3;
      },
    };
    soundManager["playSound"](_0x2aa66f["lFAdB"]);
    _0x2aa66f["gFcmF"](mainMenuMode, MODE_MAIN_MENU)
      ? SceneMenu["instance"]["hideButtons"](MODE_INSTRUCTIONS)
      : _0x2aa66f["gFcmF"](mainMenuMode, MODE_PARENTAL_LOCK)
      ? SceneMenu["instance"]["returnFromLockToMenu"]()
      : _0x2aa66f["gFcmF"](mainMenuMode, MODE_SETTINGS)
      ? SceneMenu["instance"]["returnFromSettingsToMenu"]()
      : _0x2aa66f["bgfOc"](mainMenuMode, MODE_ABOUT)
      ? SceneMenu["instance"]["returnFromAboutToSettings"]()
      : _0x2aa66f["bgfOc"](mainMenuMode, MODE_INSTRUCTIONS) &&
        SceneMenu["instance"]["returnFromInstructionToMenu"]();
  },
  hideButtons: function (_0x3327a5) {
    var _0x3aa6db = {
      lDVBh: function (_0x1cb432, _0xdc2da0) {
        return _0x1cb432 + _0xdc2da0;
      },
    };
    game["add"]
      ["tween"](this["rightButton"])
      ["to"](
        {
          x: _0x3aa6db["lDVBh"](game["width"], this["rightButton"]["width"]),
          y: -this["rightButton"]["height"],
        },
        this["animationTime"],
        Phaser["Easing"]["Linear"]["none"],
        !0x0
      )
      ["onComplete"]["add"](function () {
        SceneMenu["instance"]["changeMode"](_0x3327a5);
      }, this);
  },
  showButtons: function (_0x5d95db) {
    endPosX = game["world"]["width"];
    game["add"]
      ["tween"](this["rightButton"])
      ["to"](
        { x: game["world"]["width"], y: 0x0 },
        this["animationTime"],
        Phaser["Easing"]["Linear"]["none"],
        !0x0
      );
  },
  changeMode: function (_0x277f3e) {
    var _0x26e23d = {
      qChEl: function (_0x5b90f4, _0x15aec2) {
        return _0x5b90f4 == _0x15aec2;
      },
      mCRRj: "icons_all_0",
      EijvB: function (_0x334625, _0x2a8de9) {
        return _0x334625 == _0x2a8de9;
      },
      oDURX: function (_0xdee473, _0x1c72e7) {
        return _0xdee473 == _0x1c72e7;
      },
      uQvls: "icons_all_3",
    };
    mainMenuMode = _0x277f3e;
    _0x26e23d["qChEl"](mainMenuMode, MODE_PARENTAL_LOCK)
      ? (SceneMenu["instance"]["showParentScreen"](),
        (this["rightButton"]["getChildAt"](0x0)["frame"] = 0x2))
      : _0x26e23d["qChEl"](mainMenuMode, MODE_MAIN_MENU)
      ? (game["add"]
          ["tween"](shadow)
          ["to"](
            { alpha: 0x0 },
            0x96,
            Phaser["Easing"]["Linear"]["none"],
            !0x0
          ),
        (shadow["inputEnabled"] = !0x1),
        (this["rightButton"]["getChildAt"](0x0)["frameName"] =
          _0x26e23d["mCRRj"]))
      : _0x26e23d["qChEl"](mainMenuMode, MODE_SETTINGS)
      ? (SceneMenu["instance"]["showSettingsScreen"](),
        (this["rightButton"]["getChildAt"](0x0)["frame"] = 0x2))
      : _0x26e23d["EijvB"](mainMenuMode, MODE_ABOUT)
      ? (SceneMenu["instance"]["showAboutScreen"](),
        (this["rightButton"]["getChildAt"](0x0)["frame"] = 0x2))
      : _0x26e23d["oDURX"](mainMenuMode, MODE_INSTRUCTIONS) &&
        ((shadow["inputEnabled"] = !0x0),
        game["add"]
          ["tween"](shadow)
          ["to"](
            { alpha: 0.5 },
            0x96,
            Phaser["Easing"]["Linear"]["none"],
            !0x0
          ),
        SceneMenu["instance"]["showInstructionsScreen"](),
        (this["rightButton"]["getChildAt"](0x0)["frameName"] =
          _0x26e23d["uQvls"]));
    SceneMenu["instance"]["showButtons"](_0x277f3e);
  },
  createQuitWindow: function () {
    var _0x2a12c8 = {
      LTyNw: "10|12|18|6|14|3|9|1|0|19|5|17|11|15|13|7|4|2|8|16",
      nBVwI: function (_0x1a9565, _0x5c7485, _0x1505d2) {
        return _0x1a9565(_0x5c7485, _0x1505d2);
      },
      MDmto: function (_0x13ba1a, _0x543c07) {
        return _0x13ba1a + _0x543c07;
      },
      QBIZw: function (_0x399c9d, _0x23aef6) {
        return _0x399c9d - _0x23aef6;
      },
      lMluN: function (_0x26a4b2, _0x369885) {
        return _0x26a4b2 / _0x369885;
      },
      MbroC: "menu_window",
      eGEvh: function (_0x221e79, _0x5ee1cf) {
        return _0x221e79 / _0x5ee1cf;
      },
      lvsWY: "pak1",
      lPVOB: "dialog_header",
      qAyJr: "HEADER",
      QqJDY: "#F99111",
      xUXzE: "72px\x20",
      sfZfM: "center",
      AhrvI: function (_0x4d6f61, _0x58a1bd) {
        return _0x4d6f61 / _0x58a1bd;
      },
      GUTUp: function (_0x18e0be, _0x5c42b3) {
        return _0x18e0be / _0x5c42b3;
      },
      ZdFjy: "#000000",
    };
    var _0x347f4a = _0x2a12c8["LTyNw"]["split"]("|"),
      _0x586d1d = 0x0;
    while ([]) {
      switch (_0x347f4a[_0x586d1d++]) {
        case "0":
          _0x39f568["anchor"]["x"] = _0x2a12c8["nBVwI"](
            getCorrectAnchorX,
            _0x39f568,
            0.5
          );
          continue;
        case "1":
          var _0x39f568 = new Phaser["Text"](
            game,
            0x0,
            _0x2a12c8["MDmto"](
              _0x2a12c8["QBIZw"](
                _0x2a12c8["lMluN"](
                  -game["cache"]["getImage"](_0x2a12c8["MbroC"])["height"],
                  0x2
                ),
                _0x2a12c8["eGEvh"](
                  game["cache"]["getFrameByName"](
                    _0x2a12c8["lvsWY"],
                    _0x2a12c8["lPVOB"]
                  )["height"],
                  0x2
                )
              ),
              0x8
            ),
            _0x2a12c8["qAyJr"],
            {
              fill: _0x2a12c8["QqJDY"],
              font: _0x2a12c8["MDmto"](_0x2a12c8["xUXzE"], GAME_FONT),
              wordWrap: !0x0,
              wordWrapWidth: 0x1e0,
              align: _0x2a12c8["sfZfM"],
            }
          );
          continue;
        case "2":
          this["windowQuit"]["addChild"](_0x39f568);
          continue;
        case "3":
          _0x218b03["anchor"]["set"](0.5);
          continue;
        case "4":
          this["windowQuit"]["addChild"](_0x218b03);
          continue;
        case "5":
          _0x39f568["shadowOffsetX"] = 0x2;
          continue;
        case "6":
          this["windowQuit"]["position"]["set"](
            game["world"]["centerX"],
            game["world"]["centerY"]
          );
          continue;
        case "7":
          _0x39f568["lineSpacing"] = -0x7;
          continue;
        case "8":
          grpSceneMenu["add"](this["windowQuit"]);
          continue;
        case "9":
          _0x218b03["position"]["set"](
            0x0,
            _0x2a12c8["QBIZw"](
              _0x2a12c8["AhrvI"](
                -game["cache"]["getImage"](_0x2a12c8["MbroC"])["height"],
                0x2
              ),
              _0x2a12c8["GUTUp"](
                game["cache"]["getFrameByName"](
                  _0x2a12c8["lvsWY"],
                  _0x2a12c8["lPVOB"]
                )["height"],
                0x2
              )
            )
          );
          continue;
        case "10":
          this["windowQuit"] = game["make"]["sprite"](
            0x0,
            0x0,
            _0x2a12c8["MbroC"]
          );
          continue;
        case "11":
          _0x39f568["shadowColor"] = _0x2a12c8["ZdFjy"];
          continue;
        case "12":
          this["windowQuit"]["anchor"]["set"](0.5);
          continue;
        case "13":
          _0x39f568["shadowBlur"] = 0x5;
          continue;
        case "14":
          var _0x218b03 = game["make"]["sprite"](
            0x0,
            0x0,
            _0x2a12c8["lvsWY"],
            _0x2a12c8["lPVOB"]
          );
          continue;
        case "15":
          _0x39f568["shadowFill"] = _0x2a12c8["ZdFjy"];
          continue;
        case "16":
          this["windowQuit"]["visible"] = !0x1;
          continue;
        case "17":
          _0x39f568["shadowOffsetY"] = 0x2;
          continue;
        case "18":
          this["windowQuit"]["scale"]["set"](0.5);
          continue;
        case "19":
          _0x39f568["anchor"]["y"] = _0x2a12c8["nBVwI"](
            getCorrectAnchorY,
            _0x39f568,
            0.5
          );
          continue;
      }
      break;
    }
  },
  createParentWindow: function () {
    var _0x3a3542 = {
      cfJIQ:
        "11|2|10|7|34|24|29|9|48|21|46|31|14|37|42|35|39|47|33|41|27|22|30|19|25|6|23|8|32|36|20|3|1|15|38|18|16|17|5|49|12|28|40|26|13|4|44|0|43|45",
      bwtIF: "32px\x20",
      SXSsy: function (_0x16c7c8, _0x5ce104, _0xed95c1, _0x42b8f9, _0x34f1e2) {
        return _0x16c7c8(_0x5ce104, _0xed95c1, _0x42b8f9, _0x34f1e2);
      },
      YBDbL: "tmpBtn",
      QfPPf: function (_0x417f47, _0x471da2) {
        return _0x417f47 / _0x471da2;
      },
      QwZyr: function (_0x266773, _0x59ba2d) {
        return _0x266773 + _0x59ba2d;
      },
      QQwbI: function (_0x4d6aad, _0x1b4b3d) {
        return _0x4d6aad >> _0x1b4b3d;
      },
      qRPph: "pak1",
      hsFJo: "dialog_header",
      mmKGu: function (_0x5f57fc, _0x410a20) {
        return _0x5f57fc - _0x410a20;
      },
      EkDjm: function (_0x18ad10, _0x228927, _0x29e5ff) {
        return _0x18ad10(_0x228927, _0x29e5ff);
      },
      Orgho: "menu_window",
      PsONr: "#000000",
      JMuot: function (_0x204d8e, _0x467002, _0x2ba4fa, _0x1a230d, _0x3a5c8d) {
        return _0x204d8e(_0x467002, _0x2ba4fa, _0x1a230d, _0x3a5c8d);
      },
      MQwML: function (_0x4c2873, _0x54fc53) {
        return _0x4c2873 + _0x54fc53;
      },
      LnTvo: function (_0x89fde3, _0x10f26f) {
        return _0x89fde3 / _0x10f26f;
      },
      jvwPU: function (_0x6edb50, _0x5112f4) {
        return _0x6edb50 + _0x5112f4;
      },
      ODKGP: "ARE\x20YOU\x20AN\x20ADULT\x20?",
      qzIds: "#F99111",
      pZMzp: function (_0x2a4533, _0xf715b0) {
        return _0x2a4533 + _0xf715b0;
      },
      BbibJ: "25px\x20",
      vUfhp: "center",
      KfAnI: function (_0x4ed563, _0x89767e) {
        return _0x4ed563 / _0x89767e;
      },
      NUWti: "\x201\x20+\x201\x20=\x20",
      HYtjl: "#FFFFFF",
      ODtmr: function (_0x1b76e8, _0x45149b) {
        return _0x1b76e8 + _0x45149b;
      },
      PvkaD: "50px\x20",
      xYKXE: function (_0x25c880, _0x263c66, _0x470eff) {
        return _0x25c880(_0x263c66, _0x470eff);
      },
    };
    var _0x332238 = _0x3a3542["cfJIQ"]["split"]("|"),
      _0x238ef9 = 0x0;
    while ([]) {
      switch (_0x332238[_0x238ef9++]) {
        case "0":
          this["btn1"] = _0x647cdd;
          continue;
        case "1":
          _0x419372["tmpTxt"] = this["createText"](
            "2",
            -0x2,
            _0x419372,
            _0x3a3542["bwtIF"]
          );
          continue;
        case "2":
          this["windowParent"]["anchor"]["set"](0.5);
          continue;
        case "3":
          _0x419372["anchor"]["set"](0.5);
          continue;
        case "4":
          grpSceneMenu["add"](this["windowParent"]);
          continue;
        case "5":
          _0x3a3542["SXSsy"](
            AddButtonEvents,
            _0x4302a1,
            this["parentButtonPress"],
            ButtonOnInputOver,
            ButtonOnInputOut
          );
          continue;
        case "6":
          var _0x4302a1 = game["cache"]["getBitmapData"](_0x3a3542["YBDbL"])[
              "width"
            ],
            _0x204f42 = _0x3a3542["QfPPf"](_0x4302a1, 0xa),
            _0x647cdd = _0x3a3542["QfPPf"](_0x4302a1, 0x3),
            _0x352e13 = _0x3a3542["QwZyr"](
              _0x3a3542["QQwbI"](
                game["cache"]["getBitmapData"](_0x3a3542["YBDbL"])["height"],
                0x1
              ),
              _0x647cdd
            );
          continue;
        case "7":
          var _0x4eca8b = game["make"]["sprite"](
            0x0,
            0x0,
            _0x3a3542["qRPph"],
            _0x3a3542["hsFJo"]
          );
          continue;
        case "8":
          _0x647cdd = game["make"]["sprite"](
            _0x3a3542["mmKGu"](-_0x4302a1, _0x204f42),
            _0x352e13,
            game["cache"]["getBitmapData"](_0x3a3542["YBDbL"]),
            0x1
          );
          continue;
        case "9":
          _0x3a88a8["anchor"]["x"] = _0x3a3542["EkDjm"](
            getCorrectAnchorX,
            _0x3a88a8,
            0.5
          );
          continue;
        case "10":
          this["windowParent"]["position"]["set"](
            game["world"]["centerX"],
            game["world"]["centerY"]
          );
          continue;
        case "11":
          this["windowParent"] = game["make"]["sprite"](
            0x0,
            0x0,
            _0x3a3542["Orgho"]
          );
          continue;
        case "12":
          this["windowParent"]["addChild"](_0x3a88a8);
          continue;
        case "13":
          this["windowParent"]["addChild"](_0x4302a1);
          continue;
        case "14":
          _0x3a88a8["shadowFill"] = _0x3a3542["PsONr"];
          continue;
        case "15":
          _0x4302a1 = game["make"]["sprite"](
            _0x3a3542["QwZyr"](_0x4302a1, _0x204f42),
            _0x352e13,
            game["cache"]["getBitmapData"](_0x3a3542["YBDbL"]),
            0x1
          );
          continue;
        case "16":
          _0x3a3542["SXSsy"](
            AddButtonEvents,
            _0x647cdd,
            this["parentButtonPress"],
            ButtonOnInputOver,
            ButtonOnInputOut
          );
          continue;
        case "17":
          _0x3a3542["JMuot"](
            AddButtonEvents,
            _0x419372,
            this["parentButtonPress"],
            ButtonOnInputOver,
            ButtonOnInputOut
          );
          continue;
        case "18":
          _0x4302a1["tmpTxt"] = this["createText"](
            "3",
            -0x2,
            _0x4302a1,
            _0x3a3542["bwtIF"]
          );
          continue;
        case "19":
          _0x1bac13["lineSpacing"] = -0x7;
          continue;
        case "20":
          var _0x419372 = game["make"]["sprite"](
            0x0,
            _0x352e13,
            game["cache"]["getBitmapData"](_0x3a3542["YBDbL"]),
            0x1
          );
          continue;
        case "21":
          _0x3a88a8["shadowOffsetX"] = 0x2;
          continue;
        case "22":
          _0x1bac13["shadowFill"] = _0x3a3542["PsONr"];
          continue;
        case "23":
          _0x1bac13["y"] = -_0x3a3542["MQwML"](
            _0x3a3542["QQwbI"](_0x1bac13["height"], 0x1),
            _0x647cdd
          );
          continue;
        case "24":
          _0x4eca8b["position"]["set"](
            0x0,
            _0x3a3542["mmKGu"](
              _0x3a3542["QfPPf"](
                -game["cache"]["getImage"](_0x3a3542["Orgho"])["height"],
                0x2
              ),
              _0x3a3542["LnTvo"](
                game["cache"]["getFrameByName"](
                  _0x3a3542["qRPph"],
                  _0x3a3542["hsFJo"]
                )["height"],
                0x2
              )
            )
          );
          continue;
        case "25":
          this["question"] = _0x1bac13;
          continue;
        case "26":
          this["windowParent"]["addChild"](_0x419372);
          continue;
        case "27":
          _0x1bac13["shadowColor"] = _0x3a3542["PsONr"];
          continue;
        case "28":
          this["windowParent"]["addChild"](_0x1bac13);
          continue;
        case "29":
          var _0x3a88a8 = new Phaser["Text"](
            game,
            0x0,
            _0x3a3542["jvwPU"](
              _0x3a3542["mmKGu"](
                _0x3a3542["LnTvo"](
                  -game["cache"]["getImage"](_0x3a3542["Orgho"])["height"],
                  0x2
                ),
                _0x3a3542["LnTvo"](
                  game["cache"]["getFrameByName"](
                    _0x3a3542["qRPph"],
                    _0x3a3542["hsFJo"]
                  )["height"],
                  0x2
                )
              ),
              0x8
            ),
            _0x3a3542["ODKGP"],
            {
              fill: _0x3a3542["qzIds"],
              font: _0x3a3542["pZMzp"](_0x3a3542["BbibJ"], GAME_FONT),
              wordWrap: !0x0,
              wordWrapWidth: 0x12c,
              align: _0x3a3542["vUfhp"],
            }
          );
          continue;
        case "30":
          _0x1bac13["shadowBlur"] = 0x5;
          continue;
        case "31":
          _0x3a88a8["shadowColor"] = _0x3a3542["PsONr"];
          continue;
        case "32":
          _0x647cdd["anchor"]["set"](0.5);
          continue;
        case "33":
          _0x1bac13["shadowOffsetX"] = 0x2;
          continue;
        case "34":
          _0x4eca8b["anchor"]["set"](0.5);
          continue;
        case "35":
          var _0x1bac13 = new Phaser["Text"](
            game,
            0x0,
            _0x3a3542["KfAnI"](
              -game["cache"]["getImage"](_0x3a3542["Orgho"])["height"],
              0x7
            ),
            _0x3a3542["NUWti"],
            {
              fill: _0x3a3542["HYtjl"],
              font: _0x3a3542["ODtmr"](_0x3a3542["PvkaD"], GAME_FONT),
              wordWrap: !0x0,
              wordWrapWidth: 0x1e0,
              align: _0x3a3542["vUfhp"],
            }
          );
          continue;
        case "36":
          _0x647cdd["tmpTxt"] = this["createText"](
            "1",
            -0x2,
            _0x647cdd,
            _0x3a3542["bwtIF"]
          );
          continue;
        case "37":
          _0x3a88a8["shadowBlur"] = 0x5;
          continue;
        case "38":
          _0x4302a1["anchor"]["set"](0.5);
          continue;
        case "39":
          _0x1bac13["anchor"]["x"] = _0x3a3542["xYKXE"](
            getCorrectAnchorX,
            _0x1bac13,
            0.5
          );
          continue;
        case "40":
          this["windowParent"]["addChild"](_0x647cdd);
          continue;
        case "41":
          _0x1bac13["shadowOffsetY"] = 0x2;
          continue;
        case "42":
          _0x3a88a8["lineSpacing"] = -0x7;
          continue;
        case "43":
          this["btn2"] = _0x419372;
          continue;
        case "44":
          this["windowParent"]["y"] = WINDOW_HIDE_POS_Y;
          continue;
        case "45":
          this["btn3"] = _0x4302a1;
          continue;
        case "46":
          _0x3a88a8["shadowOffsetY"] = 0x2;
          continue;
        case "47":
          _0x1bac13["anchor"]["y"] = _0x3a3542["xYKXE"](
            getCorrectAnchorY,
            _0x1bac13,
            0.5
          );
          continue;
        case "48":
          _0x3a88a8["anchor"]["y"] = _0x3a3542["xYKXE"](
            getCorrectAnchorY,
            _0x3a88a8,
            0.5
          );
          continue;
        case "49":
          this["windowParent"]["addChild"](_0x4eca8b);
          continue;
      }
      break;
    }
  },
  createSettingsWindow: function () {
    var _0x318e5f = {
      xgihX: "13|1|19|7|8|15|4|6|16|12|0|17|2|18|3|14|11|20|9|10|5",
      ERLye: "#000000",
      nivkX: function (_0x584791, _0x11f696) {
        return _0x584791 + _0x11f696;
      },
      YFRBZ: function (_0xeae8eb, _0x372eb2) {
        return _0xeae8eb - _0x372eb2;
      },
      IhthG: function (_0x51f983, _0x31d698) {
        return _0x51f983 / _0x31d698;
      },
      Iuqaq: "menu_window",
      Kcoig: function (_0x52a326, _0x3c895a) {
        return _0x52a326 / _0x3c895a;
      },
      hAaNm: "pak1",
      DxwdA: "dialog_header",
      nbMhZ: "SETTINGS",
      frDFE: "#F99111",
      fosKI: "25px\x20",
      dRgMN: "center",
      OEuIW: "tmpBtn",
      EntYP: function (_0x10219b, _0x50bc5a, _0x390535) {
        return _0x10219b(_0x50bc5a, _0x390535);
      },
      ZUdIV: function (_0x34d520, _0x1d08d7) {
        return _0x34d520 - _0x1d08d7;
      },
      ttROh: function (_0x32ce50, _0x4b7d00) {
        return _0x32ce50 / _0x4b7d00;
      },
      RnvlR: function (_0x49d1f3, _0x2ecfbe, _0x423a78) {
        return _0x49d1f3(_0x2ecfbe, _0x423a78);
      },
    };
    var _0x2fba81 = _0x318e5f["xgihX"]["split"]("|"),
      _0x5b22a3 = 0x0;
    while ([]) {
      switch (_0x2fba81[_0x5b22a3++]) {
        case "0":
          _0x7acbc9["shadowOffsetY"] = 0x2;
          continue;
        case "1":
          this["windowSettings"]["anchor"]["set"](0.5);
          continue;
        case "2":
          _0x7acbc9["shadowFill"] = _0x318e5f["ERLye"];
          continue;
        case "3":
          _0x7acbc9["lineSpacing"] = -0x7;
          continue;
        case "4":
          _0x7acbc9 = new Phaser["Text"](
            game,
            0x0,
            _0x318e5f["nivkX"](
              _0x318e5f["YFRBZ"](
                _0x318e5f["IhthG"](
                  -game["cache"]["getImage"](_0x318e5f["Iuqaq"])["height"],
                  0x2
                ),
                _0x318e5f["Kcoig"](
                  game["cache"]["getFrameByName"](
                    _0x318e5f["hAaNm"],
                    _0x318e5f["DxwdA"]
                  )["height"],
                  0x2
                )
              ),
              0x8
            ),
            _0x318e5f["nbMhZ"],
            {
              fill: _0x318e5f["frDFE"],
              font: _0x318e5f["nivkX"](_0x318e5f["fosKI"], GAME_FONT),
              wordWrap: !0x0,
              wordWrapWidth: 0x1e0,
              align: _0x318e5f["dRgMN"],
            }
          );
          continue;
        case "5":
          game["cache"]["getBitmapData"](_0x318e5f["OEuIW"]);
          continue;
        case "6":
          _0x7acbc9["anchor"]["x"] = _0x318e5f["EntYP"](
            getCorrectAnchorX,
            _0x7acbc9,
            0.5
          );
          continue;
        case "7":
          var _0x7acbc9 = game["make"]["sprite"](
            0x0,
            0x0,
            _0x318e5f["hAaNm"],
            _0x318e5f["DxwdA"]
          );
          continue;
        case "8":
          _0x7acbc9["anchor"]["set"](0.5);
          continue;
        case "9":
          game["cache"]["getImage"](_0x318e5f["Iuqaq"]);
          continue;
        case "10":
          game["cache"]["getBitmapData"](_0x318e5f["OEuIW"]);
          continue;
        case "11":
          game["cache"]["getBitmapData"](_0x318e5f["OEuIW"]);
          continue;
        case "12":
          _0x7acbc9["shadowOffsetX"] = 0x2;
          continue;
        case "13":
          this["windowSettings"] = game["make"]["sprite"](
            0x0,
            0x0,
            _0x318e5f["Iuqaq"]
          );
          continue;
        case "14":
          game["cache"]["getBitmapData"](_0x318e5f["OEuIW"]);
          continue;
        case "15":
          _0x7acbc9["position"]["set"](
            0x0,
            _0x318e5f["ZUdIV"](
              _0x318e5f["Kcoig"](
                -game["cache"]["getImage"](_0x318e5f["Iuqaq"])["height"],
                0x2
              ),
              _0x318e5f["ttROh"](
                game["cache"]["getFrameByName"](
                  _0x318e5f["hAaNm"],
                  _0x318e5f["DxwdA"]
                )["height"],
                0x2
              )
            )
          );
          continue;
        case "16":
          _0x7acbc9["anchor"]["y"] = _0x318e5f["RnvlR"](
            getCorrectAnchorY,
            _0x7acbc9,
            0.5
          );
          continue;
        case "17":
          _0x7acbc9["shadowColor"] = _0x318e5f["ERLye"];
          continue;
        case "18":
          _0x7acbc9["shadowBlur"] = 0x5;
          continue;
        case "19":
          this["windowSettings"]["position"]["set"](
            game["world"]["centerX"],
            game["world"]["centerY"]
          );
          continue;
        case "20":
          game["cache"]["getImage"](_0x318e5f["Iuqaq"]);
          continue;
      }
      break;
    }
  },
  createInstructionWindow: function () {
    var _0x528b58 = {
      LXunf:
        "30|25|23|26|10|13|22|20|4|0|12|5|24|18|27|28|16|8|7|2|9|15|14|21|19|29|1|6|3|17|11",
      fMphF: function (_0x254e35, _0x33bfd0, _0x566ef6) {
        return _0x254e35(_0x33bfd0, _0x566ef6);
      },
      bFnDH: "#000000",
      GTvia: function (_0x41cf40, _0x189f3c, _0x1f2944) {
        return _0x41cf40(_0x189f3c, _0x1f2944);
      },
      ZMJkl: function (_0x28b190, _0x5e80bc) {
        return _0x28b190 - _0x5e80bc;
      },
      kGScp: function (_0x3315d3, _0x166289) {
        return _0x3315d3 / _0x166289;
      },
      sEnvp: "menu_window",
      xTowJ: function (_0x39e8af, _0x59622d) {
        return _0x39e8af / _0x59622d;
      },
      KYuoL: "pak1",
      SIlQm: "dialog_header",
      CSDvx: function (_0x536228, _0x216d95, _0x511f00) {
        return _0x536228(_0x216d95, _0x511f00);
      },
      qSypk: function (_0x1e38d7, _0x214b54) {
        return _0x1e38d7 + _0x214b54;
      },
      SaLyk: function (_0x5ecc8e, _0x4dc008) {
        return _0x5ecc8e(_0x4dc008);
      },
      TeglW: "INSTRUCTIONS",
      ABHwC: "#F99111",
      qqvFH: function (_0x1fd7ba, _0x4a474d) {
        return _0x1fd7ba + _0x4a474d;
      },
      FTtyr: "40px\x20",
      yrAKM: "center",
      HFVEF: "INS_TXT",
      mdyKH: "#FFFFFF",
      AQMHX: "30px\x20",
    };
    var _0x412b5a = _0x528b58["LXunf"]["split"]("|"),
      _0x36ade2 = 0x0;
    while ([]) {
      switch (_0x412b5a[_0x36ade2++]) {
        case "0":
          _0x250903["shadowOffsetX"] = 0x2;
          continue;
        case "1":
          this["windowInstructions"]["addChild"](_0x250903);
          continue;
        case "2":
          _0x3ac74e["shadowOffsetY"] = 0x2;
          continue;
        case "3":
          this["windowInstructions"]["addChild"](_0x58069a);
          continue;
        case "4":
          _0x250903["anchor"]["y"] = _0x528b58["fMphF"](
            getCorrectAnchorY,
            _0x250903,
            0.5
          );
          continue;
        case "5":
          _0x250903["shadowColor"] = _0x528b58["bFnDH"];
          continue;
        case "6":
          this["windowInstructions"]["addChild"](_0x3ac74e);
          continue;
        case "7":
          _0x3ac74e["shadowOffsetX"] = 0x2;
          continue;
        case "8":
          _0x3ac74e["anchor"]["y"] = _0x528b58["GTvia"](
            getCorrectAnchorY,
            _0x3ac74e,
            0.5
          );
          continue;
        case "9":
          _0x3ac74e["shadowColor"] = _0x528b58["bFnDH"];
          continue;
        case "10":
          _0x9cb0e["anchor"]["set"](0.5);
          continue;
        case "11":
          this["windowInstructions"]["y"] = WINDOW_HIDE_POS_Y;
          continue;
        case "12":
          _0x250903["shadowOffsetY"] = 0x2;
          continue;
        case "13":
          _0x9cb0e["position"]["set"](
            0x0,
            _0x528b58["ZMJkl"](
              _0x528b58["kGScp"](
                -game["cache"]["getImage"](_0x528b58["sEnvp"])["height"],
                0x2
              ),
              _0x528b58["xTowJ"](
                game["cache"]["getFrameByName"](
                  _0x528b58["KYuoL"],
                  _0x528b58["SIlQm"]
                )["height"],
                0x2
              )
            )
          );
          continue;
        case "14":
          _0x3ac74e["shadowBlur"] = 0x5;
          continue;
        case "15":
          _0x3ac74e["shadowFill"] = _0x528b58["bFnDH"];
          continue;
        case "16":
          _0x3ac74e["anchor"]["x"] = _0x528b58["CSDvx"](
            getCorrectAnchorX,
            _0x3ac74e,
            0.5
          );
          continue;
        case "17":
          grpSceneMenu["add"](this["windowInstructions"]);
          continue;
        case "18":
          _0x250903["shadowBlur"] = 0x5;
          continue;
        case "19":
          var _0x58069a = game["make"]["group"]();
          continue;
        case "20":
          _0x250903["anchor"]["x"] = _0x528b58["CSDvx"](
            getCorrectAnchorX,
            _0x250903,
            0.5
          );
          continue;
        case "21":
          _0x3ac74e["lineSpacing"] = 0x7;
          continue;
        case "22":
          var _0x250903 = new Phaser["Text"](
            game,
            0x0,
            _0x528b58["qSypk"](
              _0x528b58["ZMJkl"](
                _0x528b58["xTowJ"](
                  -game["cache"]["getImage"](_0x528b58["sEnvp"])["height"],
                  0x2
                ),
                _0x528b58["xTowJ"](
                  game["cache"]["getFrameByName"](
                    _0x528b58["KYuoL"],
                    _0x528b58["SIlQm"]
                  )["height"],
                  0x2
                )
              ),
              0x8
            ),
            _0x528b58["qSypk"](
              _0x528b58["SaLyk"](STR, _0x528b58["TeglW"]),
              "\x20"
            ),
            {
              fill: _0x528b58["ABHwC"],
              font: _0x528b58["qqvFH"](_0x528b58["FTtyr"], GAME_FONT),
              wordWrap: !0x0,
              wordWrapWidth: 0x1e0,
              align: _0x528b58["yrAKM"],
            }
          );
          continue;
        case "23":
          this["windowInstructions"]["position"]["set"](
            game["world"]["centerX"],
            game["world"]["centerY"]
          );
          continue;
        case "24":
          _0x250903["shadowFill"] = _0x528b58["bFnDH"];
          continue;
        case "25":
          this["windowInstructions"]["anchor"]["set"](0.5);
          continue;
        case "26":
          var _0x9cb0e = game["make"]["sprite"](
            0x0,
            0x0,
            _0x528b58["KYuoL"],
            _0x528b58["SIlQm"]
          );
          continue;
        case "27":
          _0x250903["lineSpacing"] = 0x7;
          continue;
        case "28":
          var _0x3ac74e = new Phaser["Text"](
            game,
            0x0,
            0x0,
            _0x528b58["SaLyk"](STR, _0x528b58["HFVEF"]),
            {
              fill: _0x528b58["mdyKH"],
              font: _0x528b58["qqvFH"](_0x528b58["AQMHX"], GAME_FONT),
              wordWrap: !0x0,
              wordWrapWidth: _0x528b58["ZMJkl"](
                game["cache"]["getImage"](_0x528b58["sEnvp"])["width"],
                0x28
              ),
              align: _0x528b58["yrAKM"],
            }
          );
          continue;
        case "29":
          this["windowInstructions"]["addChild"](_0x9cb0e);
          continue;
        case "30":
          this["windowInstructions"] = game["make"]["sprite"](
            0x0,
            0x0,
            _0x528b58["sEnvp"]
          );
          continue;
      }
      break;
    }
  },
  createAboutWindow: function () {
    var _0x9d3e65 = {
      rWeOz:
        "18|1|2|0|9|11|3|24|22|20|8|15|12|19|7|25|23|26|4|21|5|14|16|13|17|6|10",
      jcHjH: "pak1",
      SBTCd: "dialog_header",
      tbncE: function (_0x5516dd, _0x5a7c44) {
        return _0x5516dd + _0x5a7c44;
      },
      CdZPZ: function (_0x1e7e2a, _0x54044f) {
        return _0x1e7e2a - _0x54044f;
      },
      DFPnS: function (_0x5ba34a, _0x55aaa2) {
        return _0x5ba34a / _0x55aaa2;
      },
      COIno: "menu_window",
      gnXrX: "ABOUT",
      nhPcT: "#F99111",
      FJOUw: "25px\x20",
      rfioc: "center",
      sSCyj: "logo_game",
      AWUbM: "inl",
      pNYyg: function (_0x17f9c7, _0x267643) {
        return _0x17f9c7 - _0x267643;
      },
      yNslH: function (_0x473729, _0x68afee) {
        return _0x473729 / _0x68afee;
      },
      DAanG: "#000000",
      modnW: function (_0x2b407f, _0x39365c, _0x439040) {
        return _0x2b407f(_0x39365c, _0x439040);
      },
      JaELh: function (_0x2db129, _0x571c72) {
        return _0x2db129 / _0x571c72;
      },
      egbTi: function (_0x175af6, _0x3ff69d) {
        return _0x175af6 - _0x3ff69d;
      },
      evyHl: function (_0xb8b3ea, _0x3853d6) {
        return _0xb8b3ea + _0x3853d6;
      },
      UTOoX: function (_0x468d19, _0x14c47a) {
        return _0x468d19 / _0x14c47a;
      },
    };
    var _0x5f25e0 = _0x9d3e65["rWeOz"]["split"]("|"),
      _0x12c597 = 0x0;
    while ([]) {
      switch (_0x5f25e0[_0x12c597++]) {
        case "0":
          var _0xc04c2a = game["make"]["sprite"](
            0x0,
            0x0,
            _0x9d3e65["jcHjH"],
            _0x9d3e65["SBTCd"]
          );
          continue;
        case "1":
          this["windowAbout"]["anchor"]["set"](0.5);
          continue;
        case "2":
          this["windowAbout"]["position"]["set"](
            game["world"]["centerX"],
            game["world"]["centerY"]
          );
          continue;
        case "3":
          var _0xffbe96 = new Phaser["Text"](
            game,
            0x0,
            _0x9d3e65["tbncE"](
              _0x9d3e65["CdZPZ"](
                _0x9d3e65["DFPnS"](
                  -game["cache"]["getImage"](_0x9d3e65["COIno"])["height"],
                  0x2
                ),
                _0x9d3e65["DFPnS"](
                  game["cache"]["getFrameByName"](
                    _0x9d3e65["jcHjH"],
                    _0x9d3e65["SBTCd"]
                  )["height"],
                  0x2
                )
              ),
              0x8
            ),
            _0x9d3e65["gnXrX"],
            {
              fill: _0x9d3e65["nhPcT"],
              font: _0x9d3e65["tbncE"](_0x9d3e65["FJOUw"], GAME_FONT),
              wordWrap: !0x0,
              wordWrapWidth: 0x1e0,
              align: _0x9d3e65["rfioc"],
            }
          );
          continue;
        case "4":
          var _0x5cb878 = _0x9d3e65["tbncE"](
              _0x5cb878,
              game["cache"]["getFrameByName"](
                _0x9d3e65["jcHjH"],
                _0x9d3e65["sSCyj"]
              )["height"]
            ),
            _0x64e5f0 = game["make"]["sprite"](
              0x0,
              0x0,
              _0x9d3e65["jcHjH"],
              _0x9d3e65["AWUbM"]
            );
          continue;
        case "5":
          _0x64e5f0["y"] = _0x5cb878;
          continue;
        case "6":
          grpSceneMenu["add"](this["windowAbout"]);
          continue;
        case "7":
          _0xffbe96["lineSpacing"] = -0x7;
          continue;
        case "8":
          _0xffbe96["shadowOffsetY"] = 0x2;
          continue;
        case "9":
          _0xc04c2a["anchor"]["set"](0.5);
          continue;
        case "10":
          this["windowAbout"]["y"] = WINDOW_HIDE_POS_Y;
          continue;
        case "11":
          _0xc04c2a["position"]["set"](
            0x0,
            _0x9d3e65["pNYyg"](
              _0x9d3e65["DFPnS"](
                -game["cache"]["getImage"](_0x9d3e65["COIno"])["height"],
                0x2
              ),
              _0x9d3e65["yNslH"](
                game["cache"]["getFrameByName"](
                  _0x9d3e65["jcHjH"],
                  _0x9d3e65["SBTCd"]
                )["height"],
                0x2
              )
            )
          );
          continue;
        case "12":
          _0xffbe96["shadowFill"] = _0x9d3e65["DAanG"];
          continue;
        case "13":
          this["windowAbout"]["addChild"](_0xc04c2a);
          continue;
        case "14":
          this["windowAbout"]["addChild"](_0x351892);
          continue;
        case "15":
          _0xffbe96["shadowColor"] = _0x9d3e65["DAanG"];
          continue;
        case "16":
          this["windowAbout"]["addChild"](_0x64e5f0);
          continue;
        case "17":
          this["windowAbout"]["addChild"](_0xffbe96);
          continue;
        case "18":
          this["windowAbout"] = game["make"]["sprite"](
            0x0,
            0x0,
            _0x9d3e65["COIno"]
          );
          continue;
        case "19":
          _0xffbe96["shadowBlur"] = 0x5;
          continue;
        case "20":
          _0xffbe96["shadowOffsetX"] = 0x2;
          continue;
        case "21":
          _0x64e5f0["anchor"]["set"](0.5);
          continue;
        case "22":
          _0xffbe96["anchor"]["y"] = _0x9d3e65["modnW"](
            getCorrectAnchorY,
            _0xffbe96,
            0.5
          );
          continue;
        case "23":
          _0x351892["anchor"]["set"](0.5);
          continue;
        case "24":
          _0xffbe96["anchor"]["x"] = _0x9d3e65["modnW"](
            getCorrectAnchorX,
            _0xffbe96,
            0.5
          );
          continue;
        case "25":
          var _0x5cb878 = _0x9d3e65["JaELh"](
              _0x9d3e65["pNYyg"](
                _0x9d3e65["egbTi"](
                  game["cache"]["getImage"](_0x9d3e65["COIno"])["height"],
                  game["cache"]["getFrameByName"](
                    _0x9d3e65["jcHjH"],
                    _0x9d3e65["sSCyj"]
                  )["height"]
                ),
                game["cache"]["getFrameByName"](
                  _0x9d3e65["jcHjH"],
                  _0x9d3e65["AWUbM"]
                )["height"]
              ),
              0x2
            ),
            _0x5cb878 = _0x9d3e65["evyHl"](
              _0x9d3e65["evyHl"](
                _0x9d3e65["JaELh"](
                  -game["cache"]["getImage"](_0x9d3e65["COIno"])["height"],
                  0x2
                ),
                _0x5cb878
              ),
              _0x9d3e65["UTOoX"](
                game["cache"]["getFrameByName"](
                  _0x9d3e65["jcHjH"],
                  _0x9d3e65["sSCyj"]
                )["height"],
                0x2
              )
            ),
            _0x351892 = game["make"]["sprite"](
              0x0,
              0x0,
              _0x9d3e65["jcHjH"],
              _0x9d3e65["sSCyj"]
            );
          continue;
        case "26":
          _0x351892["y"] = _0x5cb878;
          continue;
      }
      break;
    }
  },
  createText: function (_0x3e7856, _0x5bde72, _0xc63a66, _0x423148) {
    var _0x3e8da8 = {
      ZVdKE: "0|2|1|9|10|7|8|4|3|5|6",
      hURPe: "#FFFFFF",
      YlBNP: function (_0x18a3d6, _0x2fff18) {
        return _0x18a3d6 + _0x2fff18;
      },
      tsdCj: "left",
      qZDFh: function (_0x45aa0e, _0x10a2e5, _0x55c275) {
        return _0x45aa0e(_0x10a2e5, _0x55c275);
      },
      bdLeo: "#000000",
    };
    var _0x295080 = _0x3e8da8["ZVdKE"]["split"]("|"),
      _0x4e1bc2 = 0x0;
    while ([]) {
      switch (_0x295080[_0x4e1bc2++]) {
        case "0":
          _0x3e7856 = new Phaser["Text"](game, 0x0, _0x5bde72, _0x3e7856, {
            fill: _0x3e8da8["hURPe"],
            font: _0x3e8da8["YlBNP"](_0x423148, GAME_FONT),
            wordWrap: !0x0,
            wordWrapWidth: 0x1e0,
            align: _0x3e8da8["tsdCj"],
          });
          continue;
        case "1":
          _0x3e7856["anchor"]["y"] = _0x3e8da8["qZDFh"](
            getCorrectAnchorY,
            _0x3e7856,
            0.5
          );
          continue;
        case "2":
          _0x3e7856["anchor"]["x"] = _0x3e8da8["qZDFh"](
            getCorrectAnchorX,
            _0x3e7856,
            0.5
          );
          continue;
        case "3":
          _0x3e7856["lineSpacing"] = -0x7;
          continue;
        case "4":
          _0x3e7856["shadowBlur"] = 0x5;
          continue;
        case "5":
          _0xc63a66["addChild"](_0x3e7856);
          continue;
        case "6":
          return _0x3e7856;
        case "7":
          _0x3e7856["shadowColor"] = _0x3e8da8["bdLeo"];
          continue;
        case "8":
          _0x3e7856["shadowFill"] = _0x3e8da8["bdLeo"];
          continue;
        case "9":
          _0x3e7856["shadowOffsetX"] = 0x2;
          continue;
        case "10":
          _0x3e7856["shadowOffsetY"] = 0x2;
          continue;
      }
      break;
    }
  },
  parentButtonPress: function (_0x377f5d) {
    var _0x293c51 = {
      PKOCA: function (_0x428398, _0x37ebfa) {
        return _0x428398 !== _0x37ebfa;
      },
    };
    _0x293c51["PKOCA"](_0x377f5d["val"], _0x377f5d["answer"])
      ? SceneMenu["instance"]["returnFromLockToMenu"]()
      : SceneMenu["instance"]["callSettingsFromLock"]();
  },
  hideParentScreen: function () {
    game["add"]
      ["tween"](this["windowParent"])
      ["to"](
        { y: WINDOW_HIDE_POS_Y },
        this["animationTime"],
        Phaser["Easing"]["Linear"]["none"],
        !0x0
      );
  },
  showParentScreen: function () {
    var _0x46fd7a = {
      jQFQb: "1|20|3|10|14|16|5|11|19|21|12|13|7|17|4|9|15|2|0|8|6|18",
      RyaMG: function (_0x75cb91, _0x524ef8) {
        return _0x75cb91 + _0x524ef8;
      },
      dVSVi: function (_0x38b69b, _0x2c8758) {
        return _0x38b69b == _0x2c8758;
      },
      HFQko: function (_0x337cc3, _0xe948f0) {
        return _0x337cc3 === _0xe948f0;
      },
      GDwOW: function (_0x1cf2c6, _0x4e2bac) {
        return _0x1cf2c6 > _0x4e2bac;
      },
      InclH: function (_0x4ac8c3, _0x130deb) {
        return _0x4ac8c3 - _0x130deb;
      },
      dDEaR: function (_0x39576e, _0x5dd967) {
        return _0x39576e === _0x5dd967;
      },
      oodSX: function (_0x24a94f, _0x5d6a1b) {
        return _0x24a94f + _0x5d6a1b;
      },
      tJuJy: function (_0x3ef1fc, _0x415f94) {
        return _0x3ef1fc + _0x415f94;
      },
      zJTjb: "\x20+\x20",
    };
    var _0x122a9c = _0x46fd7a["jQFQb"]["split"]("|"),
      _0x5d7e00 = 0x0;
    while ([]) {
      switch (_0x122a9c[_0x5d7e00++]) {
        case "0":
          SceneMenu["instance"]["btn3"]["tmpTxt"]["setText"](
            this["btn3"]["val"]
          );
          continue;
        case "1":
          var _0x2d98b1 = game["rnd"]["integerInRange"](0x1, 0x14),
            _0x32823e = game["rnd"]["integerInRange"](0x1, 0x14),
            _0x4ba9d9 = game["rnd"]["integerInRange"](0x0, 0x2),
            _0x2e0178 = _0x46fd7a["RyaMG"](_0x2d98b1, _0x32823e);
          continue;
        case "2":
          _0x2d98b1[_0x32823e] = -0x1;
          continue;
        case "3":
          _0x2d98b1 = [];
          continue;
        case "4":
          this["btn2"]["answer"] = _0x2e0178;
          continue;
        case "5":
          this["btn1"]["val"] = _0x2d98b1[_0x32823e];
          continue;
        case "6":
          _0x46fd7a["dVSVi"](0x0, _0x4ba9d9)
            ? ((this["btn1"]["val"] = _0x2e0178),
              SceneMenu["instance"]["btn1"]["tmpTxt"]["setText"](
                this["btn1"]["val"]
              ))
            : _0x46fd7a["dVSVi"](0x1, _0x4ba9d9)
            ? ((this["btn2"]["val"] = _0x2e0178),
              SceneMenu["instance"]["btn2"]["tmpTxt"]["setText"](
                this["btn2"]["val"]
              ))
            : _0x46fd7a["dVSVi"](0x2, _0x4ba9d9) &&
              ((this["btn3"]["val"] = _0x2e0178),
              SceneMenu["instance"]["btn3"]["tmpTxt"]["setText"](
                this["btn3"]["val"]
              ));
          continue;
        case "7":
          _0x2d98b1[_0x32823e] = -0x1;
          continue;
        case "8":
          this["btn3"]["answer"] = _0x2e0178;
          continue;
        case "9":
          for (
            _0x32823e = game["rnd"]["integerInRange"](0x1, 0x23);
            _0x46fd7a["HFQko"](-0x1, _0x2d98b1[_0x32823e]);

          )
            _0x32823e = game["rnd"]["integerInRange"](0x1, 0x23);
          continue;
        case "10":
          for (i = 0x2; _0x46fd7a["GDwOW"](0x29, i); i++)
            _0x2d98b1[_0x46fd7a["InclH"](i, 0x2)] = i;
          continue;
        case "11":
          _0x2d98b1[_0x32823e] = -0x1;
          continue;
        case "12":
          for (
            _0x32823e = game["rnd"]["integerInRange"](0x1, 0x23);
            _0x46fd7a["HFQko"](-0x1, _0x2d98b1[_0x32823e]);

          )
            _0x32823e = game["rnd"]["integerInRange"](0x1, 0x23);
          continue;
        case "13":
          this["btn2"]["val"] = _0x2d98b1[_0x32823e];
          continue;
        case "14":
          _0x2d98b1[_0x46fd7a["InclH"](_0x2e0178, 0x2)] = -0x1;
          continue;
        case "15":
          this["btn3"]["val"] = _0x2d98b1[_0x32823e];
          continue;
        case "16":
          for (
            _0x32823e = game["rnd"]["integerInRange"](0x1, 0x23);
            _0x46fd7a["dDEaR"](-0x1, _0x2d98b1[_0x32823e]);

          )
            _0x32823e = game["rnd"]["integerInRange"](0x1, 0x23);
          continue;
        case "17":
          SceneMenu["instance"]["btn2"]["tmpTxt"]["setText"](
            this["btn2"]["val"]
          );
          continue;
        case "18":
          game["add"]
            ["tween"](this["windowParent"])
            ["to"](
              { y: game["world"]["centerY"] },
              this["animationTime"],
              Phaser["Easing"]["Linear"]["none"],
              !0x0
            );
          continue;
        case "19":
          SceneMenu["instance"]["btn1"]["tmpTxt"]["setText"](
            this["btn1"]["val"]
          );
          continue;
        case "20":
          this["question"]["setText"](
            _0x46fd7a["oodSX"](
              _0x46fd7a["tJuJy"](
                _0x46fd7a["tJuJy"](_0x2d98b1, _0x46fd7a["zJTjb"]),
                _0x32823e
              ),
              "\x20="
            )
          );
          continue;
        case "21":
          this["btn1"]["answer"] = _0x2e0178;
          continue;
      }
      break;
    }
  },
  showAboutScreen: function () {
    game["add"]
      ["tween"](this["windowAbout"])
      ["to"](
        { y: game["world"]["centerY"] },
        this["animationTime"],
        Phaser["Easing"]["Linear"]["none"],
        !0x0
      );
  },
  hideAboutScreen: function () {
    game["add"]
      ["tween"](this["windowAbout"])
      ["to"](
        { y: WINDOW_HIDE_POS_Y },
        this["animationTime"],
        Phaser["Easing"]["Linear"]["none"],
        !0x0
      );
  },
  showInstructionsScreen: function () {
    game["add"]
      ["tween"](this["windowInstructions"])
      ["to"](
        { y: game["world"]["centerY"] },
        this["animationTime"],
        Phaser["Easing"]["Linear"]["none"],
        !0x0
      );
  },
  hideInstructionsScreen: function () {
    game["add"]
      ["tween"](this["windowInstructions"])
      ["to"](
        { y: WINDOW_HIDE_POS_Y },
        this["animationTime"],
        Phaser["Easing"]["Linear"]["none"],
        !0x0
      );
  },
  showSettingsScreen: function () {
    game["add"]
      ["tween"](this["windowSettings"])
      ["to"](
        { y: game["world"]["centerY"] },
        this["animationTime"],
        Phaser["Easing"]["Linear"]["none"],
        !0x0
      );
  },
  hideSettingsScreen: function () {
    game["add"]
      ["tween"](this["windowSettings"])
      ["to"](
        { y: WINDOW_HIDE_POS_Y },
        this["animationTime"],
        Phaser["Easing"]["Linear"]["none"],
        !0x0
      );
  },
  returnFromSettingsToMenu: function () {
    SceneMenu["instance"]["hideSettingsScreen"]();
    SceneMenu["instance"]["hideButtons"](MODE_MAIN_MENU);
  },
  returnFromLockToMenu: function () {
    SceneMenu["instance"]["hideParentScreen"]();
    SceneMenu["instance"]["hideButtons"](MODE_MAIN_MENU);
  },
  returnFromInstructionToMenu: function () {
    SceneMenu["instance"]["hideInstructionsScreen"]();
    SceneMenu["instance"]["hideButtons"](MODE_MAIN_MENU);
  },
  returnFromAboutToSettings: function () {
    SceneMenu["instance"]["hideAboutScreen"]();
    SceneMenu["instance"]["hideButtons"](MODE_SETTINGS);
  },
  returnFromInstructionsToSettings: function () {
    SceneMenu["instance"]["hideInstructionsScreen"]();
    SceneMenu["instance"]["hideButtons"](MODE_SETTINGS);
  },
  callSettingsFromLock: function () {
    SceneMenu["instance"]["hideParentScreen"]();
    SceneMenu["instance"]["hideButtons"](MODE_SETTINGS);
  },
  callAboutFromSettings: function () {
    SceneMenu["instance"]["hideSettingsScreen"]();
    SceneMenu["instance"]["hideButtons"](MODE_ABOUT);
  },
  callInstructionsFromSettings: function () {
    SceneMenu["instance"]["hideSettingsScreen"]();
    SceneMenu["instance"]["hideButtons"](MODE_INSTRUCTIONS);
  },
  updateButtonsPosition: function () {
    var _0x5158f1 = {
      cbhsa: "6|2|5|1|3|4|0",
      JFJMK: function (_0x426565, _0x9561b0) {
        return _0x426565 + _0x9561b0;
      },
      PPGKj: function (_0x2533b1, _0x4f50bb) {
        return _0x2533b1 >> _0x4f50bb;
      },
      kcKiQ: function (_0x60b578, _0x32264a) {
        return _0x60b578 > _0x32264a;
      },
      BWypb: function (_0x9f2a5, _0x56d7d2) {
        return _0x9f2a5 + _0x56d7d2;
      },
      eYylP: function (_0x1a39c6, _0x102311) {
        return _0x1a39c6 / _0x102311;
      },
      TjGeg: "tmpBtn",
      hjQpP: function (_0x1999c2, _0xda015a) {
        return _0x1999c2 - _0xda015a;
      },
      BkigS: function (_0x4675bf, _0x6b2011) {
        return _0x4675bf / _0x6b2011;
      },
      KLPVw: function (_0x9f4a67, _0x3fd2c2) {
        return _0x9f4a67 == _0x3fd2c2;
      },
      QcjJG: function (_0x480185, _0x5b8947) {
        return _0x480185 - _0x5b8947;
      },
      qUBnU: function (_0x2f545e, _0x2298af) {
        return _0x2f545e >> _0x2298af;
      },
      nSaAD: function (_0x42efc2, _0x5020a0) {
        return _0x42efc2 >> _0x5020a0;
      },
      fGEqv: function (_0x379471, _0x23cea6) {
        return _0x379471 >> _0x23cea6;
      },
      ZXSEz: function (_0x47ba37, _0x4949e0) {
        return _0x47ba37 * _0x4949e0;
      },
    };
    var _0x10cb78 = _0x5158f1["cbhsa"]["split"]("|"),
      _0x4d5d32 = 0x0;
    while ([]) {
      switch (_0x10cb78[_0x4d5d32++]) {
        case "0":
          buttonGroup["getChildAt"](0x2)["position"]["x"] = _0x5158f1["JFJMK"](
            _0x5158f1["JFJMK"](
              _0x5158f1["PPGKj"](game["width"], 0x1),
              this["buttonWidth"]
            ),
            this["buttonSpace"]
          );
          continue;
        case "1":
          _0x5158f1["kcKiQ"](
            _0x5158f1["BWypb"](
              buttonGroup["y"],
              _0x5158f1["eYylP"](
                game["cache"]["getBitmapData"](_0x5158f1["TjGeg"])["height"],
                0x4
              )
            ),
            game["height"]
          ) &&
            (buttonGroup["y"] = _0x5158f1["hjQpP"](
              game["height"],
              _0x5158f1["BkigS"](
                game["cache"]["getBitmapData"](_0x5158f1["TjGeg"])["height"],
                0x3
              )
            ));
          continue;
        case "2":
          this["menuButtonPosY"] = _0x5158f1["KLPVw"](
            GAME_CURRENT_ORIENTATION,
            ORIENTATION_PORTRAIT
          )
            ? this["menuButtonPosY_P"]
            : this["menuButtonPosY_L"];
          continue;
        case "3":
          buttonGroup["getChildAt"](0x0)["position"]["x"] = _0x5158f1["QcjJG"](
            _0x5158f1["QcjJG"](
              _0x5158f1["qUBnU"](game["width"], 0x1),
              this["buttonWidth"]
            ),
            this["buttonSpace"]
          );
          continue;
        case "4":
          buttonGroup["getChildAt"](0x1)["position"]["x"] = _0x5158f1["nSaAD"](
            game["width"],
            0x1
          );
          continue;
        case "5":
          buttonGroup["y"] = _0x5158f1["BWypb"](
            _0x5158f1["fGEqv"](game["height"], 0x1),
            _0x5158f1["ZXSEz"](
              this["menuButtonPosY"],
              imgBackground["scale"]["x"]
            )
          );
          continue;
        case "6":
          this["buttonSpace"] = _0x5158f1["KLPVw"](
            GAME_CURRENT_ORIENTATION,
            ORIENTATION_PORTRAIT
          )
            ? this["buttonSpace_P"]
            : this["buttonSpace_L"];
          continue;
      }
      break;
    }
  },
};
function create1x3HeightWindowBitmap(_0x5ae42e, _0x57fa6f, _0x328ff6) {
  var _0x5dd5cd = {
    BJCQi: "pak1",
    YBqxs: function (_0x45fe84, _0x7e23f2) {
      return _0x45fe84 + _0x7e23f2;
    },
    grnHa: function (_0x1f411d, _0x28f320) {
      return _0x1f411d / _0x28f320;
    },
    FyglJ: function (_0x51801a, _0x474a17) {
      return _0x51801a * _0x474a17;
    },
    upvHV: function (_0x76bf07, _0x57e88a, _0x2a8ff1, _0x4b6eb8) {
      return _0x76bf07(_0x57e88a, _0x2a8ff1, _0x4b6eb8);
    },
    jdhPa: function (_0x34e791, _0x5d2de9) {
      return _0x34e791 * _0x5d2de9;
    },
    rjJEl: function (_0x4c3ee4, _0x3362bc) {
      return _0x4c3ee4 - _0x3362bc;
    },
    vvCWw: function (_0x26d86f, _0x25893d) {
      return _0x26d86f < _0x25893d;
    },
    qtjbD: function (_0x13362e, _0x41487f) {
      return _0x13362e - _0x41487f;
    },
    DYcke: function (_0x4e07eb, _0x1c14e5) {
      return _0x4e07eb * _0x1c14e5;
    },
    VzGVB: function (_0xfeab83, _0x4c689a) {
      return _0xfeab83 != _0x4c689a;
    },
  };
  function _0x5aeecf(_0x5e0e29, _0x1a7b79, _0x38298b) {
    _0x5e0e29 = game["make"]["image"](
      0x0,
      0x0,
      _0x5dd5cd["BJCQi"],
      _0x5dd5cd["YBqxs"](_0x5dd5cd["YBqxs"](_0x328ff6, "_"), _0x5e0e29)
    );
    _0x149aa0["draw"](_0x5e0e29, _0x1a7b79, _0x38298b);
  }
  _0x5ae42e = Math["floor"](_0x5dd5cd["grnHa"](_0x5ae42e, 0x32));
  var _0x149aa0 = game["add"]["bitmapData"](
    _0x5dd5cd["FyglJ"](0x32, _0x5ae42e),
    0x4b
  );
  _0x5dd5cd["upvHV"](_0x5aeecf, 0x3, 0x0, 0x0);
  _0x5dd5cd["upvHV"](
    _0x5aeecf,
    0x5,
    _0x5dd5cd["jdhPa"](0x32, _0x5dd5cd["rjJEl"](_0x5ae42e, 0x1)),
    0x0
  );
  for (
    var _0x1e435d = 0x1;
    _0x5dd5cd["vvCWw"](_0x1e435d, _0x5dd5cd["qtjbD"](_0x5ae42e, 0x1));
    _0x1e435d++
  )
    _0x5dd5cd["upvHV"](
      _0x5aeecf,
      0x4,
      _0x5dd5cd["DYcke"](0x32, _0x1e435d),
      0x0
    );
  if (_0x5dd5cd["VzGVB"](null, _0x57fa6f))
    game["cache"]["addBitmapData"](_0x57fa6f, _0x149aa0);
  else return _0x149aa0;
}
var gameRunning = !0x1,
  gamePaused = !0x1,
  gamePieces86 = [
    0x0, 0x1, 0x2, 0x1, 0x2, 0x1, 0x2, 0x3, 0x6, 0x7, 0x8, 0x7, 0x8, 0x7, 0x8,
    0x9, 0xa, 0x8, 0x7, 0x8, 0x7, 0x8, 0x7, 0xb, 0x6, 0x7, 0x8, 0x7, 0x8, 0x7,
    0x8, 0x9, 0xa, 0x8, 0x7, 0x8, 0x7, 0x8, 0x7, 0xb, 0xe, 0xf, 0xd, 0xf, 0xd,
    0xf, 0xd, 0x4,
  ],
  gamePieces64 = [
    0x0, 0x1, 0x2, 0x1, 0x2, 0x3, 0x6, 0x7, 0x8, 0x7, 0x8, 0x9, 0xa, 0x8, 0x7,
    0x8, 0x7, 0xb, 0xe, 0xf, 0xd, 0xf, 0xd, 0x4,
  ],
  gamePieces43 = [0x0, 0x1, 0x2, 0x3, 0x6, 0x7, 0x8, 0x9, 0xc, 0xd, 0xf, 0x10],
  gamePieces32 = [0x0, 0x1, 0x5, 0xe, 0xf, 0x10],
  balloonColor = [
    0xb20202, 0xea0f0f, 0xff1286, 0xc3c8ce, 0x643410, 0x52107e, 0x7639ae,
    0x1851a2, 0x14c7ff, 0xfeb800, 0xff8201, 0x3c8900, 0xadea5f,
  ],
  gameMode = 0x1,
  gamePieces,
  X_CNT,
  Y_CNT,
  gameBoard = [],
  PIECES_CNT,
  scaleTileW,
  scaleTileH,
  baseScale = 0.5,
  pickedScale = 0x1,
  tileW,
  tileH,
  tileW2,
  tileH2,
  tileW5,
  tileH5,
  tileW35,
  tileH35,
  PARTICLE_CNT = 0x3c,
  particle = null,
  particleSizeW,
  particleSizeH,
  particleSizeW2,
  particleSizeH2,
  BASE_POS_X,
  BASE_POS_Y,
  startPosition = [],
  puzzleHidden = !0x1,
  particlesEnabled = !0x1,
  onButtonPointer = !0x1,
  mainImagePosX,
  tmpTween,
  ballonTween,
  lastTimeOrientation,
  angleDiff = 0x0,
  SceneGame = function () {
    var _0x3b266b = { eHHGD: "5|2|4|0|1|3" };
    var _0x47b21a = _0x3b266b["eHHGD"]["split"]("|"),
      _0x3518be = 0x0;
    while ([]) {
      switch (_0x47b21a[_0x3518be++]) {
        case "0":
          this["layoutPieces"];
          continue;
        case "1":
          this["gameOver"] = !0x1;
          continue;
        case "2":
          this["backgroundImg"];
          continue;
        case "3":
          this["create"]();
          continue;
        case "4":
          this["timeEvent"] =
            this["mainImage"] =
            this["tweenOnPieceRotation"] =
            this["tweenOnPieceScale"] =
            this["groupPlaced"] =
            this["groupInit"] =
              null;
          continue;
        case "5":
          SceneGame["instance"] = this;
          continue;
      }
      break;
    }
  };
SceneGame["instance"] = null;
SceneGame["prototype"] = {
  create: function () {
    var _0x39affc = {
      nohsp: "11|12|7|9|3|17|16|14|18|4|2|1|5|10|13|6|15|8|0",
      wVkHO: function (_0x1c1498, _0x4409fc, _0x4e34cd, _0x2d82c2, _0x3c9ba3) {
        return _0x1c1498(_0x4409fc, _0x4e34cd, _0x2d82c2, _0x3c9ba3);
      },
      isvUF: "pak1",
      zSqnt: "icons_all_9",
      WzGbj: function (_0x31066e, _0x5694b6) {
        return _0x31066e + _0x5694b6;
      },
      rUfRH: function (_0x1839fa, _0x31eec9) {
        return _0x1839fa / _0x31eec9;
      },
      KkMKg: function (_0x4fbee2, _0x2c01a5) {
        return _0x4fbee2 - _0x2c01a5;
      },
      CrIFf: "tmpBtn3",
      KwPSN: "icons_all_10",
      lZwfY: function (_0x43118f, _0x7c717a, _0x1494c4, _0x381971, _0x1d4d17) {
        return _0x43118f(_0x7c717a, _0x1494c4, _0x381971, _0x1d4d17);
      },
    };
    var _0x135bf5 = _0x39affc["nohsp"]["split"]("|"),
      _0x302af8 = 0x0;
    while ([]) {
      switch (_0x135bf5[_0x302af8++]) {
        case "0":
          gameRunning = grpSceneGame["visible"] = !0x1;
          continue;
        case "1":
          _0x39affc["wVkHO"](
            AddButtonEvents,
            btnMenu,
            this["OnMoreGames"],
            ButtonOnInputOver,
            ButtonOnInputOut
          );
          continue;
        case "2":
          btnMenu["anchor"]["set"](0.5);
          continue;
        case "3":
          var _0x14bf09 = game["make"]["sprite"](
            0x0,
            -0x5,
            _0x39affc["isvUF"],
            _0x39affc["zSqnt"]
          );
          continue;
        case "4":
          btnMenu = game["make"]["sprite"](
            _0x39affc["WzGbj"](_0x39affc["rUfRH"](game["width"], 0x2), 0x64),
            _0x39affc["KkMKg"](game["height"], 0x23),
            game["cache"]["getBitmapData"](_0x39affc["CrIFf"]),
            0x1
          );
          continue;
        case "5":
          var _0x14bf09 = game["make"]["sprite"](
            -0x8,
            -0xf,
            _0x39affc["isvUF"],
            _0x39affc["KwPSN"]
          );
          continue;
        case "6":
          btnMenu["addChild"](_0x14bf09);
          continue;
        case "7":
          btnMenu["anchor"]["set"](0.5);
          continue;
        case "8":
          this["initGame"]();
          continue;
        case "9":
          _0x39affc["lZwfY"](
            AddButtonEvents,
            btnMenu,
            this["OnPressedFromGameToPause"],
            ButtonOnInputOver,
            ButtonOnInputOut
          );
          continue;
        case "10":
          _0x14bf09["anchor"]["set"](0.3);
          continue;
        case "11":
          grpSceneGame = game["add"]["group"]();
          continue;
        case "12":
          btnMenu = game["make"]["sprite"](
            _0x39affc["KkMKg"](_0x39affc["rUfRH"](game["width"], 0x2), 0x64),
            _0x39affc["KkMKg"](game["height"], 0x23),
            game["cache"]["getBitmapData"](_0x39affc["CrIFf"]),
            0x1
          );
          continue;
        case "13":
          _0x14bf09["scale"]["set"](0.4);
          continue;
        case "14":
          btnMenu["addChild"](_0x14bf09);
          continue;
        case "15":
          grpSceneGame["add"](btnMenu);
          continue;
        case "16":
          _0x14bf09["scale"]["set"](0.7);
          continue;
        case "17":
          _0x14bf09["anchor"]["set"](0.5);
          continue;
        case "18":
          grpSceneGame["add"](btnMenu);
          continue;
      }
      break;
    }
  },
  update: function () {
    this["updateParticles"]();
    this["updateBalloonParticles"]();
  },
  onResolutionChange: function () {
    var _0x42e9f0 = {
      tMpkp: function (_0x12bc33, _0x29b799) {
        return _0x12bc33 >> _0x29b799;
      },
      tABzL: function (_0x122aec, _0x2818ad) {
        return _0x122aec - _0x2818ad;
      },
      exMRz: function (_0xd62ecc, _0x4adc27) {
        return _0xd62ecc != _0x4adc27;
      },
      LcXZG: function (_0xbe86a6, _0x212507) {
        return _0xbe86a6 == _0x212507;
      },
      PRBnD: function (_0x579ba8, _0x4f5cfb) {
        return _0x579ba8 >> _0x4f5cfb;
      },
      TSXZf: function (_0x3cef0a, _0x11b7c0) {
        return _0x3cef0a - _0x11b7c0;
      },
      RYyBN: function (_0x4a227b, _0x1ea341) {
        return _0x4a227b / _0x1ea341;
      },
      REhEB: function (_0x253b36, _0x55660f) {
        return _0x253b36 / _0x55660f;
      },
      atNmb: function (_0x3cc630, _0x2cd5e9) {
        return _0x3cc630 >> _0x2cd5e9;
      },
      uQUMd: function (_0x43bf02, _0x1ab8dd) {
        return _0x43bf02 + _0x1ab8dd;
      },
      qjshH: function (_0x5d95be, _0xfd6ef3) {
        return _0x5d95be / _0xfd6ef3;
      },
      qsnbb: function (_0x5e4666, _0x5c5ace) {
        return _0x5e4666 >= _0x5c5ace;
      },
      LqkpC: function (_0x3801bf, _0x299926) {
        return _0x3801bf / _0x299926;
      },
      qDLpY: function (_0x4f9734, _0x43fe80) {
        return _0x4f9734 - _0x43fe80;
      },
      ziaft: "tmpBtn3",
      GssxC: function (_0x5b5335, _0x23cb6f) {
        return _0x5b5335 - _0x23cb6f;
      },
      rNwBj: function (_0x40d826, _0x3a61db) {
        return _0x40d826 / _0x3a61db;
      },
      aOjsK: function (_0x59649c, _0x3558e1) {
        return _0x59649c >> _0x3558e1;
      },
      GZKXh: function (_0x242117, _0x1e7bad) {
        return _0x242117 >> _0x1e7bad;
      },
      iyLKE: function (_0x38385d, _0x59f4eb) {
        return _0x38385d != _0x59f4eb;
      },
    };
    btnMenu["reset"](
      _0x42e9f0["tMpkp"](game["world"]["width"], 0x1),
      _0x42e9f0["tABzL"](game["height"], 0x23)
    );
    _0x42e9f0["exMRz"](void 0x0, this["backgroundImg"]) &&
      (_0x42e9f0["LcXZG"](GAME_CURRENT_ORIENTATION, ORIENTATION_LANDSCAPE)
        ? ((mainImagePosX = this["gameOver"]
            ? _0x42e9f0["PRBnD"](game["width"], 0x1)
            : _0x42e9f0["tABzL"](
                _0x42e9f0["TSXZf"](
                  game["width"],
                  _0x42e9f0["RYyBN"](
                    this["backgroundImg"]["getChildAt"](0x3)["width"],
                    0x2
                  )
                ),
                _0x42e9f0["REhEB"](
                  this["backgroundImg"]["getChildAt"](0x3)["width"],
                  0x12
                )
              )),
          (mainImagePosY = game["world"]["centerY"]))
        : ((mainImagePosX = _0x42e9f0["atNmb"](game["width"], 0x1)),
          (mainImagePosY = _0x42e9f0["uQUMd"](
            game["world"]["centerY"],
            _0x42e9f0["qjshH"](
              this["backgroundImg"]["getChildAt"](0x3)["height"],
              0x2
            )
          )),
          _0x42e9f0["qsnbb"](
            _0x42e9f0["uQUMd"](
              mainImagePosY,
              _0x42e9f0["LqkpC"](
                this["backgroundImg"]["getChildAt"](0x3)["height"],
                0x2
              )
            ),
            _0x42e9f0["TSXZf"](
              _0x42e9f0["qDLpY"](game["height"], 0x23),
              game["cache"]["getBitmapData"](_0x42e9f0["ziaft"])["height"]
            )
          ) &&
            (mainImagePosY = _0x42e9f0["qDLpY"](
              _0x42e9f0["GssxC"](
                game["height"],
                _0x42e9f0["LqkpC"](
                  this["backgroundImg"]["getChildAt"](0x3)["height"],
                  0x2
                )
              ),
              _0x42e9f0["rNwBj"](
                this["backgroundImg"]["getChildAt"](0x3)["height"],
                0x4
              )
            ))),
      puzzleHidden &&
        ((mainImagePosX = _0x42e9f0["aOjsK"](game["width"], 0x1)),
        (mainImagePosY = _0x42e9f0["GZKXh"](game["height"], 0x1))),
      this["updateTilesPosition"](),
      _0x42e9f0["iyLKE"](null, this["backgroundImg"]) &&
        this["backgroundImg"]["position"]["set"](mainImagePosX, mainImagePosY),
      (lastTimeOrientation = GAME_CURRENT_ORIENTATION));
  },
  onPause: function () {
    soundManager["pauseMusic"]();
    gameRunning &&
      (!grpSceneGame["visible"] ||
        grpScenePause["visible"] ||
        grpSceneResult["visible"] ||
        (gameRunning && SceneGame["instance"]["OnPressedFromGameToPause"]()),
      soundManager["pauseMusic"]());
  },
  onResume: function () {
    soundManager["resumeMusic"]();
  },
  RestartGame: function () {
    soundManager["stopMusic"]();
    gameScore = 0x0;
    gameRunning = !0x0;
  },
  ResumeGame: function () {
    gameRunning = !0x0;
    gamePaused = !0x1;
  },
  OnPressedFromGameToPause: function () {
    var _0x28433b = {
      FIbNm: "8|5|1|2|4|3|9|6|0|7|10",
      aVgXL: "music_menu",
      Kqtpo: function (_0x3e056f, _0x266add) {
        return _0x3e056f != _0x266add;
      },
      TlmEt: function (_0x452ad9, _0x480178) {
        return _0x452ad9 != _0x480178;
      },
      LtqSA: "menu-click1",
    };
    var _0x419d88 = _0x28433b["FIbNm"]["split"]("|"),
      _0x367e27 = 0x0;
    while ([]) {
      switch (_0x419d88[_0x367e27++]) {
        case "0":
          SceneMenu["instance"]["ShowAnimated"](0xc8);
          continue;
        case "1":
          SceneGame["instance"]["stopBalloonParticles"]();
          continue;
        case "2":
          soundManager["stopTimer"](_0x28433b["aVgXL"]);
          continue;
        case "3":
          _0x28433b["Kqtpo"](null, ballonTween) &&
            _0x28433b["Kqtpo"](void 0x0, ballonTween) &&
            ballonTween["stop"]();
          continue;
        case "4":
          _0x28433b["TlmEt"](void 0x0, tmpTween) && tmpTween["stop"]();
          continue;
        case "5":
          _0x28433b["TlmEt"](void 0x0, this["timeEvent"]) &&
            this["timeEvent"]["remove"]();
          continue;
        case "6":
          SceneGame["instance"]["HideAnimated"]();
          continue;
        case "7":
          SceneGame["instance"]["onGameOver"](LEVEL_OVER_USER);
          continue;
        case "8":
          gameRunning = !0x1;
          continue;
        case "9":
          soundManager["playSound"](_0x28433b["LtqSA"]);
          continue;
        case "10":
          this["showAds"];
          continue;
      }
      break;
    }
  },
  OnMoreGames: function () {},
  ShowAnimated: function () {
    var _0x595d7a = {
      OUocL: function (_0x2969aa, _0x469fbc) {
        return _0x2969aa + _0x469fbc;
      },
    };
    ScenesTransitions["transitionStarted"]();
    ScenesTransitions["TRANSITION_EFFECT_IN"] =
      Phaser["Easing"]["Quadratic"]["Out"];
    ScenesTransitions["showSceneAlpha"](
      grpSceneGame,
      0x0,
      _0x595d7a["OUocL"](ScenesTransitions["TRANSITION_LENGTH"], 0xa),
      ScenesTransitions["transitionFinished"]
    );
  },
  HideAnimated: function () {
    var _0x5a9f8c = {
      PzTWq: function (_0x500a9b, _0x2a7c4b) {
        return _0x500a9b + _0x2a7c4b;
      },
    };
    ScenesTransitions["transitionStarted"]();
    ScenesTransitions["TRANSITION_EFFECT_IN"] =
      Phaser["Easing"]["Quadratic"]["Out"];
    ScenesTransitions["hideSceneAlpha"](
      grpSceneGame,
      0x0,
      _0x5a9f8c["PzTWq"](ScenesTransitions["TRANSITION_LENGTH"], 0xa)
    );
  },
  StartLevel: function (_0x11d591) {},
  destroyStonesTilesGroups: function () {},
  setGame: function () {
    var _0x41179c = {
      PrURw: "6|11|8|4|9|0|2|1|3|12|7|5|15|16|14|10|13",
      QGGQz: function (_0x3f1509, _0x70060d) {
        return _0x3f1509 / _0x70060d;
      },
      VTnNN: function (_0x132708, _0x30b4f0) {
        return _0x132708 / _0x30b4f0;
      },
      XIVMA: function (_0x315c99, _0x13fddb) {
        return _0x315c99 / _0x13fddb;
      },
      ycXtZ: function (_0x15808c, _0x5517c8) {
        return _0x15808c * _0x5517c8;
      },
      RDvfa: function (_0x34cbe5, _0x2b816f) {
        return _0x34cbe5 == _0x2b816f;
      },
      yMDXo: function (_0x1da841, _0x396ef4) {
        return _0x1da841 == _0x396ef4;
      },
      nslSN: function (_0x20613c, _0x2b93a8) {
        return _0x20613c * _0x2b93a8;
      },
      QTnJh: function (_0x1a42d8, _0x1fa72a) {
        return _0x1a42d8 / _0x1fa72a;
      },
      RbKQH: function (_0x527775, _0xd2b0bf) {
        return _0x527775 / _0xd2b0bf;
      },
      glyiY: function (_0x1ca19c, _0x1d116b) {
        return _0x1ca19c * _0x1d116b;
      },
      qLRWK: function (_0x1018ae, _0xef5d88) {
        return _0x1018ae / _0xef5d88;
      },
    };
    var _0x3beb9f = _0x41179c["PrURw"]["split"]("|"),
      _0x2f8dce = 0x0;
    while ([]) {
      switch (_0x3beb9f[_0x2f8dce++]) {
        case "0":
          tileH2 = _0x41179c["QGGQz"](tileH, 0x2);
          continue;
        case "1":
          tileH5 = _0x41179c["VTnNN"](tileH, 0x5);
          continue;
        case "2":
          tileW5 = _0x41179c["XIVMA"](tileW, 0x5);
          continue;
        case "3":
          tileW35 = _0x41179c["ycXtZ"](0x3, tileW5);
          continue;
        case "4":
          tileH = _0x41179c["ycXtZ"](0x1f4, scaleTileH);
          continue;
        case "5":
          particleSizeH = tileH35;
          continue;
        case "6":
          _0x41179c["RDvfa"](0x0, gameMode)
            ? ((gamePieces = gamePieces32),
              (X_CNT = 0x3),
              (Y_CNT = 0x2),
              (scaleTileW = 0.5333333333),
              (scaleTileH = 0.6),
              (this["layoutPieces"] = 0x2))
            : _0x41179c["RDvfa"](0x1, gameMode)
            ? ((gamePieces = gamePieces43),
              (X_CNT = 0x4),
              (Y_CNT = 0x3),
              (scaleTileH = scaleTileW = 0.4),
              (this["layoutPieces"] = 0x3))
            : _0x41179c["yMDXo"](0x2, gameMode)
            ? ((gamePieces = gamePieces64),
              (X_CNT = 0x6),
              (Y_CNT = 0x4),
              (scaleTileW = 0.2666),
              (scaleTileH = 0.3),
              (this["layoutPieces"] = 0x4))
            : _0x41179c["yMDXo"](0x3, gameMode) &&
              ((gamePieces = gamePieces86),
              (X_CNT = 0x8),
              (Y_CNT = 0x6),
              (scaleTileH = scaleTileW = 0.2),
              (this["layoutPieces"] = 0x5));
          continue;
        case "7":
          particleSizeW = tileW35;
          continue;
        case "8":
          tileW = _0x41179c["nslSN"](0x1f4, scaleTileW);
          continue;
        case "9":
          tileW2 = _0x41179c["QTnJh"](tileW, 0x2);
          continue;
        case "10":
          particleSizeH2 = _0x41179c["RbKQH"](particleSizeH, 0x2);
          continue;
        case "11":
          PIECES_CNT = gamePieces["length"];
          continue;
        case "12":
          tileH35 = _0x41179c["glyiY"](0x3, tileH5);
          continue;
        case "13":
          this["createGameBoard"]();
          continue;
        case "14":
          particleSizeW2 = _0x41179c["qLRWK"](particleSizeW, 0x2);
          continue;
        case "15":
          particleSizeW += 0x5;
          continue;
        case "16":
          particleSizeH += 0x5;
          continue;
      }
      break;
    }
  },
  createGameBoard: function () {
    var _0x1bb4a0 = {
      PDANA: function (_0x59e962, _0xa821a4) {
        return _0x59e962(_0xa821a4);
      },
      jDAnr: function (_0x1f6489, _0x121f74) {
        return _0x1f6489 < _0x121f74;
      },
      Ivhau: function (_0x56ad15, _0x2d4b6f) {
        return _0x56ad15(_0x2d4b6f);
      },
    };
    gameBoard = _0x1bb4a0["PDANA"](Array, Y_CNT);
    var _0x583f11 = 0x0;
    for (i = 0x0; _0x1bb4a0["jDAnr"](i, Y_CNT); i++)
      for (
        gameBoard[i] = _0x1bb4a0["Ivhau"](Array, X_CNT), j = 0x0;
        _0x1bb4a0["jDAnr"](j, X_CNT);
        j++
      )
        gameBoard[i][j] = _0x583f11++;
  },
  createTiles: function (_0x43ec1e) {
    var _0x5f1188 = {
      TTtlY: function (_0x240d11, _0x268d72) {
        return _0x240d11 < _0x268d72;
      },
      oMkjq:
        "16|34|15|40|39|41|22|11|29|37|38|24|35|4|18|17|20|25|32|7|6|3|1|36|30|28|26|21|33|27|23|12|14|2|0|19|9|5|31|8|10|13",
      vJpAl: function (_0x1c9f23, _0x2a1fef) {
        return _0x1c9f23 / _0x2a1fef;
      },
      OkYGI: function (_0x14a9fa, _0x1665a7) {
        return _0x14a9fa * _0x1665a7;
      },
      JaJcl: function (_0x261049, _0x181678) {
        return _0x261049 * _0x181678;
      },
      CSRjn: function (_0xe1c9c5, _0x114a8b) {
        return _0xe1c9c5 == _0x114a8b;
      },
      ANApY: "puzzle_piece",
      JGhvQ: function (_0x135f09, _0x1524e2) {
        return _0x135f09 == _0x1524e2;
      },
      ZTaSM: "puzzle_piece_outline",
      DizMT: function (_0x1ee3d5, _0x43de14) {
        return _0x1ee3d5 == _0x43de14;
      },
      odxHj: function (_0x56edc, _0x2e3c26) {
        return _0x56edc == _0x2e3c26;
      },
      gmRZX: function (_0x37e27d, _0x5b18c7) {
        return _0x37e27d == _0x5b18c7;
      },
      LQeUG: function (_0x266ae9, _0x2cd972) {
        return _0x266ae9 == _0x2cd972;
      },
      NSZPG: function (_0xfafab1, _0x1f5b39) {
        return _0xfafab1 == _0x1f5b39;
      },
      tOCyi: function (_0x265968, _0xc468dc) {
        return _0x265968 == _0xc468dc;
      },
      seflw: function (_0x29aad0, _0x39e8c3) {
        return _0x29aad0 == _0x39e8c3;
      },
      YLArp: function (_0x10e1ff, _0x485735) {
        return _0x10e1ff == _0x485735;
      },
      KzDqr: function (_0x4d75a8, _0x29b5f) {
        return _0x4d75a8 + _0x29b5f;
      },
      EgkWV: function (_0x538bc7, _0xeb5da5) {
        return _0x538bc7 % _0xeb5da5;
      },
      QvIDR: function (_0x168ab5, _0x60724) {
        return _0x168ab5 + _0x60724;
      },
    };
    for (
      var _0x557d96,
        _0x41c3e7,
        _0x3844c5 = 0x0,
        _0x20c292 = 0x0,
        _0x57f81a = 0x0,
        _0x1a494e = 0x0;
      _0x5f1188["TTtlY"](_0x1a494e, PIECES_CNT);
      _0x1a494e++
    ) {
      var _0x5ad591 = _0x5f1188["oMkjq"]["split"]("|"),
        _0x1382c0 = 0x0;
      while ([]) {
        switch (_0x5ad591[_0x1382c0++]) {
          case "0":
            _0x5b2081["hitArea"] = new Phaser["Rectangle"](
              _0x5f1188["vJpAl"](-tileW35, 0x2),
              _0x5f1188["vJpAl"](-tileH35, 0x2),
              tileW35,
              tileH35
            );
            continue;
          case "1":
            _0x185e03["angle"] = _0x5f1188["OkYGI"](
              _0x5f1188["JaJcl"](_0x21244f, _0x557d96),
              _0x41c3e7
            );
            continue;
          case "2":
            _0x5b2081["input"]["enableDrag"](!0x0);
            continue;
          case "3":
            _0x185e03["scale"]["y"] *= _0x41c3e7;
            continue;
          case "4":
            _0x3a1e4f["alphaMask"](_0x43ec1e, _0x2f160a);
            continue;
          case "5":
            _0x5b2081["scale"]["set"](baseScale);
            continue;
          case "6":
            _0x185e03["scale"]["x"] *= _0x557d96;
            continue;
          case "7":
            _0x185e03["angle"] = _0x21244f;
            continue;
          case "8":
            this["groupInit"]["add"](_0x5b2081);
            continue;
          case "9":
            _0x5b2081["events"]["onInputUp"]["add"](this["releaseTile"]);
            continue;
          case "10":
            _0x57f81a++;
            continue;
          case "11":
            _0x2f160a["angle"] = _0x21244f;
            continue;
          case "12":
            _0x5b2081["anchor"]["set"](0.5, 0.5);
            continue;
          case "13":
            lastTimeOrientation = GAME_CURRENT_ORIENTATION;
            continue;
          case "14":
            _0x5b2081["inputEnabled"] = !0x0;
            continue;
          case "15":
            _0x5f1188["CSRjn"](0xe, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x2
                )),
                (_0x21244f = 0x10e),
                (_0x185e03 = 0x2),
                (_0x41c3e7 = _0x557d96 = -0x1))
              : _0x5f1188["CSRjn"](0xf, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x4
                )),
                (_0x21244f = 0x0),
                (_0x185e03 = 0x4),
                (_0x41c3e7 = _0x557d96 = -0x1))
              : _0x5f1188["JGhvQ"](0x10, gamePieces[_0x1a494e]) &&
                ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x2
                )),
                (_0x21244f = 0x5a),
                (_0x185e03 = 0x2),
                (_0x557d96 = -0x1),
                (_0x41c3e7 = 0x1));
            continue;
          case "16":
            var _0x3a1e4f = game["make"]["bitmapData"](tileW, tileH),
              _0x2f160a,
              _0x21244f = 0x0,
              _0x185e03 = 0x0;
            continue;
          case "17":
            _0x3a1e4f["anchor"]["set"](0.5, 0.5);
            continue;
          case "18":
            _0x3a1e4f = game["make"]["image"](0x0, 0x0, _0x3a1e4f);
            continue;
          case "19":
            _0x5b2081["events"]["onInputDown"]["add"](this["pickTile"]);
            continue;
          case "20":
            _0x185e03 = game["make"]["sprite"](
              0x0,
              0x0,
              _0x5f1188["ZTaSM"],
              _0x185e03
            );
            continue;
          case "21":
            _0x5b2081["addChild"](_0x2f160a);
            continue;
          case "22":
            _0x2f160a["anchor"]["set"](0.5, 0.5);
            continue;
          case "23":
            _0x5b2081["addChild"](_0x185e03);
            continue;
          case "24":
            var _0x5b2081 = game["make"]["sprite"](0x0, 0x0);
            continue;
          case "25":
            _0x5f1188["DizMT"](0x5a, Math["abs"](_0x2f160a["angle"]))
              ? _0x185e03["scale"]["set"](scaleTileH, scaleTileW)
              : _0x185e03["scale"]["set"](scaleTileW, scaleTileH);
            continue;
          case "26":
            _0x2f160a["alpha"] = 0.35;
            continue;
          case "27":
            _0x5b2081["addChild"](_0x3a1e4f);
            continue;
          case "28":
            _0x5f1188["odxHj"](0x5a, Math["abs"](_0x2f160a["angle"])) &&
              (_0x2f160a["scale"]["set"](scaleTileH, scaleTileW),
              (_0x2f160a["scale"]["x"] *= _0x557d96),
              (_0x2f160a["scale"]["y"] *= _0x41c3e7),
              (_0x2f160a["angle"] = _0x5f1188["JaJcl"](
                _0x5f1188["JaJcl"](_0x21244f, _0x557d96),
                _0x41c3e7
              )));
            continue;
          case "29":
            _0x2f160a["scale"]["set"](scaleTileW, scaleTileH);
            continue;
          case "30":
            _0x185e03["alpha"] = 0.25;
            continue;
          case "31":
            _0x5b2081["alpha"] = 0.99;
            continue;
          case "32":
            _0x185e03["anchor"]["set"](0.5, 0.5);
            continue;
          case "33":
            _0x5b2081["getChildAt"](0x0)["position"]["setTo"](0x8, 0x8);
            continue;
          case "34":
            _0x5f1188["odxHj"](0x0, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x2
                )),
                (_0x21244f = 0x0),
                (_0x185e03 = 0x2),
                (_0x41c3e7 = _0x557d96 = -0x1))
              : _0x5f1188["odxHj"](0x1, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x3
                )),
                (_0x21244f = 0x5a),
                (_0x185e03 = 0x3),
                (_0x41c3e7 = _0x557d96 = -0x1))
              : _0x5f1188["odxHj"](0x2, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x4
                )),
                (_0x21244f = 0xb4),
                (_0x185e03 = 0x4),
                (_0x41c3e7 = _0x557d96 = -0x1))
              : _0x5f1188["odxHj"](0x3, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x2
                )),
                (_0x21244f = 0x10e),
                (_0x185e03 = 0x2),
                (_0x41c3e7 = _0x557d96 = 0x1))
              : _0x5f1188["odxHj"](0x4, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x2
                )),
                (_0x21244f = 0xb4),
                (_0x185e03 = 0x2),
                (_0x41c3e7 = _0x557d96 = -0x1))
              : _0x5f1188["gmRZX"](0x5, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x2
                )),
                (_0x21244f = 0xb4),
                (_0x185e03 = 0x2),
                (_0x557d96 = -0x1),
                (_0x41c3e7 = 0x1))
              : _0x5f1188["gmRZX"](0x6, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x4
                )),
                (_0x21244f = 0x10e),
                (_0x185e03 = 0x4),
                (_0x41c3e7 = _0x557d96 = 0x1))
              : _0x5f1188["gmRZX"](0x7, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x1
                )),
                (_0x21244f = 0x0),
                (_0x41c3e7 = _0x557d96 = _0x185e03 = 0x1))
              : _0x5f1188["LQeUG"](0x8, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x1
                )),
                (_0x21244f = 0x5a),
                (_0x41c3e7 = _0x557d96 = _0x185e03 = 0x1))
              : _0x5f1188["LQeUG"](0x9, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x3
                )),
                (_0x21244f = 0x0),
                (_0x185e03 = 0x3),
                (_0x41c3e7 = _0x557d96 = 0x1))
              : _0x5f1188["NSZPG"](0xa, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x3
                )),
                (_0x21244f = 0xb4),
                (_0x185e03 = 0x3),
                (_0x41c3e7 = _0x557d96 = 0x1))
              : _0x5f1188["tOCyi"](0xb, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x4
                )),
                (_0x21244f = 0x5a),
                (_0x185e03 = 0x4),
                (_0x41c3e7 = _0x557d96 = 0x1))
              : _0x5f1188["seflw"](0xc, gamePieces[_0x1a494e])
              ? ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x2
                )),
                (_0x21244f = 0x0),
                (_0x185e03 = 0x2),
                (_0x557d96 = -0x1),
                (_0x41c3e7 = 0x1))
              : _0x5f1188["YLArp"](0xd, gamePieces[_0x1a494e]) &&
                ((_0x2f160a = game["make"]["image"](
                  tileW2,
                  tileH2,
                  _0x5f1188["ANApY"],
                  0x3
                )),
                (_0x21244f = 0x5a),
                (_0x185e03 = 0x3),
                (_0x557d96 = -0x1),
                (_0x41c3e7 = 0x1));
            continue;
          case "35":
            _0x5b2081["index"] = _0x57f81a;
            continue;
          case "36":
            _0x185e03["tint"] = 0x0;
            continue;
          case "37":
            _0x2f160a["scale"]["x"] *= _0x557d96;
            continue;
          case "38":
            _0x2f160a["scale"]["y"] *= _0x41c3e7;
            continue;
          case "39":
            _0x43ec1e["y"] = _0x5f1188["KzDqr"](_0x20c292, tileH5);
            continue;
          case "40":
            _0x43ec1e["x"] = _0x5f1188["KzDqr"](_0x3844c5, tileW5);
            continue;
          case "41":
            _0x5f1188["YLArp"](
              0x0,
              _0x5f1188["EgkWV"](_0x5f1188["QvIDR"](_0x1a494e, 0x1), X_CNT)
            )
              ? ((_0x20c292 -= tileH35), (_0x3844c5 = 0x0))
              : (_0x3844c5 -= tileW35);
            continue;
        }
        break;
      }
    }
  },
  shuffle: function () {
    var _0x36195c = {
      tLVFC: "5|2|0|10|12|11|8|7|6|3|1|4|9",
      wLlNN: function (_0x4b60a8, _0x526537) {
        return _0x4b60a8 + _0x526537;
      },
      jRZTR: function (_0x3d68de, _0xca832e) {
        return _0x3d68de / _0xca832e;
      },
      WEZPc: function (_0x1743ae, _0x1c7e9e) {
        return _0x1743ae - _0x1c7e9e;
      },
      stboa: function (_0x25d6bd, _0x1d6ae0) {
        return _0x25d6bd * _0x1d6ae0;
      },
      TTlXq: function (_0x97e4aa, _0x1236a3) {
        return _0x97e4aa / _0x1236a3;
      },
      yNvvl: function (_0x5e0afc, _0x461939) {
        return _0x5e0afc / _0x461939;
      },
      rVYrX: function (_0x5873b8, _0x18fc08) {
        return _0x5873b8 - _0x18fc08;
      },
      ChtjI: function (_0x39b2f3, _0x3b2134) {
        return _0x39b2f3 / _0x3b2134;
      },
      BIooq: function (_0x27d1bb, _0x48d21a) {
        return _0x27d1bb * _0x48d21a;
      },
      XTniL: function (_0x10a58f, _0xf363b9) {
        return _0x10a58f == _0xf363b9;
      },
      obgWN: function (_0x56fadc, _0x815b15) {
        return _0x56fadc * _0x815b15;
      },
      mzjls: function (_0x54cef0, _0x4da796) {
        return _0x54cef0 - _0x4da796;
      },
      OaRDq: function (_0x3c77be, _0x231343) {
        return _0x3c77be / _0x231343;
      },
      uVKEE: function (_0x538642, _0x4b4253) {
        return _0x538642 / _0x4b4253;
      },
      SGSok: function (_0x3a9466, _0x1b2263) {
        return _0x3a9466 < _0x1b2263;
      },
      UsQLP: "7|8|2|6|0|4|1|3|5",
      gXrNb: function (_0x368de9, _0x2758a1) {
        return _0x368de9 == _0x2758a1;
      },
      LFppD: function (_0x20f5c4, _0x4555f4) {
        return _0x20f5c4 * _0x4555f4;
      },
      FJeap: function (_0x574aac, _0x23187a) {
        return _0x574aac > _0x23187a;
      },
      HSSGK: function (_0xb643f, _0x4e64df) {
        return _0xb643f >= _0x4e64df;
      },
      RlQDV: function (_0x8b439f, _0x23d692) {
        return _0x8b439f * _0x23d692;
      },
      fmuTF: function (_0x2385a4, _0x1fa64f) {
        return _0x2385a4 - _0x1fa64f;
      },
      PrDAd: function (_0x1e9a5d, _0xb40939) {
        return _0x1e9a5d * _0xb40939;
      },
    };
    var _0x57041d = _0x36195c["tLVFC"]["split"]("|"),
      _0x5e5e3 = 0x0;
    while ([]) {
      switch (_0x57041d[_0x5e5e3++]) {
        case "0":
          BASE_POS_Y = _0x36195c["wLlNN"](
            _0x36195c["jRZTR"](
              _0x36195c["WEZPc"](
                game["height"],
                _0x36195c["stboa"](
                  _0x36195c["TTlXq"](PIECES_CNT, this["layoutPieces"]),
                  _0x29929c
                )
              ),
              0x2
            ),
            tileH5
          );
          continue;
        case "1":
          SceneGame["instance"]["angleDiff"] = 0x0;
          continue;
        case "2":
          BASE_POS_X = _0x36195c["wLlNN"](
            _0x36195c["yNvvl"](
              _0x36195c["rVYrX"](
                _0x36195c["rVYrX"](
                  this["backgroundImg"]["x"],
                  _0x36195c["ChtjI"](
                    SceneGame["instance"]["mainImage"]["width"],
                    0x2
                  )
                ),
                _0x36195c["BIooq"](this["layoutPieces"], _0x1e95a8)
              ),
              0x2
            ),
            tileW5
          );
          continue;
        case "3":
          this["groupPieces"]["position"]["setTo"](
            horizontalDiff,
            verticalDiff
          );
          continue;
        case "4":
          SceneGame["instance"]["angleDiff"] = _0x36195c["XTniL"](
            GAME_CURRENT_ORIENTATION,
            ORIENTATION_PORTRAIT
          )
            ? -0x5a
            : 0x0;
          continue;
        case "5":
          var _0x1e95a8 = _0x36195c["ChtjI"](
              _0x36195c["obgWN"](0x5, tileW5),
              0x2
            ),
            _0x29929c = _0x36195c["ChtjI"](
              _0x36195c["obgWN"](0x5, tileH5),
              0x2
            );
          continue;
        case "6":
          horizontalDiff = _0x36195c["ChtjI"](
            _0x36195c["mzjls"](
              mainImagePosX,
              _0x36195c["OaRDq"](this["mainImage"]["width"], 0x2)
            ),
            0x2
          );
          continue;
        case "7":
          verticalDiff = _0x36195c["uVKEE"](game["height"], 0x2);
          continue;
        case "8":
          for (
            this["gameOver"] = !0x1;
            _0x36195c["SGSok"](0x0, this["groupInit"]["length"]);

          ) {
            var _0x24455e = _0x36195c["UsQLP"]["split"]("|"),
              _0x23a123 = 0x0;
            while ([]) {
              switch (_0x24455e[_0x23a123++]) {
                case "0":
                  _0x53a9cb["angle"] = Math["floor"](
                    _0x36195c["wLlNN"](
                      _0x36195c["gXrNb"](
                        GAME_CURRENT_ORIENTATION,
                        ORIENTATION_PORTRAIT
                      )
                        ? -0x5a
                        : 0x0,
                      _0x36195c["LFppD"](
                        game["rnd"]["integerInRange"](0xf, 0x32),
                        _0x36195c["FJeap"](
                          0x32,
                          game["rnd"]["integerInRange"](0x0, 0x64)
                        )
                          ? -0x1
                          : 0x1
                      )
                    )
                  );
                  continue;
                case "1":
                  this["groupInit"]["remove"](_0x53a9cb);
                  continue;
                case "2":
                  _0x53a9cb["y"] = Math["floor"](_0xebb5a6);
                  continue;
                case "3":
                  _0x199bbe += _0x1e95a8;
                  continue;
                case "4":
                  this["groupPieces"]["add"](_0x53a9cb);
                  continue;
                case "5":
                  _0x36195c["HSSGK"](
                    _0x199bbe,
                    _0x36195c["wLlNN"](
                      BASE_POS_X,
                      _0x36195c["RlQDV"](_0x1e95a8, this["layoutPieces"])
                    )
                  ) && ((_0x199bbe = BASE_POS_X), (_0xebb5a6 += _0x29929c));
                  continue;
                case "6":
                  _0x53a9cb["scale"]["set"](baseScale);
                  continue;
                case "7":
                  var _0x53a9cb = this["groupInit"]["getRandom"](
                    0x0,
                    this["groupInit"]["length"]
                  );
                  continue;
                case "8":
                  _0x53a9cb["x"] = Math["floor"](_0x199bbe);
                  continue;
              }
              break;
            }
          }
          continue;
        case "9":
          this["groupInit"]["destroy"]();
          continue;
        case "10":
          BASE_POS_X = _0x36195c["fmuTF"](
            tileW5,
            _0x36195c["uVKEE"](
              _0x36195c["RlQDV"](this["layoutPieces"], _0x1e95a8),
              0x2
            )
          );
          continue;
        case "11":
          var _0x199bbe = BASE_POS_X,
            _0xebb5a6 = BASE_POS_Y;
          continue;
        case "12":
          BASE_POS_Y = _0x36195c["fmuTF"](
            tileH5,
            _0x36195c["uVKEE"](
              _0x36195c["PrDAd"](
                _0x36195c["uVKEE"](PIECES_CNT, this["layoutPieces"]),
                _0x29929c
              ),
              0x2
            )
          );
          continue;
      }
      break;
    }
  },
  updateTilesPosition: function () {
    var _0x3be914 = {
      QpAVf: function (_0x3a7cf3, _0x389e3f) {
        return _0x3a7cf3 == _0x389e3f;
      },
      KHweI: function (_0x291e68, _0x1e2758) {
        return _0x291e68 != _0x1e2758;
      },
      VaLcm: function (_0x5adbdf, _0x3dc146) {
        return _0x5adbdf / _0x3dc146;
      },
      fPQUX: function (_0x1191de, _0x5ab275) {
        return _0x1191de - _0x5ab275;
      },
      eRmIH: function (_0x4f8822, _0x544038) {
        return _0x4f8822 / _0x544038;
      },
      XWAiU: function (_0x1626ac, _0x2cd8c6) {
        return _0x1626ac * _0x2cd8c6;
      },
      tXWRp: function (_0x285076, _0x5a8268) {
        return _0x285076 == _0x5a8268;
      },
      QUlUn: function (_0x28e247, _0x504b37) {
        return _0x28e247 - _0x504b37;
      },
    };
    _0x3be914["QpAVf"](GAME_CURRENT_ORIENTATION, ORIENTATION_PORTRAIT)
      ? (_0x3be914["KHweI"](GAME_LAST_ORIENTATION, ORIENTATION_PORTRAIT) &&
          ((GAME_LAST_ORIENTATION = GAME_CURRENT_ORIENTATION),
          this["groupPieces"]["forEach"](function (_0x5414e0) {
            _0x5414e0["angle"] -= 0x5a;
          }, this)),
        (verticalDiff = _0x3be914["VaLcm"](
          _0x3be914["fPQUX"](
            mainImagePosY,
            _0x3be914["VaLcm"](this["mainImage"]["height"], 0x2)
          ),
          0x2
        )),
        (horizontalDiff = _0x3be914["VaLcm"](game["width"], 0x2)),
        (this["groupPieces"]["x"] = horizontalDiff),
        (this["groupPieces"]["y"] = verticalDiff),
        (this["groupPieces"]["rotation"] = _0x3be914["eRmIH"](
          _0x3be914["XWAiU"](0x5a, Math["PI"]),
          0xb4
        )),
        (this["angleDiff"] = -0x5a))
      : _0x3be914["tXWRp"](GAME_CURRENT_ORIENTATION, ORIENTATION_LANDSCAPE) &&
        (_0x3be914["tXWRp"](GAME_LAST_ORIENTATION, ORIENTATION_PORTRAIT) &&
          ((GAME_LAST_ORIENTATION = GAME_CURRENT_ORIENTATION),
          this["groupPieces"]["forEach"](function (_0x53e60f) {
            _0x53e60f["angle"] += 0x5a;
          }, this)),
        (verticalDiff = _0x3be914["eRmIH"](game["height"], 0x2)),
        (horizontalDiff = _0x3be914["eRmIH"](
          _0x3be914["QUlUn"](
            mainImagePosX,
            _0x3be914["eRmIH"](this["mainImage"]["width"], 0x2)
          ),
          0x2
        )),
        (this["groupPieces"]["x"] = horizontalDiff),
        (this["groupPieces"]["y"] = verticalDiff),
        (this["angleDiff"] = 0x0),
        (this["groupPieces"]["rotation"] = 0x0));
  },
  pickTile: function (_0x10893b, _0x150b0c, _0x45d1e8) {
    var _0x8484f6 = { cuBKf: "2|4|0|5|1|3" };
    var _0x579eb4 = _0x8484f6["cuBKf"]["split"]("|"),
      _0xc25342 = 0x0;
    while ([]) {
      switch (_0x579eb4[_0xc25342++]) {
        case "0":
          startPosition[0x1] = _0x10893b["y"];
          continue;
        case "1":
          this["tweenOnPieceScale"] = game["add"]
            ["tween"](_0x10893b["scale"])
            ["to"](
              { x: pickedScale, y: pickedScale },
              0x4b,
              Phaser["Easing"]["Linear"]["none"],
              !0x0
            );
          continue;
        case "2":
          _0x10893b["bringToTop"]();
          continue;
        case "3":
          this["tweenOnPieceRotation"] = game["add"]
            ["tween"](_0x10893b)
            ["to"](
              { angle: SceneGame["instance"]["angleDiff"] },
              0x32,
              Phaser["Easing"]["Linear"]["none"],
              !0x0
            );
          continue;
        case "4":
          startPosition[0x0] = _0x10893b["x"];
          continue;
        case "5":
          startPosition[0x2] = _0x10893b["angle"];
          continue;
      }
      break;
    }
  },
  releaseTile: function (_0x3586e4) {
    var _0x4769a5 = {
      BcvhE: "0|3|6|4|1|5|2",
      oiTuK: function (_0x4a7b56, _0x1e5df8) {
        return _0x4a7b56 - _0x1e5df8;
      },
      SDTsK: function (_0x574c1f, _0x1db40f) {
        return _0x574c1f / _0x1db40f;
      },
      YTKSQ: function (_0x5866b9, _0x5ae9da) {
        return _0x5866b9 / _0x5ae9da;
      },
      rFtGb: function (_0x1416f6, _0x56e6f3) {
        return _0x1416f6 < _0x56e6f3;
      },
      hfHji: function (_0x339ebe, _0x1f1a8f) {
        return _0x339ebe == _0x1f1a8f;
      },
      vcYnv: function (_0x548bf6, _0x33d62f) {
        return _0x548bf6 + _0x33d62f;
      },
      Laoak: function (_0x25adf4, _0x4b0c9e) {
        return _0x25adf4 + _0x4b0c9e;
      },
      IrLwi: function (_0x4a4070, _0x41f297) {
        return _0x4a4070 - _0x41f297;
      },
      InISy: function (_0x2fef30, _0x5a386b) {
        return _0x2fef30 * _0x5a386b;
      },
      pSfhw: function (_0x4553fb, _0x56ef54) {
        return _0x4553fb + _0x56ef54;
      },
      QPaen: function (_0x339614, _0x248087) {
        return _0x339614 * _0x248087;
      },
      ZGjHS: function (_0xa60701, _0x84b8ba) {
        return _0xa60701 + _0x84b8ba;
      },
      Omzmy: function (_0x4ce50c, _0x31ddff) {
        return _0x4ce50c >= _0x31ddff;
      },
      yyfOl: "game_completed",
      uxDQN: "music_menu",
      flfKF: "tile_pop",
    };
    var _0x23835a = _0x4769a5["BcvhE"]["split"]("|"),
      _0x37f3c7 = 0x0;
    while ([]) {
      switch (_0x23835a[_0x37f3c7++]) {
        case "0":
          var _0x2e01e0 = _0x4769a5["oiTuK"](
              SceneGame["instance"]["mainImage"]["worldPosition"]["x"],
              _0x4769a5["SDTsK"](
                SceneGame["instance"]["mainImage"]["width"],
                0x2
              )
            ),
            _0x5dada7 = _0x4769a5["oiTuK"](
              mainImagePosY,
              _0x4769a5["YTKSQ"](
                SceneGame["instance"]["mainImage"]["height"],
                0x2
              )
            );
          continue;
        case "1":
          this["tweenOnPieceScale"]["stop"]();
          continue;
        case "2":
          SceneGame["instance"]["returnToStartPosition"](_0x3586e4);
          continue;
        case "3":
          _0x3586e4["scale"]["set"](0x1, 0x1);
          continue;
        case "4":
          if (
            SceneGame["instance"]["mainImage"]
              ["getBounds"]()
              ["contains"](_0x29fccd, _0x1d5ef5) &&
            _0x4769a5["rFtGb"](_0x2e01e0, X_CNT) &&
            _0x4769a5["rFtGb"](_0x5dada7, Y_CNT) &&
            _0x4769a5["hfHji"](
              gameBoard[_0x5dada7][_0x2e01e0],
              _0x3586e4["index"]
            )
          )
            return (
              (_0x3586e4["angle"] = 0x0),
              _0x3586e4["anchor"]["set"](0x1),
              (_0x3586e4["x"] = _0x4769a5["vcYnv"](
                _0x4769a5["Laoak"](
                  _0x4769a5["IrLwi"](
                    SceneGame["instance"]["mainImage"]["x"],
                    _0x4769a5["YTKSQ"](
                      SceneGame["instance"]["mainImage"]["width"],
                      0x2
                    )
                  ),
                  _0x4769a5["InISy"](_0x2e01e0, tileW35)
                ),
                _0x4769a5["YTKSQ"](tileW35, 0x2)
              )),
              (_0x3586e4["y"] = _0x4769a5["Laoak"](
                _0x4769a5["pSfhw"](
                  _0x4769a5["IrLwi"](
                    SceneGame["instance"]["mainImage"]["y"],
                    _0x4769a5["YTKSQ"](
                      SceneGame["instance"]["mainImage"]["height"],
                      0x2
                    )
                  ),
                  _0x4769a5["QPaen"](_0x5dada7, tileH35)
                ),
                _0x4769a5["YTKSQ"](tileH35, 0x2)
              )),
              (_0x2e01e0 =
                SceneGame["instance"]["mainImage"]["worldPosition"]["x"]),
              (_0x5dada7 =
                SceneGame["instance"]["mainImage"]["worldPosition"]["y"]),
              SceneGame["instance"]["startParticles"](
                _0x4769a5["ZGjHS"](_0x3586e4["x"], _0x2e01e0),
                _0x4769a5["ZGjHS"](_0x3586e4["y"], _0x5dada7)
              ),
              SceneGame["instance"]["groupPlaced"]["add"](_0x3586e4),
              SceneGame["instance"]["groupPieces"]["remove"](_0x3586e4),
              _0x3586e4["children"][0x0]["kill"](),
              (_0x3586e4["children"][0x2]["alpha"] = 0.75),
              (_0x3586e4["inputEnabled"] = !0x1),
              _0x4769a5["Omzmy"](
                0x0,
                SceneGame["instance"]["groupPieces"]["length"]
              ) &&
                (SceneGame["instance"]["hidePieces"](),
                soundManager["playSound"](_0x4769a5["yyfOl"]),
                soundManager["fadeOutMusic"](_0x4769a5["uxDQN"]),
                (this["gameOver"] = !0x0)),
              soundManager["playSound"](_0x4769a5["flfKF"]),
              !0x0
            );
          continue;
        case "5":
          this["tweenOnPieceRotation"]["stop"]();
          continue;
        case "6":
          var _0x29fccd = _0x3586e4["world"]["x"],
            _0x1d5ef5 = _0x3586e4["world"]["y"],
            _0x2e01e0 = Math["floor"](
              _0x4769a5["YTKSQ"](
                _0x4769a5["IrLwi"](_0x29fccd, _0x2e01e0),
                tileW35
              )
            ),
            _0x5dada7 = Math["floor"](
              _0x4769a5["YTKSQ"](
                _0x4769a5["IrLwi"](_0x1d5ef5, _0x5dada7),
                tileH35
              )
            );
          continue;
      }
      break;
    }
  },
  hidePieces: function () {
    puzzleHidden ||
      ((this["backgroundImg"]["getChildAt"](0x1)["alpha"] = 0x1),
      (tmpTween = game["add"]
        ["tween"](SceneGame["instance"]["groupPlaced"])
        ["to"](
          { alpha: 0x0 },
          0x320,
          Phaser["Easing"]["Cubic"]["InOut"],
          !0x0,
          0x0,
          0x0,
          !0x1
        )),
      tmpTween["onComplete"]["add"](
        SceneGame["instance"]["animationAfterTween"],
        this
      ),
      (puzzleHidden = !0x0));
  },
  animationAfterTween: function () {
    game["add"]
      ["tween"](this["backgroundImg"])
      ["to"](
        { x: game["world"]["centerX"], y: game["world"]["centerY"] },
        0xfa,
        Phaser["Easing"]["Elastic"]["Out"],
        !0x0
      );
    ballonTween = game["add"]
      ["tween"](this["backgroundImg"]["scale"])
      ["to"](
        { x: 1.2, y: 1.2 },
        0x1f4,
        Phaser["Easing"]["Elastic"]["Out"],
        !0x0,
        0xfa
      );
    ballonTween["onComplete"]["add"](this["startBalloonParticles"], this);
    SceneGame["instance"]["onGameOver"](LEVEL_OVER_GAME);
  },
  returnToStartPosition: function (_0x41b584) {
    var _0x1673b1 = { HWdxI: "4|0|1|3|2", pyolq: "tile_return" };
    var _0x2a6eb1 = _0x1673b1["HWdxI"]["split"]("|"),
      _0x52ab63 = 0x0;
    while ([]) {
      switch (_0x2a6eb1[_0x52ab63++]) {
        case "0":
          soundManager["playSound"](_0x1673b1["pyolq"]);
          continue;
        case "1":
          game["add"]
            ["tween"](_0x41b584)
            ["to"](
              { angle: startPosition[0x2] },
              0xc8,
              Phaser["Easing"]["Linear"]["none"],
              !0x0
            );
          continue;
        case "2":
          game["add"]
            ["tween"](_0x41b584)
            ["to"](
              { x: startPosition[0x0], y: startPosition[0x1] },
              0xc8,
              Phaser["Easing"]["Linear"]["none"],
              !0x0
            )
            ["onComplete"]["add"](function (_0x2ec96a) {
              _0x2ec96a["inputEnabled"] = !0x0;
            }, this);
          continue;
        case "3":
          game["add"]
            ["tween"](_0x41b584["scale"])
            ["to"](
              { x: baseScale, y: baseScale },
              0x4b,
              Phaser["Easing"]["Linear"]["none"],
              !0x0
            );
          continue;
        case "4":
          _0x41b584["inputEnabled"] = !0x1;
          continue;
      }
      break;
    }
  },
  initParticles: function () {
    var _0x18af55 = {
      UYXWr: function (_0x509792, _0x144b3c) {
        return _0x509792 === _0x144b3c;
      },
      oZQop: function (_0x562dc9, _0x36c3dc) {
        return _0x562dc9 < _0x36c3dc;
      },
      lVGSC: "pak1",
      iBrUD: "white",
      BvlOO: function (_0x519b77, _0x448a9e) {
        return _0x519b77 < _0x448a9e;
      },
    };
    if (_0x18af55["UYXWr"](null, particle))
      for (particle = {}, i = 0x0; _0x18af55["oZQop"](i, PARTICLE_CNT); i++)
        (particle[i] = game["add"]["sprite"](
          0x0,
          0x0,
          _0x18af55["lVGSC"],
          _0x18af55["iBrUD"]
        )),
          particle[i]["anchor"]["set"](0.5),
          particle[i]["kill"]();
    else
      for (i = 0x0; _0x18af55["BvlOO"](i, PARTICLE_CNT); i++)
        particle[i]["kill"]();
  },
  startParticles: function (_0x54b3ed, _0x10546a) {
    var _0x424ef0 = {
      xlKAo: function (_0x4cebd0, _0x3107f0) {
        return _0x4cebd0 < _0x3107f0;
      },
      QDIlJ: function (_0x55c49c, _0x1645d5) {
        return _0x55c49c / _0x1645d5;
      },
      lVuNA: function (_0x58ec70, _0x43ab7c) {
        return _0x58ec70 > _0x43ab7c;
      },
      gPbrW: function (_0x4593db, _0x16f34e) {
        return _0x4593db + _0x16f34e;
      },
      kyatW: function (_0x65eb8, _0x28f76a) {
        return _0x65eb8 - _0x28f76a;
      },
      TdHui: function (_0x26d994, _0x336d51) {
        return _0x26d994 + _0x336d51;
      },
      YKQcJ: function (_0x4348c7, _0x4a17f6) {
        return _0x4348c7 - _0x4a17f6;
      },
      dtvHY: function (_0x2e09f7, _0x83f4d4) {
        return _0x2e09f7 * _0x83f4d4;
      },
      Uuupn: function (_0x2a00d3, _0x464f36) {
        return _0x2a00d3 - _0x464f36;
      },
      NbVOD: function (_0x327ac3, _0xc17a6) {
        return _0x327ac3 + _0xc17a6;
      },
    };
    for (i = 0x0; _0x424ef0["xlKAo"](i, PARTICLE_CNT); i++)
      particle[i]["revive"](),
        particle[i]["scale"]["set"](
          _0x424ef0["QDIlJ"](game["rnd"]["integerInRange"](0x1, 0x5), 0xa)
        ),
        (particle[i]["alpha"] = 0.6),
        (particle[i]["tint"] = 0xccc4bf),
        _0x424ef0["lVuNA"](0x32, game["rnd"]["integerInRange"](0x0, 0x64))
          ? particle[i]["position"]["setTo"](
              _0x424ef0["gPbrW"](
                _0x424ef0["kyatW"](_0x54b3ed, particleSizeW2),
                game["rnd"]["integerInRange"](0x0, particleSizeW)
              ),
              _0x424ef0["TdHui"](
                _0x424ef0["YKQcJ"](_0x10546a, particleSizeH2),
                _0x424ef0["dtvHY"](
                  game["rnd"]["integerInRange"](0x0, 0x1),
                  particleSizeH
                )
              )
            )
          : particle[i]["position"]["setTo"](
              _0x424ef0["TdHui"](
                _0x424ef0["Uuupn"](_0x54b3ed, particleSizeW2),
                _0x424ef0["dtvHY"](
                  game["rnd"]["integerInRange"](0x0, 0x1),
                  particleSizeW
                )
              ),
              _0x424ef0["NbVOD"](
                _0x424ef0["Uuupn"](_0x10546a, particleSizeH2),
                game["rnd"]["integerInRange"](0x0, particleSizeH)
              )
            ),
        particle[i]["bringToTop"]();
    particlesEnabled = !0x0;
  },
  updateParticles: function () {
    var _0x2fc69e = {
      NwzjT: function (_0x37ea53, _0x43797f) {
        return _0x37ea53 < _0x43797f;
      },
      tjtJy: function (_0x4e303b, _0x35d24f) {
        return _0x4e303b - _0x35d24f;
      },
      JnvbG: function (_0x421595, _0x309006) {
        return _0x421595 >= _0x309006;
      },
    };
    if (particlesEnabled)
      for (i = 0x0; _0x2fc69e["NwzjT"](i, PARTICLE_CNT); i++)
        (particle[i]["alpha"] -= 0.02),
          _0x2fc69e["NwzjT"](0x0, particle[i]["scale"]["x"])
            ? particle[i]["scale"]["set"](
                _0x2fc69e["tjtJy"](particle[i]["scale"]["x"], 0.005)
              )
            : particle[i]["kill"](),
          _0x2fc69e["JnvbG"](0x0, particle[i]["alpha"]) &&
            particle[i]["kill"]();
  },
  resetGame: function () {
    var _0x2d3564 = {
      IAQbw: "5|1|2|4|0|3|6",
      NRHFs: function (_0x509b5c, _0x464d80) {
        return _0x509b5c < _0x464d80;
      },
      YOQfW: function (_0x3cc28a, _0x35c9d5) {
        return _0x3cc28a < _0x35c9d5;
      },
    };
    var _0x830318 = _0x2d3564["IAQbw"]["split"]("|"),
      _0x40593f = 0x0;
    while ([]) {
      switch (_0x830318[_0x40593f++]) {
        case "0":
          for (
            SceneGame["instance"]["backgroundImg"]["scale"]["set"](0x1);
            _0x2d3564["NRHFs"](
              0x0,
              SceneGame["instance"]["groupPieces"]["length"]
            );

          )
            (_0x402ab1 = SceneGame["instance"]["groupPieces"]["getAt"](0x0)),
              SceneGame["instance"]["groupInit"]["add"](_0x402ab1),
              SceneGame["instance"]["groupPieces"]["remove"](_0x402ab1),
              _0x4c39ea++;
          continue;
        case "1":
          puzzleHidden = !0x1;
          continue;
        case "2":
          SceneGame["instance"]["backgroundImg"]["getChildAt"](0x1)[
            "alpha"
          ] = 0.15;
          continue;
        case "3":
          for (
            _0x4c39ea = 0x0;
            _0x2d3564["YOQfW"](
              0x0,
              SceneGame["instance"]["groupPlaced"]["length"]
            );

          )
            (_0x402ab1 = SceneGame["instance"]["groupPlaced"]["getAt"](0x0)),
              SceneGame["instance"]["groupInit"]["add"](_0x402ab1),
              SceneGame["instance"]["groupPlaced"]["remove"](_0x402ab1),
              _0x4c39ea++;
          continue;
        case "4":
          SceneGame["instance"]["groupPlaced"]["alpha"] = 0x1;
          continue;
        case "5":
          var _0x402ab1,
            _0x4c39ea = 0x0;
          continue;
        case "6":
          SceneGame["instance"]["shuffle"]();
          continue;
      }
      break;
    }
  },
  initGame: function () {
    var _0x4b6efd = { NHGwo: "3|5|4|0|1|2" };
    var _0x41a539 = _0x4b6efd["NHGwo"]["split"]("|"),
      _0x5a81fa = 0x0;
    while ([]) {
      switch (_0x41a539[_0x5a81fa++]) {
        case "0":
          this["groupPlaced"] = game["add"]["group"]();
          continue;
        case "1":
          this["initParticles"]();
          continue;
        case "2":
          this["createBalloonParticles"]();
          continue;
        case "3":
          this["backgroundImg"] = null;
          continue;
        case "4":
          this["groupPieces"] = game["add"]["group"]();
          continue;
        case "5":
          this["groupInit"] = game["add"]["group"]();
          continue;
      }
      break;
    }
  },
  __startGame: function (_0x30ae59, _0x493e02) {
    var _0x28e19c = {
      jyxbo:
        "28|10|5|27|23|1|32|25|18|6|14|20|16|12|31|36|3|19|33|2|35|29|8|15|17|11|0|26|7|30|9|24|21|13|4|22|34",
      caJBg: function (_0x424f83, _0x3db6ad) {
        return _0x424f83 === _0x3db6ad;
      },
      KtbiL: "11|6|7|9|13|4|0|1|2|16|8|3|15|12|5|14|10|17",
      CEBNU: "frame",
      XNauW: "pak1",
      fWsst: "white_point",
      ykWHQ: function (_0x4b4da8, _0x2080af) {
        return _0x4b4da8 + _0x2080af;
      },
      JmIfz: "img_",
      gCWLx: function (_0x50466d, _0x4fcbf7) {
        return _0x50466d == _0x4fcbf7;
      },
      eKjVK: function (_0x402d37, _0x410535) {
        return _0x402d37 - _0x410535;
      },
      eEOTx: function (_0x5eb5d1, _0x3373fa) {
        return _0x5eb5d1 - _0x3373fa;
      },
      qzpoZ: function (_0x52fc4d, _0x3f846d) {
        return _0x52fc4d / _0x3f846d;
      },
      qBRbH: function (_0x4f61e8, _0x185d7a) {
        return _0x4f61e8 >> _0x185d7a;
      },
      buGvU: function (_0x5f2905, _0x1fd2c4) {
        return _0x5f2905 - _0x1fd2c4;
      },
      ApzFb: function (_0x1bfad9, _0x11556a) {
        return _0x1bfad9 / _0x11556a;
      },
      zmFVe: function (_0x92a6ce, _0x801ba8) {
        return _0x92a6ce >= _0x801ba8;
      },
      mTFfN: function (_0x5ac508, _0x523478) {
        return _0x5ac508 / _0x523478;
      },
      zXgPV: function (_0x3f2740) {
        return _0x3f2740();
      },
      ekiDu: function (_0xf90a30, _0x5b497f) {
        return _0xf90a30 === _0x5b497f;
      },
      GXhDs: function (_0x3b0f63, _0x2f0739) {
        return _0x3b0f63 + _0x2f0739;
      },
      bjdOy: function (_0xb7296, _0x302dd6) {
        return _0xb7296 + _0x302dd6;
      },
      Eldfm: function (_0x16fd07, _0x4819f3) {
        return _0x16fd07 - _0x4819f3;
      },
      VhtbW: function (_0x505b1e, _0x2807c2) {
        return _0x505b1e - _0x2807c2;
      },
      XuoDe: function (_0x4d01d0, _0x542c17) {
        return _0x4d01d0 / _0x542c17;
      },
    };
    var _0x352800 = _0x28e19c["jyxbo"]["split"]("|"),
      _0x454a3d = 0x0;
    while ([]) {
      switch (_0x352800[_0x454a3d++]) {
        case "0":
          puzzleHidden = !0x1;
          continue;
        case "1":
          this["mainImage"]["alpha"] = 0x1;
          continue;
        case "2":
          if (_0x28e19c["caJBg"](null, this["backgroundImg"])) {
            var _0x1b12c6 = _0x28e19c["KtbiL"]["split"]("|"),
              _0x44a927 = 0x0;
            while ([]) {
              switch (_0x1b12c6[_0x44a927++]) {
                case "0":
                  _0x576315["alpha"] = 0x1;
                  continue;
                case "1":
                  var _0xf86103 = game["make"]["sprite"](
                    0x0,
                    0x0,
                    _0x28e19c["CEBNU"]
                  );
                  continue;
                case "2":
                  _0xf86103["anchor"]["set"](0.5);
                  continue;
                case "3":
                  this["backgroundImg"]["addChild"](this["mainImage"]);
                  continue;
                case "4":
                  _0x576315["height"] = this["mainImage"]["height"];
                  continue;
                case "5":
                  this["backgroundImg"]["addChild"](this["groupPieces"]);
                  continue;
                case "6":
                  var _0x576315 = game["make"]["sprite"](
                    0x0,
                    0x0,
                    _0x28e19c["XNauW"],
                    _0x28e19c["fWsst"]
                  );
                  continue;
                case "7":
                  _0x576315["anchor"]["set"](0.5);
                  continue;
                case "8":
                  this["backgroundImg"]["addChild"](_0x576315);
                  continue;
                case "9":
                  _0x576315["tint"] = 0xefc1a0;
                  continue;
                case "10":
                  this["backgroundImg"]["position"]["setTo"](
                    game["world"]["centerX"],
                    game["world"]["centerY"]
                  );
                  continue;
                case "11":
                  this["backgroundImg"] = game["make"]["sprite"](0x0, 0x0);
                  continue;
                case "12":
                  this["backgroundImg"]["addChild"](_0xf86103);
                  continue;
                case "13":
                  _0x576315["width"] = this["mainImage"]["width"];
                  continue;
                case "14":
                  this["backgroundImg"]["anchor"]["set"](0.5);
                  continue;
                case "15":
                  this["backgroundImg"]["addChild"](this["groupPlaced"]);
                  continue;
                case "16":
                  _0xf86103["scale"]["set"](0.395);
                  continue;
                case "17":
                  this["backgroundImg"]["scale"]["set"](0x1);
                  continue;
              }
              break;
            }
          } else
            this["backgroundImg"]["getChildAt"](0x1)["frameName"] = _0x28e19c[
              "ykWHQ"
            ](_0x28e19c["JmIfz"], _0x493e02);
          continue;
        case "3":
          this["mainImage"]["anchor"]["set"](0.5);
          continue;
        case "4":
          this["updateTilesPosition"]();
          continue;
        case "5":
          GAME_LAST_ORIENTATION = GAME_CURRENT_ORIENTATION;
          continue;
        case "6":
          this["groupPieces"]["removeAll"]();
          continue;
        case "7":
          grpSceneGame["remove"](this["backgroundImg"]);
          continue;
        case "8":
          _0x28e19c["gCWLx"](GAME_CURRENT_ORIENTATION, ORIENTATION_LANDSCAPE)
            ? ((mainImagePosX = _0x28e19c["eKjVK"](
                _0x28e19c["eEOTx"](
                  game["width"],
                  _0x28e19c["qzpoZ"](
                    this["backgroundImg"]["getChildAt"](0x3)["width"],
                    0x2
                  )
                ),
                _0x28e19c["qzpoZ"](
                  this["backgroundImg"]["getChildAt"](0x3)["width"],
                  0x12
                )
              )),
              (mainImagePosY = game["world"]["centerY"]))
            : ((mainImagePosX = _0x28e19c["qBRbH"](game["width"], 0x1)),
              (mainImagePosY = _0x28e19c["eEOTx"](
                _0x28e19c["buGvU"](
                  game["height"],
                  _0x28e19c["ApzFb"](
                    this["backgroundImg"]["getChildAt"](0x3)["height"],
                    0x2
                  )
                ),
                _0x28e19c["ApzFb"](
                  this["backgroundImg"]["getChildAt"](0x3)["height"],
                  0x4
                )
              )));
          continue;
        case "9":
          grpSceneGame["add"](this["backgroundImg"]);
          continue;
        case "10":
          _0x493e02 = _0x28e19c["zmFVe"](0x0, _0x493e02) ? 0x1 : _0x493e02;
          continue;
        case "11":
          this["backgroundImg"]["scale"]["set"](0x1);
          continue;
        case "12":
          this["groupPieces"]["alpha"] = 0x1;
          continue;
        case "13":
          h2 = _0x28e19c["ApzFb"](game["height"], 0x2);
          continue;
        case "14":
          this["groupPlaced"]["removeAll"]();
          continue;
        case "15":
          this["backgroundImg"]["anchor"]["set"](0.5);
          continue;
        case "16":
          this["groupInit"]["alpha"] = 0x1;
          continue;
        case "17":
          this["backgroundImg"]["position"]["setTo"](
            mainImagePosX,
            mainImagePosY
          );
          continue;
        case "18":
          this["groupInit"]["removeAll"]();
          continue;
        case "19":
          this["mainImage"]["alpha"] = 0.15;
          continue;
        case "20":
          this["groupPlaced"]["alpha"] = 0x1;
          continue;
        case "21":
          w2 = _0x28e19c["mTFfN"](game["width"], 0x2);
          continue;
        case "22":
          _0x28e19c["zXgPV"](analyticsOnLevelStartEvent);
          continue;
        case "23":
          this["mainImage"]["anchor"]["set"](0x0);
          continue;
        case "24":
          grpSceneGame["add"](this["groupPieces"]);
          continue;
        case "25":
          this["mainImage"]["position"]["setTo"](0x0, 0x0);
          continue;
        case "26":
          this["shuffle"]();
          continue;
        case "27":
          _0x28e19c["ekiDu"](null, this["mainImage"])
            ? (this["mainImage"] = game["make"]["sprite"](
                0x0,
                0x0,
                _0x28e19c["XNauW"],
                _0x28e19c["GXhDs"](_0x28e19c["JmIfz"], _0x493e02)
              ))
            : (this["mainImage"]["frameName"] = _0x28e19c["bjdOy"](
                _0x28e19c["JmIfz"],
                _0x493e02
              ));
          continue;
        case "28":
          gameMode = _0x30ae59;
          continue;
        case "29":
          mainImagePosY = game["world"]["centerY"];
          continue;
        case "30":
          grpSceneGame["remove"](this["groupPieces"]);
          continue;
        case "31":
          this["setGame"]();
          continue;
        case "32":
          this["mainImage"]["scale"]["set"](0x1);
          continue;
        case "33":
          this["mainImage"]["position"]["setTo"](0x0, 0x0);
          continue;
        case "34":
          SceneGame["instance"]["sessionRunning"] = !0x0;
          continue;
        case "35":
          mainImagePosX = _0x28e19c["Eldfm"](
            _0x28e19c["VhtbW"](
              game["width"],
              _0x28e19c["XuoDe"](
                this["backgroundImg"]["getChildAt"](0x3)["width"],
                0x2
              )
            ),
            _0x28e19c["XuoDe"](
              this["backgroundImg"]["getChildAt"](0x3)["width"],
              0x12
            )
          );
          continue;
        case "36":
          this["createTiles"](this["mainImage"]);
          continue;
      }
      break;
    }
  },
  startGame: function (_0x43b84b, _0x4713f4) {
    var _0x150a62 = {
      tEEtN: function (_0x302efc) {
        return _0x302efc();
      },
    };
    adinplay_onAdStarted = function () {
      this["__startGame"](_0x43b84b, _0x4713f4);
    }["bind"](this);
    adinplay_onAdFinished = function () {};
    _0x150a62["tEEtN"](adinplay_playVideoAd);
  },
  returnToMenuAfterEnd: function () {
    SceneGame["instance"]["HideAnimated"]();
    SceneMenu["instance"]["ShowAnimated"](0xc8);
  },
  createBalloonParticles: function () {
    var _0xc18da = {
      xfHSL: "6|1|2|7|4|5|0|3|8",
      SKorI: "pak1",
      sglQO: "balon",
      MKbpK: function (_0x15f3a0, _0x22b922) {
        return _0x15f3a0 < _0x22b922;
      },
      vpZki: "4|14|8|5|11|13|9|7|1|12|0|6|10|3|2",
      sJvmh: "explosion_baloon_0",
      ClDnj: "explosion_animation",
      tdlRH: "explosion_baloon_1",
      UKNEh: "explosion_baloon_2",
      faLtG: "explosion_baloon_3",
      IkLgX: "explosion_baloon_4",
    };
    var _0x3edc6a = _0xc18da["xfHSL"]["split"]("|"),
      _0x5a4bbf = 0x0;
    while ([]) {
      switch (_0x3edc6a[_0x5a4bbf++]) {
        case "0":
          generateNew = runParticles = !0x1;
          continue;
        case "1":
          BALLOON_CNT = 0x19;
          continue;
        case "2":
          balloonMaxHeight = game["cache"]["getFrameByName"](
            _0xc18da["SKorI"],
            _0xc18da["sglQO"]
          )["height"];
          continue;
        case "3":
          balloonGrp["visible"] = !0x1;
          continue;
        case "4":
          balloonGrp = game["add"]["group"]();
          continue;
        case "5":
          for (i = 0x0; _0xc18da["MKbpK"](i, BALLOON_CNT); i++) {
            var _0x27b3ea = _0xc18da["vpZki"]["split"]("|"),
              _0x542098 = 0x0;
            while ([]) {
              switch (_0x27b3ea[_0x542098++]) {
                case "0":
                  _0x28a4c0["inputEnabled"] = !0x0;
                  continue;
                case "1":
                  _0x242a94["onComplete"]["add"](
                    SceneGame["instance"]["onAnimationEnd"],
                    this
                  );
                  continue;
                case "2":
                  balloonGrp["addChild"](_0x28a4c0);
                  continue;
                case "3":
                  _0x28a4c0["idx"] = i;
                  continue;
                case "4":
                  var _0x28a4c0 = game["make"]["sprite"](0x0, 0x0);
                  continue;
                case "5":
                  _0x8f80ed["anchor"]["set"](0.5);
                  continue;
                case "6":
                  _0x28a4c0["events"]["onInputDown"]["add"](this["popBalloon"]);
                  continue;
                case "7":
                  _0x8f80ed["visible"] = !0x1;
                  continue;
                case "8":
                  var _0x8f80ed = game["make"]["sprite"](
                    0x0,
                    0x0,
                    _0xc18da["SKorI"],
                    _0xc18da["sglQO"]
                  );
                  continue;
                case "9":
                  _0x8f80ed["anchor"]["set"](0.5);
                  continue;
                case "10":
                  this["createParticle"](_0x28a4c0);
                  continue;
                case "11":
                  _0x28a4c0["addChild"](_0x8f80ed);
                  continue;
                case "12":
                  _0x28a4c0["addChild"](_0x8f80ed);
                  continue;
                case "13":
                  var _0x8f80ed = game["make"]["sprite"](
                      0x0,
                      0x0,
                      _0xc18da["SKorI"],
                      _0xc18da["sJvmh"]
                    ),
                    _0x242a94 = _0x8f80ed["animations"]["add"](
                      _0xc18da["ClDnj"],
                      [
                        _0xc18da["sJvmh"],
                        _0xc18da["tdlRH"],
                        _0xc18da["UKNEh"],
                        _0xc18da["faLtG"],
                        _0xc18da["IkLgX"],
                      ]
                    );
                  continue;
                case "14":
                  _0x28a4c0["anchor"]["set"](0.5);
                  continue;
              }
              break;
            }
          }
          continue;
        case "6":
          balloons = {};
          continue;
        case "7":
          generateNew = runParticles = !0x0;
          continue;
        case "8":
          grpSceneGame["add"](balloonGrp);
          continue;
      }
      break;
    }
  },
  updateBalloonPosition: function () {
    var _0x4ccc3a = {
      aVLhZ: function (_0x59c545, _0x23bec5) {
        return _0x59c545 != _0x23bec5;
      },
      jDySp: function (_0x17dff2, _0x16b1da) {
        return _0x17dff2 > _0x16b1da;
      },
      gGTGx: function (_0x20f7af, _0x81c313) {
        return _0x20f7af + _0x81c313;
      },
      OXhuC: "pak1",
      KvRUU: "balon",
    };
    if (_0x4ccc3a["aVLhZ"](void 0x0, balloonGrp))
      for (i = 0x0; _0x4ccc3a["jDySp"](0x19, i); i++)
        balloonGrp["getChildAt"](i)["y"] = _0x4ccc3a["gGTGx"](
          game["height"],
          game["cache"]["getFrameByName"](
            _0x4ccc3a["OXhuC"],
            _0x4ccc3a["KvRUU"]
          )["height"]
        );
  },
  updateBalloonParticles: function () {
    var _0x49888d = {
      nzZlk: function (_0x2dde91, _0x38eb2c) {
        return _0x2dde91 < _0x38eb2c;
      },
      dpsIj: function (_0x126839, _0x5f5315) {
        return _0x126839 || _0x5f5315;
      },
    };
    if (runParticles) {
      this["checkActive"]();
      for (i = 0x0; _0x49888d["nzZlk"](i, BALLOON_CNT); i++)
        (balloonGrp["getChildAt"](i)["y"] -=
          balloonGrp["getChildAt"](i)["speed"]),
          _0x49888d["nzZlk"](
            balloonGrp["getChildAt"](i)["y"],
            -balloonMaxHeight
          ) && this["createParticle"](balloonGrp["getChildAt"](i));
      runParticles = _0x49888d["dpsIj"](generateNew, !isScreenEmpty);
      runParticles ||
        (this["timeEvent"] = game["time"]["events"]["add"](
          0x1f4,
          SceneGame["instance"]["returnToMenuAfterEnd"],
          this
        ));
    }
  },
  createParticle: function (_0x33c9b3) {
    var _0x2646ac = {
      nfpIG: function (_0x14edeb, _0x9fcf25) {
        return _0x14edeb + _0x9fcf25;
      },
      ybHyc: function (_0x54445c, _0x42ed1c) {
        return _0x54445c / _0x42ed1c;
      },
    };
    _0x33c9b3["getChildAt"](0x0)["visible"] = !0x1;
    _0x33c9b3["getChildAt"](0x1)["visible"] = !0x1;
    generateNew &&
      ((_0x33c9b3["speed"] = game["rnd"]["integerInRange"](0x2, 0x6)),
      (_0x33c9b3["x"] = game["rnd"]["integerInRange"](0x0, game["width"])),
      (_0x33c9b3["y"] = _0x2646ac["nfpIG"](game["height"], balloonMaxHeight)),
      _0x33c9b3["scale"]["set"](
        _0x2646ac["ybHyc"](game["rnd"]["integerInRange"](0x5a, 0x96), 0x64)
      ),
      (_0x33c9b3["getChildAt"](0x0)["tint"] =
        balloonColor[game["rnd"]["integerInRange"](0x0, 0xc)]),
      (_0x33c9b3["getChildAt"](0x1)["tint"] =
        _0x33c9b3["getChildAt"](0x0)["tint"]),
      (_0x33c9b3["getChildAt"](0x0)["visible"] = !0x0),
      (_0x33c9b3["getChildAt"](0x1)["visible"] = !0x1),
      (_0x33c9b3["visible"] = !0x0),
      (_0x33c9b3["inputEnabled"] = !0x0),
      _0x33c9b3["revive"]());
  },
  popBalloon: function (_0x13c25b) {
    var _0x362661 = {
      RKAin: "3|4|0|1|2|5",
      AAbpy: "explosion_animation",
      HgyeI: "pop_balloon",
    };
    var _0x3ef020 = _0x362661["RKAin"]["split"]("|"),
      _0x2bc19e = 0x0;
    while ([]) {
      switch (_0x3ef020[_0x2bc19e++]) {
        case "0":
          _0x13c25b["getChildAt"](0x1)["visible"] = !0x0;
          continue;
        case "1":
          _0x13c25b["getChildAt"](0x1)["animations"]["play"](
            _0x362661["AAbpy"],
            0xf,
            !0x1
          );
          continue;
        case "2":
          _0x13c25b["getChildAt"](0x1)["revive"]();
          continue;
        case "3":
          soundManager["playSound"](_0x362661["HgyeI"]);
          continue;
        case "4":
          _0x13c25b["getChildAt"](0x0)["visible"] = !0x1;
          continue;
        case "5":
          _0x13c25b["inputEnabled"] = !0x1;
          continue;
      }
      break;
    }
  },
  onAnimationEnd: function (_0x2c3555) {
    _0x2c3555["parent"]["kill"]();
    _0x2c3555["kill"]();
    this["createParticle"](_0x2c3555["parent"]);
  },
  startBalloonParticles: function () {
    var _0x315005 = {
      lNjrI: "2|1|0|3|4",
      GJHmk: function (_0x2b9267, _0x1852b6) {
        return _0x2b9267 < _0x1852b6;
      },
      FbpsL: function (_0x2ec7c2, _0xa5052a) {
        return _0x2ec7c2 + _0xa5052a;
      },
      VxdeL: function (_0x57d59a, _0xfc6b6a) {
        return _0x57d59a * _0xfc6b6a;
      },
      jbLrw: "pak1",
      gptDi: "balon",
    };
    var _0x33f0e6 = _0x315005["lNjrI"]["split"]("|"),
      _0x335a30 = 0x0;
    while ([]) {
      switch (_0x33f0e6[_0x335a30++]) {
        case "0":
          game["time"]["events"]["add"](
            0x157c,
            function () {
              generateNew = !0x1;
            },
            this
          );
          continue;
        case "1":
          for (i = 0x0; _0x315005["GJHmk"](i, BALLOON_CNT); i++)
            this["createParticle"](balloonGrp["getChildAt"](i)),
              (balloonGrp["getChildAt"](i)["y"] = _0x315005["FbpsL"](
                game["height"],
                _0x315005["VxdeL"](
                  game["rnd"]["integerInRange"](0x1, 0x2),
                  game["cache"]["getFrameByName"](
                    _0x315005["jbLrw"],
                    _0x315005["gptDi"]
                  )["height"]
                )
              ));
          continue;
        case "2":
          generateNew = runParticles = balloonGrp["visible"] = !0x0;
          continue;
        case "3":
          grpSceneGame["bringToTop"](balloonGrp);
          continue;
        case "4":
          grpSceneGame["bringToTop"](btnMenu);
          continue;
      }
      break;
    }
  },
  checkActive: function () {
    var _0x517613 = {
      xjWBW: function (_0x54e52f, _0x1a92bb) {
        return _0x54e52f < _0x1a92bb;
      },
      erPIZ: function (_0x5316dc, _0xb5dd0a) {
        return _0x5316dc >= _0xb5dd0a;
      },
    };
    isScreenEmpty = !0x1;
    var _0x592d2c = 0x0;
    for (i = 0x0; _0x517613["xjWBW"](i, BALLOON_CNT); i++)
      _0x592d2c += balloonGrp["getChildAt"](i)["getChildAt"](0x0)["visible"]
        ? 0x1
        : 0x0;
    isScreenEmpty = _0x517613["erPIZ"](0x0, _0x592d2c);
  },
  stopBalloonParticles: function () {
    var _0x5b3fc7 = {
      zRBCM: function (_0x3e9c9d, _0xe1992c) {
        return _0x3e9c9d + _0xe1992c;
      },
    };
    generateNew = runParticles = balloonGrp["visible"] = !0x1;
    balloonGrp["forEach"](function (_0x3f9354) {
      _0x3f9354["y"] = _0x5b3fc7["zRBCM"](game["height"], balloonMaxHeight);
    }, this);
  },
  onGameOver: function (_0x1e26b5) {
    var _0x4f2e4b = {
      HNjxA: function (_0x338e41, _0x4e5ad9) {
        return _0x338e41 !== _0x4e5ad9;
      },
    };
    _0x4f2e4b["HNjxA"](!0x1, SceneGame["instance"]["sessionRunning"]) &&
      (SceneGame["instance"]["sessionRunning"] = !0x1);
  },
};
var LEVEL_OVER_USER = 0x0,
  LEVEL_OVER_GAME = 0x1;
var SceneOverlay = function () {
  SceneOverlay["instance"] = this;
  this["create"]();
};
SceneOverlay["instance"] = null;
SceneOverlay["prototype"] = {
  create: function () {
    var _0x4ec421 = {
      sNxPY: "3|9|0|7|2|4|8|6|1|5",
      HjvSB: function (_0x218375, _0x122f03) {
        return _0x218375 >> _0x122f03;
      },
      XqGRf: "pak1",
      HAnfn: "blank",
      yoGOU: "grpSceneOverlay",
    };
    var _0x37b506 = _0x4ec421["sNxPY"]["split"]("|"),
      _0x256ae7 = 0x0;
    while ([]) {
      switch (_0x37b506[_0x256ae7++]) {
        case "0":
          imgOverlay = grpSceneOverlay["create"](
            _0x4ec421["HjvSB"](game["width"], 0x1),
            _0x4ec421["HjvSB"](game["height"], 0x1),
            _0x4ec421["XqGRf"],
            _0x4ec421["HAnfn"]
          );
          continue;
        case "1":
          imgOverlay["inputEnabled"] = !0x0;
          continue;
        case "2":
          imgOverlay["width"] = game["width"];
          continue;
        case "3":
          grpSceneOverlay = game["add"]["group"]();
          continue;
        case "4":
          imgOverlay["height"] = game["height"];
          continue;
        case "5":
          grpSceneOverlay["visible"] = !0x1;
          continue;
        case "6":
          imgOverlay["tint"] = 0x1d1d1d;
          continue;
        case "7":
          imgOverlay["anchor"]["set"](0.5);
          continue;
        case "8":
          imgOverlay["alpha"] = 0.8;
          continue;
        case "9":
          grpSceneOverlay["name"] = _0x4ec421["yoGOU"];
          continue;
      }
      break;
    }
  },
  onResolutionChange: function () {
    var _0x289693 = {
      xYHyR: function (_0x3ea1a8, _0x2a387a) {
        return _0x3ea1a8 >> _0x2a387a;
      },
      kTxtq: function (_0x323389, _0x34e39c) {
        return _0x323389 >> _0x34e39c;
      },
    };
    imgOverlay["reset"](
      _0x289693["xYHyR"](game["width"], 0x1),
      _0x289693["kTxtq"](game["height"], 0x1)
    );
    imgOverlay["width"] = game["width"];
    imgOverlay["height"] = game["height"];
  },
  ShowAnimated: function () {
    SceneOverlay["instance"]["onResolutionChange"]();
    ScenesTransitions["showSceneAlpha"](
      grpSceneOverlay,
      0x0,
      ScenesTransitions["TRANSITION_LENGTH"]
    );
  },
  HideAnimated: function () {
    ScenesTransitions["hideSceneAlpha"](
      grpSceneOverlay,
      0x0,
      ScenesTransitions["TRANSITION_LENGTH"]
    );
  },
};
var SceneSounds = function () {
  var _0x4da950 = {
    VhtBT: function (_0x2c6726, _0x21a07d) {
      return _0x2c6726 - _0x21a07d;
    },
  };
  SceneSounds["instance"] = this;
  this["buttonsPosY"] = _0x4da950["VhtBT"](game["height"], 0x32);
  this["create"]();
};
SceneSounds["instance"] = null;
SceneSounds["prototype"] = {
  create: function () {
    var _0x1fef82 = {
      HtUKp: "8|4|7|6|1|2|9|0|3|5",
      stFcw: function (_0x301bd9, _0x3d1f4c) {
        return _0x301bd9 - _0x3d1f4c;
      },
      nLiqd: "pak1",
      HqVtY: "sound-on",
      OIuay: "sound-off",
      fscUk: function (_0x42556d, _0x27262a, _0x4f83c4, _0x2c4a58, _0x4215d5) {
        return _0x42556d(_0x27262a, _0x4f83c4, _0x2c4a58, _0x4215d5);
      },
      stluD: function (_0x22e417, _0x2477ee) {
        return _0x22e417 + _0x2477ee;
      },
      XffOe: function (_0x4ab598, _0x4ba793) {
        return _0x4ab598 + _0x4ba793;
      },
      zPazy: function (_0x59efbf, _0x3c0106) {
        return _0x59efbf + _0x3c0106;
      },
      toetd: "build\x20",
      QfeUJ: "]\x20\x20",
      qSLNQ: "11px\x20Arial",
      sDTPe: "#FFFFFF",
      Xhpms: "full-screen",
      dcZdr: function (
        _0x1c0cfe,
        _0x1712cb,
        _0x15ee20,
        _0x198601,
        _0x6677ac,
        _0x4eb9c9
      ) {
        return _0x1c0cfe(_0x1712cb, _0x15ee20, _0x198601, _0x6677ac, _0x4eb9c9);
      },
    };
    var _0x205663 = _0x1fef82["HtUKp"]["split"]("|"),
      _0x390a55 = 0x0;
    while ([]) {
      switch (_0x205663[_0x390a55++]) {
        case "0":
          txtBuildString["visible"] = GameData["BuildDebug"];
          continue;
        case "1":
          SOUNDS_ENABLED &&
            ((btnSoundsToggle = grpSceneSounds["create"](
              _0x1fef82["stFcw"](game["width"], 0x32),
              this["buttonsPosY"],
              _0x1fef82["nLiqd"],
              soundManager["musicPlaying"]
                ? _0x1fef82["HqVtY"]
                : _0x1fef82["OIuay"]
            )),
            btnSoundsToggle["anchor"]["set"](0.5),
            _0x1fef82["fscUk"](
              AddButtonEvents,
              btnSoundsToggle,
              this["ToggleSounds"],
              ButtonOnInputOver,
              ButtonOnInputOut
            ));
          continue;
        case "2":
          txtBuildString = game["add"]["text"](
            0x2,
            0x2,
            _0x1fef82["stluD"](
              _0x1fef82["stluD"](
                _0x1fef82["stluD"](
                  _0x1fef82["XffOe"](
                    _0x1fef82["zPazy"](
                      _0x1fef82["toetd"],
                      GameData["BuildString"]
                    ),
                    "\x20["
                  ),
                  SceneSounds["instance"]["GetRenderTypeName"](
                    game["renderer"]["type"]
                  )
                ),
                _0x1fef82["QfeUJ"]
              ),
              SceneSounds["instance"]["GetPhaserSettingsString"]()
            ),
            { font: _0x1fef82["qSLNQ"], fill: _0x1fef82["sDTPe"] }
          );
          continue;
        case "3":
          grpSceneSounds["add"](txtBuildString);
          continue;
        case "4":
          btnFullscreenToggle = grpSceneSounds["create"](
            0x32,
            this["buttonsPosY"],
            _0x1fef82["nLiqd"],
            _0x1fef82["Xhpms"]
          );
          continue;
        case "5":
          SceneSounds["instance"]["onResolutionChange"]();
          continue;
        case "6":
          _0x1fef82["dcZdr"](
            AddButtonEvents,
            btnFullscreenToggle,
            function () {
              this["button"]["buttonPressed"] = !0x1;
            },
            ButtonOnInputOver,
            ButtonOnInputOut,
            this["ToggleFullscreen"]
          );
          continue;
        case "7":
          btnFullscreenToggle["anchor"]["set"](0.5);
          continue;
        case "8":
          grpSceneSounds = game["add"]["group"]();
          continue;
        case "9":
          txtBuildString["anchor"]["x"] = 0x0;
          continue;
      }
      break;
    }
  },
  update: function () {
    var _0x387d74 = { bjnFj: "full-screen2", zxmNV: "full-screen" };
    btnFullscreenToggle["frameName"] = screenfull["isFullscreen"]
      ? _0x387d74["bjnFj"]
      : _0x387d74["zxmNV"];
  },
  onResolutionChange: function () {
    var _0x4d2774 = {
      ztcPD: "2|1|3|0|4",
      yBslA: function (_0x3e09ac, _0x5db0b7) {
        return _0x3e09ac == _0x5db0b7;
      },
      YqEhK: function (_0x269c72, _0x57a540) {
        return _0x269c72 - _0x57a540;
      },
      aAArw: function (_0x2082c5, _0x3cc8b3) {
        return _0x2082c5 - _0x3cc8b3;
      },
    };
    var _0x53b70c = _0x4d2774["ztcPD"]["split"]("|"),
      _0x546c0f = 0x0;
    while ([]) {
      switch (_0x53b70c[_0x546c0f++]) {
        case "0":
          _0x4d2774["yBslA"](GAME_CURRENT_ORIENTATION, ORIENTATION_LANDSCAPE)
            ? (btnFullscreenToggle["scale"]["set"](0.8),
              SOUNDS_ENABLED && btnSoundsToggle["scale"]["set"](0.8))
            : (btnFullscreenToggle["scale"]["set"](0x1),
              SOUNDS_ENABLED && btnSoundsToggle["scale"]["set"](0x1));
          continue;
        case "1":
          btnFullscreenToggle["position"]["setTo"](
            0x32,
            _0x4d2774["YqEhK"](game["height"], 0x32)
          );
          continue;
        case "2":
          btnFullscreenToggle["visible"] = screenfull["enabled"];
          continue;
        case "3":
          SOUNDS_ENABLED &&
            btnSoundsToggle["position"]["setTo"](
              _0x4d2774["aAArw"](game["width"], 0x32),
              _0x4d2774["aAArw"](game["height"], 0x32)
            );
          continue;
        case "4":
          txtBuildString["position"]["setTo"](
            _0x4d2774["aAArw"](game["width"], 0x5),
            0x2
          );
          continue;
      }
      break;
    }
  },
  ButtonsOnLeft: function () {
    btnSoundsToggle["x"] = 0x1a;
  },
  ButtonsOnRight: function () {
    var _0x2ce0e5 = {
      kHKYT: function (_0x793b6f, _0x5ecf0b) {
        return _0x793b6f - _0x5ecf0b;
      },
    };
    btnSoundsToggle["x"] = _0x2ce0e5["kHKYT"](game["width"], 0x1a);
  },
  GetRenderTypeName: function (_0x486771) {
    var _0xc8ac3e = {
      buzQm: "AUTO",
      EmUWx: "CANVAS",
      oUeiS: "WEBGL",
      XDTBM: "NaN",
    };
    switch (_0x486771) {
      case Phaser["AUTO"]:
        return _0xc8ac3e["buzQm"];
      case Phaser["CANVAS"]:
        return _0xc8ac3e["EmUWx"];
      case Phaser["WEBGL"]:
        return _0xc8ac3e["oUeiS"];
    }
    return _0xc8ac3e["XDTBM"];
  },
  GetPhaserSettingsString: function () {
    var _0x2b9619 = {
      qLlKe: function (_0x2a1c0f, _0x59db6e) {
        return _0x2a1c0f + _0x59db6e;
      },
      KZrEF: ",\x20enableDebug",
      rXoNR: ",\x20forceSingleUpdate",
      qGvSN: function (_0x286f12, _0xbfb711) {
        return _0x286f12 + _0xbfb711;
      },
      hqqOA: function (_0x27863f, _0x273929) {
        return _0x27863f + _0x273929;
      },
    };
    var _0xd596c0 = _0x2b9619["qLlKe"](
      _0x2b9619["qLlKe"](game["width"], "x"),
      game["height"]
    );
    game["debug"]["isDisabled"] || (_0xd596c0 += _0x2b9619["KZrEF"]);
    game["debug"]["forceSingleUpdate"] && (_0xd596c0 += _0x2b9619["rXoNR"]);
    return _0x2b9619["qGvSN"](_0x2b9619["hqqOA"]("[", _0xd596c0), "]");
  },
  ToggleSounds: function () {
    var _0x33bbfb = {
      bDSWX: "0|3|4|5|1|2",
      vbZBh: "menu-click1",
      wwkft: "kff-music",
      tyIil: "sound-on",
      Zoqmv: "sound-off",
    };
    var _0x21fde0 = _0x33bbfb["bDSWX"]["split"]("|"),
      _0x1c139d = 0x0;
    while ([]) {
      switch (_0x21fde0[_0x1c139d++]) {
        case "0":
          soundManager["toggleMusic"](soundManager["actualMusic"]);
          continue;
        case "1":
          soundManager["playSound"](_0x33bbfb["vbZBh"]);
          continue;
        case "2":
          try {
            localStorage["setItem"](
              _0x33bbfb["wwkft"],
              soundManager["musicPlaying"]
            );
          } catch (_0x1bfc4c) {}
          continue;
        case "3":
          btnSoundsToggle["frameName"] = soundManager["musicPlaying"]
            ? _0x33bbfb["tyIil"]
            : _0x33bbfb["Zoqmv"];
          continue;
        case "4":
          btnSoundsToggle["cachedTint"] = -0x1;
          continue;
        case "5":
          btnSoundsToggle["cachedTint"] = -0x1;
          continue;
      }
      break;
    }
  },
  ToggleFullscreen: function () {
    var _0x4727e4 = { QiaIo: "menu-click1" };
    this["button"]["buttonPressed"] = !0x1;
    soundManager["playSound"](_0x4727e4["QiaIo"]);
    screenfull["toggle"]();
  },
};
var GameState = function (_0x37b598) {},
  gameState = null,
  textParticles = null;
GameState["prototype"] = {
  preload: function () {},
  create: function () {
    var _0x2a7ec8 = {
      mMXLE: "4|17|20|8|18|3|10|7|19|11|15|5|22|14|6|1|0|2|12|21|16|9|13",
      fpYLE: "canvas",
      QSbqu: "shadowed",
      OMZMt: function (_0x2e7e70) {
        return _0x2e7e70();
      },
    };
    var _0x454bd8 = _0x2a7ec8["mMXLE"]["split"]("|"),
      _0x2e472c = 0x0;
    while ([]) {
      switch (_0x454bd8[_0x2e472c++]) {
        case "0":
          SceneMenu["instance"]["ShowAnimated"](0x64);
          continue;
        case "1":
          scenes["push"](new SceneSounds());
          continue;
        case "2":
          game["onPause"]["add"](this["onGamePause"], this);
          continue;
        case "3":
          game["time"]["advancedTiming"] = !0x0;
          continue;
        case "4":
          var _0x4cdfe9 = {
            boqze: _0x2a7ec8["fpYLE"],
            ERYQE: _0x2a7ec8["QSbqu"],
          };
          continue;
        case "5":
          scenes["push"](new SceneLogo());
          continue;
        case "6":
          scenes["push"](new SceneOverlay());
          continue;
        case "7":
          soundManager = new SoundManager(game);
          continue;
        case "8":
          game["renderer"]["renderSession"]["roundPixels"] = !0x0;
          continue;
        case "9":
          game["time"]["events"]["add"](
            0xfa,
            function () {
              document["getElementsByTagName"](_0x4cdfe9["boqze"])[0x0][
                "classList"
              ]["add"](_0x4cdfe9["ERYQE"]);
            },
            this
          );
          continue;
        case "10":
          gameState = this;
          continue;
        case "11":
          scenes = [];
          continue;
        case "12":
          game["onResume"]["add"](this["onGameResume"], this);
          continue;
        case "13":
          this["showAds"];
          continue;
        case "14":
          scenes["push"](new SceneGame());
          continue;
        case "15":
          scenes["push"](new SceneBackground());
          continue;
        case "16":
          resizeCounter = 0x0;
          continue;
        case "17":
          game["input"]["maxPointers"] = 0x1;
          continue;
        case "18":
          ScenesTransitions["TRANSITION_LENGTH"] *= 0.4;
          continue;
        case "19":
          soundManager["create"]();
          continue;
        case "20":
          game["stage"]["backgroundColor"] = 0xa48255;
          continue;
        case "21":
          _0x2a7ec8["OMZMt"](analyticsOnMainMenuLoadEvent);
          continue;
        case "22":
          scenes["push"](new SceneMenu());
          continue;
      }
      break;
    }
  },
  update: function () {
    var _0x3072c5 = {
      ByBPH: function (_0x69b49a, _0x4b5246) {
        return _0x69b49a === _0x4b5246;
      },
      zPuOe: "function",
    };
    scenes["forEach"](function (_0x25fece) {
      _0x3072c5["ByBPH"](_0x3072c5["zPuOe"], typeof _0x25fece["update"]) &&
        _0x25fece["update"]();
    });
  },
  updateTexts: function () {
    var _0xdabf79 = {
      BwwYL: function (_0x23c029, _0x546d4f) {
        return _0x23c029 === _0x546d4f;
      },
      ruvOn: "function",
    };
    scenes["forEach"](function (_0x2f5621) {
      _0xdabf79["BwwYL"](_0xdabf79["ruvOn"], typeof _0x2f5621["updateTexts"]) &&
        _0x2f5621["updateTexts"]();
    });
  },
  onResolutionChange: function () {
    var _0x14866f = {
      Rgsyg: function (_0x516bd8, _0x461b2b) {
        return _0x516bd8 === _0x461b2b;
      },
      vXPVI: "function",
    };
    scenes["forEach"](function (_0x1a963f) {
      if (
        _0x14866f["Rgsyg"](
          _0x14866f["vXPVI"],
          typeof _0x1a963f["onResolutionChange"]
        )
      )
        _0x1a963f["onResolutionChange"]();
    });
  },
  onGamePause: function () {
    var _0x4e2ac9 = {
      zcGpb: "0|4|5|1|3|2",
      mShYi: function (_0x52aaf7, _0x37385f) {
        return _0x52aaf7 === _0x37385f;
      },
      dylvy: "function",
      jqNSZ: function (_0x495a23, _0x4c88df) {
        return _0x495a23(_0x4c88df);
      },
      aIgFS: "onGamePause",
    };
    var _0x16fa21 = _0x4e2ac9["zcGpb"]["split"]("|"),
      _0x37da65 = 0x0;
    while ([]) {
      switch (_0x16fa21[_0x37da65++]) {
        case "0":
          var _0xb65a0f = {
            NhtqC: function (_0x5860ac, _0x10564f) {
              return _0x4e2ac9["mShYi"](_0x5860ac, _0x10564f);
            },
            HAJAE: _0x4e2ac9["dylvy"],
          };
          continue;
        case "1":
          paused = !0x0;
          continue;
        case "2":
          game["device"]["desktop"] && game["input"]["mspointer"]["stop"]();
          continue;
        case "3":
          try {
            game["sound"]["mute"] = !0x0;
          } catch (_0x46fbf2) {}
          continue;
        case "4":
          _0x4e2ac9["jqNSZ"](LOG, _0x4e2ac9["aIgFS"]);
          continue;
        case "5":
          scenes["forEach"](function (_0x2a51d4) {
            if (
              _0xb65a0f["NhtqC"](
                _0xb65a0f["HAJAE"],
                typeof _0x2a51d4["onPause"]
              )
            )
              _0x2a51d4["onPause"]();
          });
          continue;
      }
      break;
    }
  },
  onGameResume: function () {
    var _0x2bdc98 = {
      LwNGT: "2|4|5|1|0|3",
      vhDVD: function (_0xc850cf, _0x5ee344) {
        return _0xc850cf === _0x5ee344;
      },
      gSuoi: "function",
      fTSMy: function (_0x1224d9, _0x12b982) {
        return _0x1224d9(_0x12b982);
      },
      fOyIl: "onGameResume",
    };
    var _0x334725 = _0x2bdc98["LwNGT"]["split"]("|"),
      _0x557ba0 = 0x0;
    while ([]) {
      switch (_0x334725[_0x557ba0++]) {
        case "0":
          try {
            game["sound"]["mute"] = !0x1;
          } catch (_0x2a673f) {}
          continue;
        case "1":
          scenes["forEach"](function (_0x2156aa) {
            if (
              _0x48bcc4["VVHAo"](
                _0x48bcc4["uALIu"],
                typeof _0x2156aa["onResume"]
              )
            )
              _0x2156aa["onResume"]();
          });
          continue;
        case "2":
          var _0x48bcc4 = {
            VVHAo: function (_0x36a9a4, _0x1ac1f8) {
              return _0x2bdc98["vhDVD"](_0x36a9a4, _0x1ac1f8);
            },
            uALIu: _0x2bdc98["gSuoi"],
          };
          continue;
        case "3":
          game["device"]["desktop"] && game["input"]["mspointer"]["stop"]();
          continue;
        case "4":
          _0x2bdc98["fTSMy"](LOG, _0x2bdc98["fOyIl"]);
          continue;
        case "5":
          paused = !0x1;
          continue;
      }
      break;
    }
  },
  render: function () {
    var _0x4b26b4 = {
      kRFpc: function (_0x242cec, _0xd84ea9) {
        return _0x242cec === _0xd84ea9;
      },
      MZDYL: "function",
    };
    scenes["forEach"](function (_0x32cb36) {
      _0x4b26b4["kRFpc"](_0x4b26b4["MZDYL"], typeof _0x32cb36["render"]) &&
        _0x32cb36["render"]();
    });
  },
  showFullscreeAd: function () {
    var _0x3b20c5 = {
      RyCJs: function (_0x43c9f1, _0x172247) {
        return _0x43c9f1(_0x172247);
      },
      SBhUN: "showFullscreeAd()",
      OnNJW: function (_0x102fbd, _0x2db696) {
        return _0x102fbd(_0x2db696);
      },
      GKiLt: "adFullScreen",
    };
    _0x3b20c5["RyCJs"](LOG, _0x3b20c5["SBhUN"]);
    _0x3b20c5["OnNJW"](showDiv, _0x3b20c5["GKiLt"]);
  },
};
function showDiv(_0x45f314, _0x159165) {
  var _0x320dfd = {
    axPam: function (_0x445b45, _0x998d64) {
      return _0x445b45 == _0x998d64;
    },
    cKYiO: "block",
  };
  _0x320dfd["axPam"](null, _0x159165) && (_0x159165 = !0x1);
  if (!game["device"]["desktop"] || _0x159165)
    document["getElementById"](_0x45f314)["style"]["display"] =
      _0x320dfd["cKYiO"];
}
function hideDiv(_0x25a784, _0x1b367a) {
  var _0xd65636 = {
    SfmyC: function (_0x48ae5c, _0x10f54e) {
      return _0x48ae5c == _0x10f54e;
    },
    LOnld: "none",
  };
  _0xd65636["SfmyC"](null, _0x1b367a) && (_0x1b367a = !0x1);
  if (!game["device"]["desktop"] || _0x1b367a)
    document["getElementById"](_0x25a784)["style"]["display"] =
      _0xd65636["LOnld"];
}
function reloadPage() {
  window["location"]["reload"](!0x0);
}
var ress = getMaxGameResolution(),
  resolutionX = ress[0x0],
  resolutionY = ress[0x1],
  languageLoaded = !0x1,
  isIOS = !0x1,
  userAgent = navigator["userAgent"] || navigator["vendor"] || window["opera"];
if (
  userAgent["match"](/iPad/i) ||
  userAgent["match"](/iPhone/i) ||
  userAgent["match"](/iPod/i)
)
  isIOS = !0x0;
var aspect = window["innerWidth"] / window["innerHeight"],
  androidVersionString = getAndroidVersion(),
  androidVersionMajor = 0x4;
0x0 != androidVersionString &&
  (androidVersionMajor = parseInt(getAndroidVersion(), 0xa));
var GAME_FONT = "gameFont";
0x4 > androidVersionMajor && (GAME_FONT = "arial");
selectedRenderer = Phaser["CANVAS"];
var config = {
  width: resolutionX,
  height: resolutionY,
  renderer: selectedRenderer,
  enableDebug: !0x0,
  antialias: !0x0,
  forceSetTimeOut: !0x1,
  transparent: !0x0,
};
window["addEventListener"]("contextmenu", function (_0x3bbd8f) {
  _0x3bbd8f["preventDefault"]();
});
document["addEventListener"]("touchstart", function (_0x1ab314) {
  _0x1ab314["preventDefault"]();
});
document["addEventListener"]("touchmove", function (_0x1aef32) {
  _0x1aef32["preventDefault"]();
});
var game = new Phaser["Game"](config);
game["forceSingleUpdate"] = !0x0;
game["state"]["add"]("SplashState", Splash);
game["state"]["add"]("PreloadState", Preloader);
game["state"]["add"]("GameState", GameState);
game["state"]["start"]("SplashState");
adinplay_init();
function setBG() {
  var _0xc003d6 = {
    TOnUh: "url(\x27assets/img_480/bg.png\x27)",
    GIqzB: function (_0xc16935, _0x88c6fd) {
      return _0xc16935 + _0x88c6fd;
    },
    dgLGN: "500px\x20",
  };
  document["body"]["style"]["backgroundImage"] = _0xc003d6["TOnUh"];
  document["body"]["style"]["backgroundSize"] = _0xc003d6["GIqzB"](
    _0xc003d6["GIqzB"](_0xc003d6["dgLGN"], window["innerHeight"]),
    "px"
  );
}
setBG();
window["addEventListener"](
  "touchend",
  function () {
    var _0x173ded = {
      pPjhz: function (_0x4961cc, _0x1a3caf) {
        return _0x4961cc !== _0x1a3caf;
      },
      XnEaH: "running",
    };
    if (_0x173ded["pPjhz"](null, game))
      try {
        _0x173ded["pPjhz"](
          _0x173ded["XnEaH"],
          game["sound"]["context"]["state"]
        ) && game["sound"]["context"]["resume"]();
      } catch (_0x260589) {}
  },
  !0x1
);
window["addEventListener"]("contextmenu", function (_0x295631) {
  _0x295631["preventDefault"]();
});
document["documentElement"]["style"]["overflow"] = "hidden";
document["body"]["scroll"] = "no";
window["SDK_OPTIONS"] = {
  gameId: "06ifgofdhftx97ifrvb9fswoyc9etqku",
  onEvent: function (_0x5b2e02) {
    var _0x398521 = {
      TWUTN: "SDK_GAME_START",
      dFSRi: function (_0x5b6e52, _0x78724) {
        return _0x5b6e52 != _0x78724;
      },
      rmGoo: "SDK_GAME_PAUSE",
      cKTYq: function (_0x1d9d87, _0x2b72fd) {
        return _0x1d9d87 != _0x2b72fd;
      },
    };
    switch (_0x5b2e02["name"]) {
      case _0x398521["TWUTN"]:
        _0x398521["dFSRi"](null, game) &&
          ((game["sound"]["mute"] = !0x1), (game["paused"] = !0x1));
        break;
      case _0x398521["rmGoo"]:
        _0x398521["cKTYq"](null, game) && (game["sound"]["mute"] = !0x0);
    }
  },
};
