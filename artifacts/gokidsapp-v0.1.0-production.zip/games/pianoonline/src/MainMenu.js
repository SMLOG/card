BasicGame.MainMenu = function (game) {
    sonidoAudio = true;
    estaElMuteActivado = false;
    mundo = this;

};
BasicGame.MainMenu.prototype = {
   
    create: function () {
       
    },
   
};